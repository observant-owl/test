# csv2avro — MinIO CSV → Flink → Redpanda Avro

Flink job: reads gzipped CSV objects from MinIO/S3, parses and maps each row to a typed Avro
record, writes it to Redpanda, and routes bad rows to a shared JSON DLQ topic.
One FlinkDeployment per CSV type per environment, all from this one jar.

**Everything in this file is checked against the code. Do not trust anything here that the code
contradicts — fix this file instead.**

## Current state

**The job cannot run yet.** `core/source/Sources.forStream()` throws unconditionally: the
`OwnFileSource` artifact is not in `pom.xml`. That is the one blocker. Everything downstream of
it is implemented and tested.

Also still placeholder: `type-a` is a template (`src/main/avro/type-a.avsc`, `TypeAMapper`,
and `expectedHeader: "id,name,value"` in config are all `TODO(user)`).

## Build

```sh
mvn test          # 82 tests, no cluster needed
mvn package       # shaded jar, main class com.example.csv2avro.Job
```

Java 17, Flink 2.1.3, Avro 1.11.4, commons-csv 1.14.0. Flink and slf4j are `provided`; the S3
filesystem must NOT be shaded — it belongs in `plugins/` via `ENABLE_BUILT_IN_PLUGINS`.

## Data flow

```
OwnFileSource ──> CorruptTolerantBulkFormat ──> CsvToAvroFunction ──> KafkaSink (Avro)
   (per type)      produces Line records          parse + map          └─ side output ──> KafkaSink (DLQ, JSON)
```

One chained operator per type; source, parse/map and sink share a parallelism so Flink can chain
them. Each type is an independent failover region — a poisoned type does not restart its
neighbours. Operator uids derive from the stream id, never graph position.

Delivery is **at-least-once**, and the duplicate window is **one whole file** (a gzip stream
cannot be seeked, so a restart replays the object). Dedup happens downstream in ClickHouse on a
content-derived business key. Smaller objects reduce replay cost more than shorter checkpoint
intervals do.

## Load-bearing invariants

Break any of these and the failure is silent data corruption, not an error. Each is pinned by a
test; if you delete the mechanism, delete its test in the same change.

1. **`LineParser.splitCsv` rebuilds its `CSVParser` on any failure.** One `CSVParser` is kept
   alive and fed one line at a time. A line that fails to parse leaves the lexer mid-token; the
   next line is then swallowed and the one after it loses its first character — straight to
   Kafka, with nothing in any counter. Pinned by
   `LineParserTest.malformedLineDoesNotCorruptTheFollowingLines`.
2. **Synthetic records carry the split's resume position, never one of their own**
   (`CorruptTolerantBulkFormat`). With `NO_OFFSET`, skip count means "restart the file and skip N
   records", so a `FILE_OPEN` claiming skip count 1 drops the first real line of every file on
   restore. This is also why synthetic batches use `SingletonResultIterator` (writes the position
   verbatim) and **not** `ArrayResultIterator` (increments skip count).
3. **`EOFException` is transient, `ZipException` is structural.** S3A raises `EOFException` for
   truncated responses and connection resets. Since the source advances a strict `mtime > cursor`
   watermark, an object skipped once is never revisited — so treating it as permanent corruption
   is unrecoverable data loss. Only `ZipException` skips a file.
4. **Column binding is by name against the pinned `expectedHeader`.** A same-count column
   *reorder* upstream is the one shape that stays silent: values bind to the wrong Avro fields.
   Before a known header change, stop the job, update `.avsc` + mapper + `expectedHeader`,
   redeploy. An added/removed column is loud (a flood of `column-count` rejects).
5. **No CSV field may contain an embedded newline.** Reading is line-oriented. A quoted newline
   shows up as two malformed lines in the DLQ. Rule this out per type.
6. **`RejectReason` is a bounded enum** because it becomes a Prometheus label. Free text there is
   a cardinality explosion. Prose detail goes in the DLQ payload instead.
7. **Every `reason` counter is pre-created at zero** (`StreamMetrics`). An absent series is
   indistinguishable from a zero one, so an alert on it silently never fires. Never call `dec()`.
8. **Non-string conversions in a mapper go through `Cols`.** A raw `Integer.parseInt` throws
   `NumberFormatException`, which counts as a mapper failure and kills the task instead of
   producing a counted DLQ entry.
9. **Write non-printing characters as Unicode escapes** (`LineParser.BOM`). A literal BOM or NUL
   in Java source is invisible and has been introduced by accident repeatedly. Verify at byte
   level, not by eye.

## Adding a CSV type

Five places, no more:

1. `src/main/avro/<id>.avsc` — the target schema.
2. `src/main/java/com/example/csv2avro/streams/<id>/<Id>Mapper.java` — a `RowMapper`.
3. One line in `streams/Streams.java` (`ALL`), the compile-time registry.
4. `config/streams/<id>.yaml` — prefix, topic, `expectedHeader`, dialect.
5. `src/test/resources/fixtures/<id>/` — `input.csv` + `expected.json`. `ConformanceTest`
   auto-discovers it and fails loudly if missing.

For a repair profile too: `config/repair/repair-<id>.yaml` and
`k8s/overlays/missing-files/<id>/`, plus a line in `k8s/base/kustomization.yaml`.

`Streams.ALL` is a plain list, deliberately **not** `ServiceLoader` — a `META-INF/services` text
file cannot be checked by the compiler, so a typo produced a type that silently did not exist.
The trade-off: types cannot arrive from a separate jar.

### Mapper contract — three outcomes

- **return a record** → normal path, counts in `recordsOut`
- **return `null`** → *deliberately drop* this row (uninteresting input, not bad input). Counts in
  `rowsDropped`, writes nothing anywhere.
- **throw `RowRejectedException`** → *reject* this row (bad input). Raw line goes to the DLQ,
  `rowsRejected{reason}` increments, the file keeps processing.

Drop and reject are separate so the DLQ-rate alert stays meaningful.

## Configuration

Ordered YAML layers, deep-merged, passed as repeated `--config`:

```
base.yaml → env/<env>.yaml → streams/<type>.yaml [→ repair/repair-<type>.yaml]
```

- **Objects merge recursively; scalars and arrays are replaced wholesale.** A layer setting
  `nullTokens` replaces the whole list — write the complete list you want.
- **Unknown keys fail at startup in any layer.** The merged tree is bound once with
  `FAIL_ON_UNKNOWN_PROPERTIES`, so a typo is never a silent no-op.
- **The configured streams are the running streams.** No enable flag. To pause a type, suspend
  its FlinkDeployment (`spec.job.state: suspended`) — that keeps the job graph, so resuming needs
  no `--allowNonRestoredState`.
- **The repair layer must come last**, after the stream layer whose prefix and topic it replaces.
  Get it wrong and nothing fails — the repair run reads the live prefix and replays production.
  `ConfigStackTest` pins this.
- **Every config file needs a unique basename.** `configMapGenerator` flattens paths, so
  `repair/type-a.yaml` would silently overwrite `streams/type-a.yaml` in the mount. Hence the
  `repair-` prefix. Pinned by `ConfigStackTest`.
- **`job.name` must match the FlinkDeployment's `metadata.name`**, because `Job` appends
  `-<streamId>`. Pinned by `ConfigStackTest.jobNameMatchesTheDeploymentName`.

## Kubernetes

`k8s/base` (FlinkDeployment skeleton + ConfigMap of every config file) → `overlays/<env>/env`
(endpoints, checkpointing) → `overlays/<env>/<type>` (deployment name + `--config` args).

```sh
kustomize build k8s/overlays/prod/type-a --load-restrictor LoadRestrictionsNone | kubectl apply -f -
```

`LoadRestrictionsNone` because the generator reads `config/` outside the kustomization root
(Flux defaults to it). `disableNameSuffixHash: true` because the ConfigMap is referenced from
inside a CRD's podTemplate, where kustomize's name-reference fixup does not reach — a hashed name
would dangle. Consequence: editing `config/` does **not** auto-roll pods; restart manually.
`nameSuffix`/`namePrefix` are avoided for the same reason.

### Repair runbook (`missing-files`)

Re-ingests a staged set of objects into a separate topic while dev and prod keep running. Applied
by hand, not reconciled by Flux.

```sh
# 1. stage ALL the objects first — see note below
aws s3 cp --recursive s3://BUCKET/type-a/... s3://BUCKET/repair/type-a/
# 2. start
kustomize build k8s/overlays/missing-files/type-a --load-restrictor LoadRestrictionsNone | kubectl apply -f -
# 3. watch filesOpened climb, then recordsOut flatten
# 4. tear down
kubectl delete flinkdeployment csv-to-avro-missing-files-type-a
aws s3 rm --recursive s3://BUCKET/repair/type-a/
```

- **Stage everything before starting.** The source takes all existing objects at startup then
  advances a strict `mtime > cursor`. S3 `LastModified` is second-granularity, so an object
  landing in the same second as the cursor is skipped silently.
- **Nothing signals completion** — there is no bounded mode. `recordsOut` going flat is the
  signal; teardown is manual.
- **`upgradeMode: stateless`**, overriding prod's `savepoint`. The checkpointed state *is* the
  mtime cursor; a savepoint restore after changing the prefix would skip every staged object
  older than the old cursor.

## The `OwnFileSource` contract (resolved 2026-09-01)

The rest of the design depends on these properties:

- FLIP-27 Source V2, used via `env.fromSource(...)`. Compiled against Flink 1.20.3, 2.1.0, 2.2.0.
- Emits whatever the supplied `StreamFormat`/`BulkFormat` produces. Transparently decompresses
  `.gz`, `.bz2`, `.xz`, `.deflate`; compressed files are non-splittable.
- **File boundaries do not survive the source.** This is why `CorruptTolerantBulkFormat` exists:
  a `BulkFormat`'s `createReader` sees the split, hence the path/mtime/size, and attaches them to
  every `Line`.
- Cursor is strict `mtime > last`, advanced at discovery time. Objects tying with or older than
  the cursor are skipped forever; the repair is to re-upload (a fresh PUT gets a fresh mtime).
- Checkpoints hold the mtime cursor + pending splits + in-flight offsets. gzip ⇒ whole-file
  replay on restart.
- **No bounded mode** (`processStaticFileSet()` throws). No include/exclude globs.
- MinIO endpoint, credentials, region and path-style access come from the Flink S3 filesystem
  plugin, never from job config.

## Metrics

Scope `csv2avro` + a keyed `stream` group, so the exported series are
`..._csv2avro_stream_recordsOut{stream="type-a"}` and
`..._csv2avro_stream_reason_rowsRejected{stream="type-a",reason="column-count"}`.

Counters: `recordsOut`, `rowsDropped`, `rowsRejected{reason}`, `headerLinesDropped`,
`blankLinesDropped`, `corruptFilesSkipped`, `mapperFailures`, `filesOpened`, `objectBytesRead`.
Gauge: `newestFileModifiedMillis` (absolute epoch millis; age is
`time() - (max by (stream) (... > 0) / 1000)`).

Every line is accounted for exactly once, so "rows that vanished" is not a reachable state.

Known limits, deliberately accepted:
- `mapperFailures` increments on a task that is about to die, so it usually never survives to be
  scraped. The log line and the DLQ entry are the reliable signals.
- `newestFileModifiedMillis` is an unclamped monotonic max — one object with a bogus future mtime
  pins it, and the freshness panel then stays green forever.
- `filesOpened` counts open *attempts*; `FILE_OPEN` is re-emitted on restore.

**Nothing scrapes these yet.** The Prometheus reporter ships in the image's `/opt/` and must be
activated via `ENABLE_BUILT_IN_PLUGINS`, which currently lists only the S3 jar. Port 9249 is not
declared and there is no ServiceMonitor.

## Known traps

1. gzip is non-splittable — parallelism is bounded by concurrent *file count*, not bytes. One
   oversized object pins one subtask.
2. Raising parallelism needs `taskmanager.numberOfTaskSlots` / `spec.job.parallelism` raised too,
   or the job graph asks for slots the operator never provisions.
3. Do not shade the S3 filesystem into the job jar.
4. Disable Schema Registry auto-registration in production; register subjects from CI. A repair
   run's overridden topic derives a *new* subject that would otherwise be auto-registered.
5. Pin the Avro runtime to whatever `flink-avro` resolves, not the newest release.
6. Resist a config-driven mapping DSL. Five types does not justify an ETL engine; mappers stay
   ordinary, testable Java.
7. `CorruptTolerantBulkFormat` builds on `StreamFormatAdapter`, which is `@Internal` Flink API —
   it pins the usable `flink-connector-files` version.

## Still needed per type

Before a type can be written, get **one sample `.csv.gz`** — it settles quoted-newlines,
null-vs-empty, encoding and timestamp format in one shot, and becomes the fixture. Otherwise:
the exact verbatim header line; delimiter/quote/escape/charset; tokens meaning null; per column
the target Avro name, type, nullability and whether it is normalized/removed/renamed/passed
through; timestamp format **and source timezone**; decimal-vs-double; the business key, topic and
partition count.

## Placeholders blocking deployment

`k8s/base/flinkdeployment.yaml`: namespace, image, `flinkVersion`, serviceAccount, `jarURI`,
TaskManager memory, S3 credentials (prefer a secret-backed mechanism over inline keys).
`overlays/{dev,prod}/env/env-patch.yaml`: MinIO addresses, checkpoint buckets/intervals.
`config/`: Redpanda bootstrap + schema-registry endpoints, S3 prefixes, real `expectedHeader`.

## Conventions

- 100-column lines, 4-space indent.
- Comments explain *why*, never *what*. If a comment restates the code, delete it.
- Prefer deleting a mechanism over documenting it.
