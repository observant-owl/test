#!/usr/bin/env bash
# Runs the job against a local MinIO and Redpanda, as `dev-local <type>`.
#
#     ./run-local.sh            # defaults to type-a
#     ./run-local.sh type-b
#
# The .env file is sourced HERE rather than read by Java. That keeps the job's code path
# identical in every environment — it only ever calls System.getenv, and the Kubernetes operator
# supplies nothing of the sort — and it means no dotenv dependency ends up in the shaded jar to
# serve a case that exists only on a laptop.
set -euo pipefail

cd "$(dirname "$0")"

type="${1:-type-a}"

if [[ -f .env ]]; then
    # set -a exports everything the file defines; set +a stops that leaking into later commands.
    set -a
    # shellcheck disable=SC1091
    . ./.env
    set +a
else
    echo "run-local.sh: no .env found — copy env.example to .env first." >&2
    echo "  cp env.example .env" >&2
    exit 1
fi

# Fail here rather than letting the S3 or Kafka client fail later with something less specific.
# The job checks these too, but its message arrives after a Maven build you did not need to wait
# for. These are the four keys profiles/dev-local-*.conf omits.
: "${CSV_SOURCE_S3_ACCESS_KEY:?not set in .env — see env.example}"
: "${CSV_SOURCE_S3_SECRET_KEY:?not set in .env — see env.example}"
: "${CSV_KAFKA_SASL_JAAS_CONFIG:?not set in .env — see env.example}"
: "${CSV_SCHEMA_REGISTRY_USER_INFO:?not set in .env — see env.example}"

# classpathScope=test is load-bearing, not a shortcut: Flink is a `provided` dependency, and
# exec:java's default `runtime` scope leaves provided artifacts out — the job would die on a
# NoClassDefFoundError for StreamExecutionEnvironment before reading a single byte. The test
# scope is the one that carries provided dependencies, which is also how the MiniCluster tests
# run with no extra dependency of their own.
exec mvn -q -B -o test-compile \
    org.codehaus.mojo:exec-maven-plugin:3.5.0:java \
    -Dexec.mainClass=com.example.csv2avro.Job \
    -Dexec.classpathScope=test \
    -Dexec.args="dev-local ${type}"
