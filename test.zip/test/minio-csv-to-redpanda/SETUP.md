# Console setup checklist

Everything that has to exist in MinIO and Redpanda before this job can run, in an order where
nothing references something that does not exist yet. All of it is click-through; no `mc` or
`rpk` required.

Menu names shift between versions — these follow the recent MinIO Console and Redpanda Console
layouts. Where a screen is missing, the equivalent CLI command is named.

## Decide these first

Every step below substitutes one of them, and the last four end up in `profiles/*.conf`.

| | value | notes |
|---|---|---|
| state bucket | `flink-state` | checkpoints, savepoints, HA — one bucket, three prefixes |
| data bucket | `csv-data` | where the CSVs arrive |
| object prefix | `type-a/` | plus `repair/type-a/` for repair runs |
| data TTL | `N` days | must exceed the longest outage you would accept losing objects to |
| partition count | | ClickHouse cluster size × `kafka_num_consumers`; see §6 |
| SASL mechanism | `SCRAM-SHA-256` | whatever you pick goes in every profile's `sasl.mechanism` |

---

## 1. MinIO Console — the **state** MinIO

- [ ] **Buckets → Create Bucket** → `flink-state`. Versioning off.
- [ ] **Select the bucket → Lifecycle → Add Lifecycle Rule** → abort incomplete multipart
      uploads after 7 days. **Nothing else.**

  > Do not put an expiry rule on this bucket. Expiring the newest checkpoint does not fail when
  > you set the rule — it fails on the next restart, and the job cannot recover. The checkpointed
  > state *is* the source's mtime cursor, so the fallback is re-ingesting the whole prefix.

- [ ] **Administrator → Identity → Policies → Create Policy** → name `flink-state`:

  ```json
  {"Version":"2012-10-17","Statement":[
   {"Effect":"Allow",
    "Action":["s3:GetObject","s3:PutObject","s3:DeleteObject",
              "s3:AbortMultipartUpload","s3:ListMultipartUploadParts"],
    "Resource":["arn:aws:s3:::flink-state/*"]},
   {"Effect":"Allow","Action":["s3:ListBucket","s3:ListBucketMultipartUploads"],
    "Resource":["arn:aws:s3:::flink-state"]}]}
  ```

  `s3:DeleteObject` is required, not optional — Flink prunes superseded checkpoints and HA blobs.

- [ ] **Administrator → Identity → Users → Create User** → `flink-state`, attach that policy.

---

## 2. MinIO Console — the **data** MinIO

- [ ] **Buckets → Create Bucket** → `csv-data`.
- [ ] **Lifecycle → Add Lifecycle Rule** → expire after `N` days, prefix `type-a/`.
- [ ] **Lifecycle → Add Lifecycle Rule** → a shorter expiry, prefix `repair/`. That prefix is
      scratch space for repair runs.

  > Expiry is safe here *because* the source advances an mtime cursor rather than remembering
  > paths — an expired object leaves nothing behind. (That property is why Flink's own
  > `FileSource` was rejected; see CLAUDE.md.) An object that expires while the job is down is
  > simply gone, and nothing reports it.

- [ ] **Identity → Policies → Create Policy** → `csv-uploader`:

  ```json
  {"Version":"2012-10-17","Statement":[
   {"Effect":"Allow",
    "Action":["s3:PutObject","s3:AbortMultipartUpload","s3:ListMultipartUploadParts"],
    "Resource":["arn:aws:s3:::csv-data/type-a/*"]}]}
  ```

  Three actions, not one: a multipart upload fails with `s3:PutObject` alone. **No `ListBucket`,
  which means `aws s3 sync` and `mc mirror` will not work** — they list before copying.
  `aws s3 cp` of a single object does. Add a prefix-scoped `ListBucket` if your uploader syncs,
  accepting that it can then enumerate the prefix.

- [ ] **Identity → Policies → Create Policy** → `csv-reader`:

  ```json
  {"Version":"2012-10-17","Statement":[
   {"Effect":"Allow","Action":["s3:GetObject"],
    "Resource":["arn:aws:s3:::csv-data/type-a/*","arn:aws:s3:::csv-data/repair/type-a/*"]},
   {"Effect":"Allow","Action":["s3:ListBucket"],"Resource":["arn:aws:s3:::csv-data"],
    "Condition":{"StringLike":{"s3:prefix":["type-a/*","repair/type-a/*"]}}}]}
  ```

  > If the `s3:prefix` condition is tighter than what the source actually lists, the listing comes
  > back **empty and the job looks healthy** — `filesOpened` stays at zero and no error appears
  > anywhere. Same presentation as a half-configured endpoint. If nothing is being ingested and
  > the logs are clean, suspect this first.

- [ ] **Identity → Users → Create User** → `csv-uploader`, attach the uploader policy.
- [ ] **Identity → Users → Create User** → `csv-reader`, attach the reader policy.

**Getting the keys out:** a MinIO user's username *is* its access key and its password *is* its
secret key, so the two steps above already hand you usable S3 credentials. If your version has
**Identity → Users → *select user* → Service Accounts**, prefer creating one there — separately
revocable without changing the user's password. The top-level **Access Keys** page only creates
keys for whoever is logged in, which is not what you want.

> `s3:PutObject` permits overwrite; S3 has no create-only permission. Re-PUTting an existing key
> gives it a fresh `LastModified`, and the cursor is `mtime > last`, so an accidental re-upload is
> silently re-ingested. Duplicates are collapsed downstream, but only if ClickHouse's
> `sharding_key` is a function of the same business key the dedup uses.

---

## 3. Redpanda Console

Repeat per cluster (dev and prod are separate clusters).

- [ ] **Topics → Create Topic**, one at a time, at the partition count decided above.
      Prod: `type-a.v1`, `type-a.repair.v1`, `csv-ingest.dlq`.
      Dev: `type-a.v1`, your `dev-local` topic, `csv-ingest.dlq`.

  > Sizing is by consumer count, not data volume: below (nodes × `kafka_num_consumers`) some
  > consumers sit idle. It is the **max** across consumer groups, never the sum — a second system
  > reading the same topic has its own group and gets every message anyway, so it only raises the
  > figure if its own parallelism exceeds ClickHouse's. Because records are produced **without a
  > key**, the count can also be raised later without relocating anything — that is what the
  > no-key decision buys. This job is a *producer* here and has no group at all.

- [ ] **Security → Users → Create User** → `csv2avro-<env>`, mechanism as decided. One user serves
      both the broker SASL login and the registry's basic auth.
- [ ] **Security → Users → Create User** → `clickhouse-<env>`.
- [ ] **Security → Users → Create User** → `ci-schema-registry`. Not used yet; see step 4 below.
- [ ] **Security → ACLs → Create ACL** → `csv2avro-<env>`: **Write** on each topic it produces to,
      and **Write** on `_schemas`.
- [ ] **Security → ACLs → Create ACL** → `clickhouse-<env>`: **Read** on each topic, **Read** on
      `_schemas`, **and Read on each consumer group.**

  > The consumer-group entry is the one that gets skipped. Without it the ClickHouse Kafka engine
  > table joins nothing and sits silent — `GROUP_AUTHORIZATION_FAILED` appears only in
  > ClickHouse's own log, and everywhere else it looks like no data arriving.

- [ ] **Schema Registry → Settings** → default compatibility **BACKWARD**, before the job first
      runs. Subjects created afterwards inherit it.

**No subjects to create by hand.** Flink's `ConfluentSchemaRegistryCoder.writeSchema` calls
`register(subject, schema)` unconditionally — `auto.register.schemas` is a `KafkaAvroSerializer`
setting and Flink does not use that serializer, so it has no effect here. Each subject
(`<topic>-value`) appears on the first record. `csv-ingest.dlq` gets none: the DLQ is JSON on
purpose.

> **Consequence while the job can write to `_schemas`:** a `/** */` doc comment in a `.avdl`
> becomes a `doc` property inside `SCHEMA$`, and that is what the registry compares — so editing
> prose silently registers a new version. Use `//` comments only.

---

## 4. Before production — flip registration off

The only control over auto-registration is the ACL, so this is one change:

- [ ] `csv2avro-<env>` → **Read** on `_schemas` instead of Write.
- [ ] `ci-schema-registry` → **Write** on `_schemas`.
- [ ] Register each subject from CI, from the **compiled class**, never re-derived from the IDL —
      `stringType` bakes `avro.java.string` into `SCHEMA$` and the registry compares the string:

  ```sh
  mvn -o -q clean package
  jshell --class-path target/csv2avro-*.jar
  jshell> com.example.csv2avro.generated.TypeA.SCHEMA$.toString()
  ```

  Four subjects per type, not one — prod's `type-a.v1-value`, dev's, `type-a.repair.v1-value`, and
  the dev-local topic's. A repair run against an unregistered subject is a repair that does not
  run.

---

## 5. Where each credential goes

- **`flink-state` user** → `s3.access-key` / `s3.secret-key` in
  `k8s/base/flinkdeployment.yaml`. Prefer a secretRef over inline keys.
- **`csv-reader` user** → `source.s3.access-key` / `.secret-key` as Vault paths in dev, prod and
  missing-files; `$CSV_SOURCE_S3_ACCESS_KEY` / `$CSV_SOURCE_S3_SECRET_KEY` in `.env` for
  dev-local.
- **`csv-uploader` user** → handed to whoever uploads. Appears nowhere in this repo.
- **`csv2avro-<env>`, SASL half** → `kafka.properties.sasl.jaas.config` as a Vault path;
  `$CSV_KAFKA_SASL_JAAS_CONFIG` for dev-local.
- **`csv2avro-<env>`, registry half** → `kafka.schema-registry.properties.basic.auth.user.info`,
  literally `user:password`, as a Vault path; `$CSV_SCHEMA_REGISTRY_USER_INFO` for dev-local.
- **`clickhouse-<env>`** → ClickHouse's Kafka engine tables, and its
  `format_avro_schema_registry_url`.

Endpoints to fill in the same files: `source.s3.endpoint`, `source.s3.bucket`,
`kafka.bootstrap-servers`, `kafka.schema-registry-url` — **in every profile, not just one.**

---

## 6. ClickHouse — three Kafka engine tables per environment

Not a console, but it is the other half of the wiring and the topics are useless without it.
Every node runs every table: this cluster has one node type, so there is no ingest/query split to
respect.

### The live table

```sql
CREATE TABLE type_a_queue
(
    id    String,
    name  String,
    value Nullable(Decimal(18, 4))          -- must match the Avro record's fields
)
ENGINE = Kafka
SETTINGS
    kafka_broker_list     = 'PLACEHOLDER-redpanda:9093',
    kafka_topic_list      = 'type-a.v1',
    kafka_group_name      = 'clickhouse-type-a',   -- what the group ACL in step 3 names
    kafka_format          = 'AvroConfluent',
    kafka_num_consumers   = 2,                     -- per node
    kafka_thread_per_consumer = 1,
    format_avro_schema_registry_url = 'https://user:pass@PLACEHOLDER-redpanda:8081';
```

- [ ] **The materialized view must write the `Distributed` table, not the local MergeTree.**

  > This is the one that interacts with the job's design. Records are produced **without a key**,
  > so the partition a row lands in is arbitrary — which is only safe because the `Distributed`
  > table re-routes every row by its own `sharding_key` at insert time. Point the MV at the local
  > table and the node that happened to consume the partition becomes the shard: arbitrary
  > partitioning becomes arbitrary sharding, replayed duplicates from a re-read file land on
  > different nodes, and `ReplacingMergeTree` never collapses them. That would also make Kafka
  > partitioning load-bearing and flip the no-key decision in CLAUDE.md.

- [ ] **`sharding_key` must be a function of the same business key the dedup uses.** Delivery is
      at-least-once with a duplicate window of one whole file, so anything else scatters the
      duplicates across shards where they can never meet.

### `kafka_num_consumers`, and the three limits on it

All three fail quietly rather than loudly:

- **≤ partitions**, counted across the whole group. 6 nodes × 2 = 12 consumers needs ≥ 12
  partitions; surplus consumers simply never get an assignment. A multiple of the consumer count
  distributes evenly — at 16 partitions over 12 consumers, four do double the work and set the lag.
- **≤ CPU cores** on the node. A per-node limit, not a cluster one.
- **`kafka_thread_per_consumer = 1`** or the parallelism is thrown away: at the default `0` the
  consumers' rows are squashed into one block flushed by a single thread.

Also check `background_message_broker_schedule_pool_size` (default 16) against three tables ×
`kafka_num_consumers` on every node.

To change it later, `DETACH TABLE` / `ATTACH TABLE` is the reliable route. Some versions accept
`ALTER TABLE ... MODIFY SETTING` on a Kafka engine — verify on yours, and note that dropping the
queue table means recreating the materialized view that reads it.

### The other two tables

- [ ] `type-a.repair.v1` — same columns and same `AvroConfluent` format, its **own**
      `kafka_group_name`, and an MV pointing at the same target table as the live one. Without
      this a repair run produces into a void: `recordsOut` climbs, then flattens, and the rows are
      nowhere.
- [ ] `csv-ingest.dlq` — `kafka_format = 'JSONEachRow'`, `kafka_num_consumers = 1`, its own group,
      and a different target table. The DLQ is deliberately not Avro; entries carry the stream id
      and the object key.

### Broker credentials do not go in the DDL

librdkafka properties live in the server config — a `<kafka>` section in `config.xml` or a
`config.d` drop-in, with `security.protocol`, `sasl.mechanism`, `sasl.username`, `sasl.password`,
optionally scoped per topic with a `<kafka_TOPICNAME>` block. So the DDL above is safe to commit;
the `clickhouse-<env>` credential lands in the config file instead.

The registry credential is the exception — it is userinfo inside
`format_avro_schema_registry_url`, which *is* in the DDL. Worth confirming that form works on your
version before relying on it: it fails as a bare 401, with the password in a log line.

## Not covered here

The Vault entries themselves, TLS trust for a private CA, and external ingress with matching
certificate SANs.
