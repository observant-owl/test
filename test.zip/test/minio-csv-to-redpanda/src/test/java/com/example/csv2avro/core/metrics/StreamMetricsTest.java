package com.example.csv2avro.core.metrics;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.csv2avro.core.spi.RejectReason;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class StreamMetricsTest {

    private static final String BASE = "csv2avro.stream";
    private static final String REJECTED = BASE + ".reason.rowsRejected";

    private RecordingMetricGroup root;
    private StreamMetrics metrics;

    @BeforeEach
    void setUp() {
        root = new RecordingMetricGroup();
        metrics = new StreamMetrics(root, "type-a");
    }

    private static Map<String, String> reason(RejectReason r) {
        return Map.of("reason", r.label());
    }

    /**
     * The stream id must arrive as a Prometheus <em>label</em>, not only inside the metric name.
     * Before this, the CSV type was visible solely through Flink's incidental
     * {@code operator_name} variable, so every query depended on an operator naming convention.
     */
    @Test
    void streamIdIsALabelNotJustAName() {
        assertEquals("type-a", root.labelsOf(BASE + ".recordsOut").get("stream"),
                "stream must be registered via addGroup(key, value), not addGroup(String)");
        assertTrue(root.hasMetric(BASE + ".recordsOut"),
                "the keyed group also extends the name; have " + root.all());
    }

    /**
     * A series that first appears on error has no {@code rate()} baseline, and an absent series
     * is indistinguishable from a zero one — so an alert on it silently never fires.
     */
    @Test
    void everyRejectReasonCounterExistsAtZeroBeforeAnyError() {
        for (RejectReason r : RejectReason.values()) {
            assertEquals(0L, root.counterAt(REJECTED, reason(r)).getCount(),
                    "must be pre-created at zero: " + r);
        }
        assertEquals(RejectReason.values().length,
                root.all().stream().filter(x -> x.name().equals(REJECTED)).count(),
                "one series per reason, distinguished only by the label");
        assertEquals("column-count", RejectReason.COLUMN_COUNT.label(),
                "reason labels are a public contract: dashboards and alerts filter on them");
    }

    @Test
    void everyDeclaredMetricIsRegistered() {
        for (String name : new String[] {
            "recordsOut", "rowsDropped", "headerLinesDropped", "blankLinesDropped",
            "corruptFilesSkipped", "mapperFailures", "filesOpened",
            "objectBytesRead", "newestFileModifiedMillis",
        }) {
            assertTrue(root.hasMetric(BASE + "." + name), "missing metric " + name);
        }
    }

    @Test
    void countersAddUpAndRejectionsLandInTheRightBucket() {
        metrics.recordOut();
        metrics.recordOut();
        metrics.rowRejected(RejectReason.COLUMN_COUNT);
        metrics.rowRejected(RejectReason.COLUMN_COUNT);
        metrics.rowRejected(RejectReason.VALUE_FORMAT);
        metrics.mapperFailure();
        metrics.corruptFileSkipped();
        metrics.headerLineDropped();
        metrics.blankLineDropped();
        metrics.fileOpened(1_000L, 500L);

        assertEquals(2L, root.counterAt(BASE + ".recordsOut").getCount());
        assertEquals(2L, root.counterAt(REJECTED, reason(RejectReason.COLUMN_COUNT)).getCount());
        assertEquals(1L, root.counterAt(REJECTED, reason(RejectReason.VALUE_FORMAT)).getCount());
        assertEquals(0L, root.counterAt(REJECTED, reason(RejectReason.MAPPER_OTHER)).getCount(),
                "buckets must not bleed into each other");
        assertEquals(1L, root.counterAt(BASE + ".mapperFailures").getCount());
        assertEquals(1L, root.counterAt(BASE + ".corruptFilesSkipped").getCount());
        assertEquals(1L, root.counterAt(BASE + ".headerLinesDropped").getCount());
        assertEquals(1L, root.counterAt(BASE + ".blankLinesDropped").getCount());
        assertEquals(1L, root.counterAt(BASE + ".filesOpened").getCount());
        assertEquals(500L, root.counterAt(BASE + ".objectBytesRead").getCount(),
                "the object's size is counted when it is opened");
    }

    /**
     * A deliberate drop is neither an emitted record nor a rejection. If it leaked into
     * {@code recordsOut} the throughput SLI would count rows that never reached Kafka; if it
     * leaked into any {@code rowsRejected} bucket, a business filter would page someone.
     */
    @Test
    void deliberateDropsAreCountedSeparatelyFromOutputAndRejections() {
        assertEquals(0L, root.counterAt(BASE + ".rowsDropped").getCount(),
                "must be pre-created at zero like every other counter");

        metrics.recordOut();
        metrics.rowDropped();
        metrics.rowDropped();

        assertEquals(2L, root.counterAt(BASE + ".rowsDropped").getCount());
        assertEquals(1L, root.counterAt(BASE + ".recordsOut").getCount(),
                "a dropped row is not an emitted record");
        for (RejectReason r : RejectReason.values()) {
            assertEquals(0L, root.counterAt(REJECTED, reason(r)).getCount(),
                    "a deliberate drop is not a rejection: " + r);
        }
        assertEquals(0L, root.counterAt(BASE + ".mapperFailures").getCount(),
                "a deliberate drop is not a mapper failure either");
    }

    /** Freshness is an absolute timestamp, monotonic per subtask, 0 until the first file. */
    @Test
    void freshnessGaugeTracksTheNewestFileAndNeverGoesBackwards() {
        assertEquals(0L, newestViaGauge(),
                "must be an honest 0 (filtered by '> 0' in PromQL), not a sentinel");

        metrics.fileOpened(1_756_684_800_000L, 10L);
        assertEquals(1_756_684_800_000L, newestViaGauge());

        // An older file arriving later must not drag freshness backwards.
        metrics.fileOpened(1_000_000_000_000L, 10L);
        assertEquals(1_756_684_800_000L, newestViaGauge());

        // A source that supplies no mtime reports -1; it must not win either.
        metrics.fileOpened(-1L, 10L);
        assertEquals(1_756_684_800_000L, newestViaGauge());
    }

    /** Reads the value the reporter would scrape, not the field behind it. */
    private long newestViaGauge() {
        return root.longGaugeAt(BASE + ".newestFileModifiedMillis").getValue();
    }
}
