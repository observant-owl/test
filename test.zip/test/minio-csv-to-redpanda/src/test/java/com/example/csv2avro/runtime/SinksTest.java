package com.example.csv2avro.runtime;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.example.csv2avro.api.CsvStreamDefinition;
import com.example.csv2avro.testing.TestRow;
import java.util.Set;
import org.apache.flink.configuration.Configuration;
import org.junit.jupiter.api.Test;

/**
 * That the sinks assemble, and that assembling them talks to nobody.
 *
 * <p>{@code fixture-broker:9092} and {@code fixture-registry:8081} do not resolve, so these would
 * fail or hang if construction reached the network — which is the property trap 4 rests on: a bad
 * registry credential surfaces on the first record, never at startup.
 */
class SinksTest {

    private static Configuration config() {
        return Profile.load("testing-rows", "type-a", Set.of("type-a"));
    }

    private static CsvStreamDefinition<TestRow> definition() {
        return new CsvStreamDefinition<>("test-row", TestRow.class,
                row -> TestRow.newBuilder().setId(row.require("id")).build());
    }

    @Test
    void theDlqSinkAssemblesFromAProfileAlone() {
        assertNotNull(Sinks.forDlq(config()));
    }

    /**
     * Covers the four-argument {@code forSpecific} overload. The three-argument one has no way to
     * authenticate, so a locked-down registry would 401 on the first record with nothing in the
     * configuration to explain why.
     */
    @Test
    void theStreamSinkAssemblesIncludingTheRegistrySerializer() {
        assertNotNull(Sinks.forStream(config(), definition()));
    }

    /**
     * Round-robin partitioning is a decision, not an omission (CLAUDE.md). The three-argument
     * {@code CsvStreamDefinition} supplies an extractor that yields null per record — never a
     * null extractor, which the sink's key serializer would NPE on at record time rather than at
     * startup.
     */
    @Test
    void theDefaultKeyExtractorYieldsNullPerRecordRatherThanBeingNull() {
        CsvStreamDefinition<TestRow> def = definition();

        assertNotNull(def.keyExtractor(), "a null extractor NPEs in the sink, at record time");
        assertNull(def.keyExtractor().key(TestRow.newBuilder().setId("a1").build()),
                "a null key is what makes Kafka's sticky partitioner round-robin");
    }
}
