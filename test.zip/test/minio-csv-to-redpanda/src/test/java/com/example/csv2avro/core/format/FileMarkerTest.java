package com.example.csv2avro.core.format;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class FileMarkerTest {

    @Test
    void roundTripsEveryKind() {
        for (FileMarker.Kind kind : FileMarker.Kind.values()) {
            String encoded = FileMarker.encode(
                    kind, "s3://bucket/type-a/2026/09/01/part-0.csv.gz", 1_756_684_800_000L,
                    123_456L);
            FileMarker m = FileMarker.decode(encoded);
            assertNotNull(m, "did not decode: " + kind);
            assertEquals(kind, m.kind());
            assertEquals("s3://bucket/type-a/2026/09/01/part-0.csv.gz", m.path());
            assertEquals(1_756_684_800_000L, m.modifiedMillis());
            assertEquals(123_456L, m.sizeBytes());
        }
    }

    /** The path is last precisely so it needs no escaping, whatever it contains. */
    @ParameterizedTest
    @ValueSource(strings = {
        "s3://b/with space/x.csv.gz",
        "s3://b/with,comma/x.csv.gz",
        "s3://b/with=equals&amp/x.csv.gz",
        "s3://b/quoted\"name\"/x.csv.gz",
        "s3://b/ümläut/日本語/x.csv.gz",
        "file:///tmp/relative/../x.csv",
        "",
    })
    void pathSurvivesAwkwardCharacters(String path) {
        FileMarker m = FileMarker.decode(FileMarker.encode(FileMarker.Kind.OPEN, path, 1, 2));
        assertNotNull(m);
        assertEquals(path, m.path());
    }

    @Test
    void negativeFileFactsSurvive() {
        // FileSourceSplit reports -1 when the source did not supply mtime/size.
        FileMarker m = FileMarker.decode(
                FileMarker.encode(FileMarker.Kind.DONE, "x.csv", -1L, -1L));
        assertNotNull(m);
        assertEquals(-1L, m.modifiedMillis());
        assertEquals(-1L, m.sizeBytes());
    }

    /** The whole point of the NUL separator: real text data can never forge a marker. */
    @ParameterizedTest
    @ValueSource(strings = {
        "id,name,value",
        "a1,Alice,3.5",
        "CSV2AVRO,OPEN,1,2,x",
        "",
    })
    void ordinaryLinesAreNotMarkers(String line) {
        assertNull(FileMarker.decode(line), "should not have decoded: " + line);
    }

    /**
     * Marker-shaped but broken input degrades to "not a marker" (and so to a normal, rejected
     * line) rather than throwing. NULs are built from the escape here on purpose — never
     * paste a literal NUL byte into a source file.
     */
    @Test
    void malformedMarkersDecodeToNullRatherThanThrowing() {
        String n = "\u0000";
        assertNull(FileMarker.decode(n + "CSV2AVRO-CORRUPT" + n + "s3://b/x.csv.gz"),
                "the pre-marker sentinel format is not a marker");
        assertNull(FileMarker.decode(
                n + "CSV2AVROX" + n + "OPEN" + n + "1" + n + "2" + n + "x"), "wrong magic");
        assertNull(FileMarker.decode(
                n + "CSV2AVRO" + n + "SHRUG" + n + "1" + n + "2" + n + "x"), "unknown kind");
        assertNull(FileMarker.decode(
                n + "CSV2AVRO" + n + "OPEN" + n + "nope" + n + "2" + n + "x"), "bad mtime");
        assertNull(FileMarker.decode(n + "CSV2AVRO" + n + "OPEN" + n + "1" + n + "x"),
                "too few fields");
        assertNull(FileMarker.decode("a1,Alice" + n + "3.5"), "NUL not at position 0");
    }

    @Test
    void nullIsNotAMarker() {
        assertNull(FileMarker.decode(null));
    }

    @Test
    void prefixMatchesEncodedOutput() {
        for (FileMarker.Kind kind : FileMarker.Kind.values()) {
            assertTrue(FileMarker.encode(kind, "x.csv", 1, 2)
                    .startsWith(FileMarker.prefixFor(kind)));
        }
    }
}
