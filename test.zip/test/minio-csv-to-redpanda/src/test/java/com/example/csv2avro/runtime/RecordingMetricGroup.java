package com.example.csv2avro.runtime;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.flink.metrics.CharacterFilter;
import org.apache.flink.metrics.Counter;
import org.apache.flink.metrics.Gauge;
import org.apache.flink.metrics.Histogram;
import org.apache.flink.metrics.Meter;
import org.apache.flink.metrics.Metric;
import org.apache.flink.metrics.MetricGroup;
import org.apache.flink.metrics.SimpleCounter;

/**
 * A hand-written {@link MetricGroup} that remembers what was registered, so metric naming and
 * labelling can be asserted directly.
 *
 * <p>Why not {@code OneInputStreamOperatorTestHarness}: its {@code MockEnvironment} uses
 * {@code UnregisteredMetricGroups}, which <em>discards</em> every metric, so reading values back
 * would mean pulling the {@code flink-runtime} / {@code flink-streaming-java} / {@code flink-core}
 * test-jars into the build. This costs zero dependencies.
 *
 * <p>Keeps the two {@code addGroup} overloads apart on purpose — that distinction is the thing
 * under test. {@code addGroup(String)} extends the name only; {@code addGroup(key, value)}
 * extends the name <em>and</em> contributes a Prometheus label. Registrations are therefore
 * identified by name <b>and</b> label set: the six {@code rowsRejected} counters share a name
 * and differ only in {@code reason}, exactly as they will in Prometheus.
 */
public final class RecordingMetricGroup implements MetricGroup {

    /** One registration: the full dotted name, the labels in scope, and the metric itself. */
    public record Registered(String name, Map<String, String> variables, Metric metric) {
        @Override
        public String toString() {
            return name + variables;
        }
    }

    private final List<Registered> registered;
    private final String scope;
    private final Map<String, String> variables;

    public RecordingMetricGroup() {
        this("", new ArrayList<>(), Map.of());
    }

    private RecordingMetricGroup(
            String scope, List<Registered> registered, Map<String, String> variables) {
        this.scope = scope;
        this.registered = registered;
        this.variables = variables;
    }

    // --- assertions ---------------------------------------------------------------------

    public List<Registered> all() {
        return registered;
    }

    public boolean hasMetric(String dottedName) {
        return registered.stream().anyMatch(r -> r.name().equals(dottedName));
    }

    /** The one metric with this name and (at least) these labels. Fails unless exactly one. */
    public Metric metricAt(String dottedName, Map<String, String> labels) {
        List<Registered> hits = registered.stream()
                .filter(r -> r.name().equals(dottedName))
                .filter(r -> labels.entrySet().stream()
                        .allMatch(e -> e.getValue().equals(r.variables().get(e.getKey()))))
                .toList();
        if (hits.size() != 1) {
            throw new AssertionError("expected exactly one metric '" + dottedName + "' with "
                    + labels + ", found " + hits.size() + "; registered: " + registered);
        }
        return hits.get(0).metric();
    }

    public Counter counterAt(String dottedName) {
        return counterAt(dottedName, Map.of());
    }

    public Counter counterAt(String dottedName, Map<String, String> labels) {
        Metric m = metricAt(dottedName, labels);
        if (!(m instanceof Counter c)) {
            throw new AssertionError(dottedName + " is not a Counter but " + m.getClass());
        }
        return c;
    }

    @SuppressWarnings("unchecked")
    public Gauge<Long> longGaugeAt(String dottedName) {
        Metric m = metricAt(dottedName, Map.of());
        if (!(m instanceof Gauge)) {
            throw new AssertionError(dottedName + " is not a Gauge but " + m.getClass());
        }
        return (Gauge<Long>) m;
    }

    /** Labels attached to a registration — what Prometheus would emit. */
    public Map<String, String> labelsOf(String dottedName) {
        return registered.stream()
                .filter(r -> r.name().equals(dottedName))
                .findFirst()
                .orElseThrow(() -> new AssertionError(
                        "no metric '" + dottedName + "'; registered: " + registered))
                .variables();
    }

    // --- MetricGroup --------------------------------------------------------------------

    private String qualify(String name) {
        return scope.isEmpty() ? name : scope + "." + name;
    }

    @Override
    public Counter counter(String name) {
        return counter(name, new SimpleCounter());
    }

    @Override
    public <C extends Counter> C counter(String name, C counter) {
        registered.add(new Registered(qualify(name), variables, counter));
        return counter;
    }

    @Override
    public <T, G extends Gauge<T>> G gauge(String name, G gauge) {
        registered.add(new Registered(qualify(name), variables, gauge));
        return gauge;
    }

    @Override
    public <H extends Histogram> H histogram(String name, H histogram) {
        throw new UnsupportedOperationException("histograms are deliberately not used");
    }

    @Override
    public <M extends Meter> M meter(String name, M meter) {
        throw new UnsupportedOperationException(
                "meters are deliberately not used: MeterView is a 60s sliding average that "
                        + "visibly disagrees with PromQL rate()");
    }

    @Override
    public MetricGroup addGroup(String name) {
        return new RecordingMetricGroup(qualify(name), registered, variables);
    }

    @Override
    public MetricGroup addGroup(String key, String value) {
        Map<String, String> vars = new LinkedHashMap<>(variables);
        vars.put(key, value);
        // Flink keeps the key in the name as well as emitting the value as a label.
        return new RecordingMetricGroup(qualify(key), registered, Map.copyOf(vars));
    }

    @Override
    public String[] getScopeComponents() {
        return scope.isEmpty() ? new String[0] : scope.split("\\.");
    }

    @Override
    public Map<String, String> getAllVariables() {
        return variables;
    }

    @Override
    public String getMetricIdentifier(String metricName) {
        return qualify(metricName);
    }

    @Override
    public String getMetricIdentifier(String metricName, CharacterFilter filter) {
        return filter.filterCharacters(qualify(metricName));
    }
}
