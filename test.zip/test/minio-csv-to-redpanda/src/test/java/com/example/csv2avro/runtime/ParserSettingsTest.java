package com.example.csv2avro.runtime;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.Set;
import org.junit.jupiter.api.Test;

/**
 * The unpack from configuration into {@link LineParser}'s constructor arguments.
 *
 * <p>{@code LineParserTest} pins what the parser does with each dialect, building it by hand; what
 * it cannot see is whether the profile's keys ever arrive. A value dropped here yields a parser
 * that behaves perfectly and is configured as something other than what the file says — no
 * exception, no counter, wrong output. {@code dialect.escape} matters most: it is the only key
 * allowed to be absent, so the two cases take different branches (invariant 1).
 */
class ParserSettingsTest {

    private static final Set<String> REGISTERED = Set.of("type-a");

    private static ParserSettings settings(String env) {
        return ParserSettings.of(Profile.load(env, "type-a", REGISTERED), "type-a");
    }

    @Test
    void anAbsentEscapeKeyBecomesNoEscapeCharacterAtAll() {
        assertNull(settings("testing-complete").escape(),
                "absent must mean RFC 4180 doubled quotes, not opencsv's backslash default");
    }

    /**
     * End to end in one test on purpose: asserting the field is populated and then asserting the
     * parser uses it are not two claims, because the second cannot hold without the first. The
     * split version was strictly subsumed under mutation analysis.
     */
    @Test
    void aConfiguredEscapeSurvivesTheUnpackAndChangesHowALineIsSplit() throws Exception {
        assertEquals(Character.valueOf('\\'), settings("testing-escape").escape(),
                "dialect.escape was configured and did not survive the unpack");

        LineParser parser = settings("testing-escape").newParser();
        LineParser.Outcome outcome = parser.parse(
                Line.data("a1,one\\,two,3", "s3://bucket/x.csv", 0L, 0L));

        assertEquals(LineParser.Outcome.Kind.ROW, outcome.kind(), outcome.reason());
        assertArrayEquals(new String[] {"a1", "one,two", "3"},
                new String[] {outcome.row().get("id"), outcome.row().get("name"),
                        outcome.row().get("value")},
                "the escaped delimiter should not have split the field");
    }

    /** The rest of the dialect, from a fixture that sets none of it to the obvious defaults. */
    @Test
    void theRemainingDialectKeysAllArrive() {
        ParserSettings settings = settings("testing-complete");

        assertEquals(';', settings.delimiter());
        assertEquals('"', settings.quote());
        assertEquals("id,name,value", settings.expectedHeader());
        assertEquals(Set.of("", "NULL", "n/a"), settings.nullTokens(),
                "'' is Flink list syntax for an empty element, i.e. an empty cell means null");
    }
}
