package com.example.csv2avro;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import com.example.csv2avro.runtime.Profile;
import com.example.csv2avro.runtime.Sources;
import java.nio.file.Path;
import java.util.List;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.graph.StreamGraph;
import org.apache.flink.streaming.api.graph.StreamNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/**
 * <b>The graph assembles.</b> Skipped until {@code Sources.forStream} stops throwing, then runs
 * by itself.
 *
 * <p>Nothing is executed — no cluster, no Redpanda, no Schema Registry. Building the graph is
 * the point: it is the only thing that checks the source's produced type, the parse/map operator
 * and both sinks actually fit together, and that every operator carries the uid a state restore
 * depends on. javac only ever sees the declarations.
 *
 * <p>Note each {@code KafkaSink} contributes a writer node <em>and</em> a {@code Sink Committer}
 * node: Flink adds the committer because {@code KafkaSink} supports one at all, not because this
 * job asked for it. At {@code AT_LEAST_ONCE} the writer emits no committables and it stays idle.
 */
class JobGraphTest {

    @TempDir
    Path prefix;

    private Configuration conf;

    @BeforeEach
    void setUp() {
        conf = Profile.load("testing-rows", "type-a", Streams.ids());
        // A prefix carrying its own scheme is used verbatim, so this points the source at a local
        // directory without needing a MinIO or a test-only mode. See Profile.objectPrefix.
        conf.set(Profile.SOURCE_PREFIX, prefix.toUri().toString());
        assumeTrue(sourceIsWired(), "OwnFileSource is not wired yet — see Sources.forStream");
    }

    private boolean sourceIsWired() {
        try {
            Sources.forStream(conf);
            return true;
        } catch (IllegalStateException e) {
            return e.getMessage() == null || !e.getMessage().contains("not wired yet");
        }
    }

    private StreamGraph graph() {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        Job.assemble(env, conf, Streams.byId("type-a"));
        return env.getStreamGraph();
    }

    private static StreamNode nodeWithUid(StreamGraph g, String uid) {
        return g.getStreamNodes().stream()
                .filter(n -> uid.equals(n.getTransformationUID()))
                .findFirst()
                .orElseThrow(() -> new AssertionError("no node with uid '" + uid + "'; present: "
                        + g.getStreamNodes().stream().map(StreamNode::getTransformationUID)
                                .toList()));
    }

    /**
     * Uids derive from the stream id, never from graph position — adding a second CSV type must
     * not reshuffle this one's state, and a restore must not depend on where an operator sits.
     */
    @Test
    void everyOperatorCarriesAStreamIdDerivedUid() {
        List<String> uids = graph().getStreamNodes().stream()
                .map(StreamNode::getTransformationUID)
                .filter(uid -> uid != null)
                .sorted()
                .toList();

        for (String set : List.of("type-a-source", "type-a-parse-map", "type-a-sink",
                "type-a-dlq-sink")) {
            assertTrue(uids.contains(set), "missing uid '" + set + "'; present: " + uids);
        }
        assertTrue(uids.stream().allMatch(uid -> uid.contains("type-a")),
                "every uid must derive from the stream id, got " + uids);
    }

    /**
     * Source, parse/map and the main sink set no parallelism of their own, so all three inherit
     * {@code parallelism.default} — equal by construction, which is what lets Flink chain them.
     * The DLQ writer is the one exception, pinned at 1 by hand.
     */
    @Test
    void onlyTheDlqWriterPinsItsOwnParallelism() {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        Job.assemble(env, conf, Streams.byId("type-a"));
        StreamGraph g = env.getStreamGraph();
        int inherited = env.getParallelism();

        assertEquals(inherited, nodeWithUid(g, "type-a-source").getParallelism());
        assertEquals(inherited, nodeWithUid(g, "type-a-parse-map").getParallelism());
        assertEquals(inherited, nodeWithUid(g, "type-a-sink").getParallelism());
        assertEquals(1, nodeWithUid(g, "type-a-dlq-sink").getParallelism(),
                "a near-idle DLQ topic does not need more than one producer");
    }

    /** A graph where the source fed nothing would still "assemble". */
    @Test
    void theSourceFeedsTheParseMapOperator() {
        StreamGraph g = graph();
        StreamNode source = nodeWithUid(g, "type-a-source");

        assertEquals(1, source.getOutEdges().size(), "the source has exactly one consumer");
        assertEquals(nodeWithUid(g, "type-a-parse-map").getId(),
                source.getOutEdges().get(0).getTargetId());
    }
}
