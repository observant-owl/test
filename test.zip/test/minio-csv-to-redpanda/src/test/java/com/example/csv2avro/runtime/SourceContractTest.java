package com.example.csv2avro.runtime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import com.example.csv2avro.Streams;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPOutputStream;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.connector.source.Boundedness;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.io.TempDir;

/**
 * <b>The contract the source must satisfy — written before the source exists.</b>
 *
 * <p>Every test here is <em>skipped</em> while {@code Sources.forStream} throws, and starts
 * running by itself the day the {@code OwnFileSource} dependency lands. Nothing has to be
 * un-annotated or remembered. If one then fails, the source does not behave the way the rest of
 * this codebase assumes — see CLAUDE.md's source contract.
 *
 * <p>These exist because the rest of the suite fakes this seam: every {@code FileSourceSplit} in
 * {@code CorruptTolerantBulkFormatTest} is hand-built with an mtime and size the test supplies
 * itself, so a source that reports 0, or hands out byte-range splits instead of whole objects,
 * would break metrics and parsing without failing a single existing test.
 *
 * <p>No stubs and no mock enumerator: the job runs on a real embedded MiniCluster
 * ({@code executeAndCollect}, which takes N records and then cancels), so the source is driven by
 * Flink exactly as it will be in production. That also means these tests know nothing about the
 * builder API — they go through {@code Sources.forStream} only.
 */
@Timeout(120)
class SourceContractTest {

    @TempDir
    Path prefix;

    private Configuration conf;

    @BeforeEach
    void setUp() {
        conf = CsvConfig.load(
                Configuration.fromMap(Map.of(CsvConfig.CONFIG.key(), "dev-type-a")),
                Streams.ids());
        conf.set(CsvConfig.SOURCE_PREFIX, prefix.toUri().toString());
        conf.set(CsvConfig.MONITOR_INTERVAL, Duration.ofSeconds(1));
        assumeTrue(sourceIsWired(), "OwnFileSource is not wired yet — see Sources.forStream");
    }

    /** Distinguishes "not implemented" from a real failure by the message the stub throws, so a
     * genuinely broken source fails loudly instead of being silently skipped. */
    private boolean sourceIsWired() {
        try {
            Sources.forStream(conf);
            return true;
        } catch (IllegalStateException e) {
            return e.getMessage() == null || !e.getMessage().contains("not wired yet");
        }
    }

    /** One gzipped object under the prefix. Header matches dev-type-a.conf's expected-header. */
    private Path writeGzipObject(String name, String body) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (GZIPOutputStream gz = new GZIPOutputStream(bytes)) {
            gz.write(("id,name,value\n" + body).getBytes(StandardCharsets.UTF_8));
        }
        Path f = prefix.resolve(name);
        Files.write(f, bytes.toByteArray());
        return f;
    }

    /** Runs the real source on an embedded cluster until {@code n} records are out, then cancels.
     * The job is unbounded, so a limit is the only way this ever returns. */
    private List<Line> collect(int n) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        return env.fromSource(Sources.forStream(conf), WatermarkStrategy.noWatermarks(),
                        "type-a-source", TypeInformation.of(Line.class))
                .executeAndCollect(n);
    }

    private static List<Line> ofKind(List<Line> lines, Line.Kind kind) {
        return lines.stream().filter(l -> l.kind == kind).toList();
    }

    // --- the contract ------------------------------------------------------------------------

    /**
     * There is no bounded mode. A source that reported BOUNDED would drain once and the
     * deployment would report FINISHED while new objects piled up unread.
     */
    @Test
    void theSourceIsUnboundedSoTheDeploymentKeepsPolling() {
        assertEquals(Boundedness.CONTINUOUS_UNBOUNDED, Sources.forStream(conf).getBoundedness());
    }

    /** Transparent decompression, and the line text is the decompressed CSV. */
    @Test
    void gzippedObjectsAreDecompressedTransparently() throws Exception {
        writeGzipObject("a.csv.gz", "a1,Alice,3.5\na2,Bob,1.5\n");

        // 4, not 3: the first record out of the source is the synthetic FILE_OPEN.
        List<Line> data = ofKind(collect(4), Line.Kind.DATA);

        assertEquals(List.of("id,name,value", "a1,Alice,3.5", "a2,Bob,1.5"),
                data.stream().map(l -> l.text).toList());
    }

    /**
     * <b>The assumption every per-file metric rests on.</b> {@code CorruptTolerantBulkFormat}
     * copies the split's mtime and size onto every record; if the source supplies 0 or -1,
     * {@code newestFileModifiedMillis} and {@code objectBytesRead} are silently wrong and no
     * other test notices.
     */
    @Test
    void everyRecordCarriesTheObjectPathRealMtimeAndRealSize() throws Exception {
        Path object = writeGzipObject("a.csv.gz", "a1,Alice,3.5\n");
        long realMtime = Files.getLastModifiedTime(object).toMillis();
        long realSize = Files.size(object);

        // FILE_OPEN + header + the data row: the signal and the real lines must all carry it.
        for (Line l : collect(3)) {
            assertTrue(l.path != null && l.path.endsWith("a.csv.gz"),
                    "every record must name its object, got " + l.path);
            assertEquals(realSize, l.sizeBytes, "sizeBytes must be the on-the-wire object size");
            assertTrue(l.modifiedMillis > 0,
                    "modifiedMillis must be a real epoch time, got " + l.modifiedMillis);
            assertEquals(realMtime / 1000, l.modifiedMillis / 1000,
                    "modifiedMillis must be the object's mtime, to the second");
        }
    }

    /**
     * Whole-file splits. gzip is not splittable, and one split per object is what keeps
     * {@code filesOpened} honest — byte-range splits would emit several FILE_OPENs per object and
     * would start parsing mid-line.
     */
    @Test
    void eachObjectProducesExactlyOneFileOpenSignal() throws Exception {
        writeGzipObject("a.csv.gz", "a1,Alice,3.5\na2,Bob,1.5\na3,Carol,2.5\n");

        List<Line> lines = collect(5);

        assertEquals(1, ofKind(lines, Line.Kind.FILE_OPEN).size(),
                "one object must yield one FILE_OPEN, got " + lines);
    }

    /** Two objects under the prefix are both ingested, each announced once. */
    @Test
    void allObjectsUnderThePrefixAreIngested() throws Exception {
        writeGzipObject("a.csv.gz", "a1,Alice,3.5\n");
        writeGzipObject("b.csv.gz", "b1,Bob,1.5\n");

        List<Line> lines = collect(6);   // 2 x (FILE_OPEN + header + row)

        assertEquals(2, ofKind(lines, Line.Kind.FILE_OPEN).size());
        assertEquals(Set.of("a1,Alice,3.5", "b1,Bob,1.5"),
                ofKind(lines, Line.Kind.DATA).stream()
                        .map(l -> l.text).filter(t -> !t.startsWith("id,")).collect(
                                java.util.stream.Collectors.toSet()));
    }

    /**
     * Continuous discovery: an object that lands after the job started must still be picked up.
     * This is the difference between an ingest job and a one-shot batch read, and it is the one
     * property the repair runbook's "stage everything first" note exists to work around.
     */
    @Test
    void objectsArrivingAfterStartupAreDiscoveredOnALaterPoll() throws Exception {
        writeGzipObject("a.csv.gz", "a1,Alice,3.5\n");

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        var stream = env.fromSource(Sources.forStream(conf), WatermarkStrategy.noWatermarks(),
                "type-a-source", TypeInformation.of(Line.class));

        // The second object is written before the job starts consuming, but the source still has
        // to find it on a discovery pass rather than in one initial listing.
        writeGzipObject("b.csv.gz", "b1,Bob,1.5\n");

        List<Line> lines = stream.executeAndCollect(6);

        assertEquals(2, ofKind(lines, Line.Kind.FILE_OPEN).size(),
                "both objects must be discovered, got " + lines);
    }
}
