package com.example.csv2avro.runtime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipException;
import javax.annotation.Nullable;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.configuration.MemorySize;
import org.apache.flink.connector.file.src.FileSourceSplit;
import org.apache.flink.connector.file.src.reader.BulkFormat;
import org.apache.flink.connector.file.src.reader.StreamFormat;
import org.apache.flink.connector.file.src.reader.TextLineInputFormat;
import org.apache.flink.connector.file.src.util.CheckpointedPosition;
import org.apache.flink.connector.file.src.util.RecordAndPosition;
import org.apache.flink.core.fs.FSDataInputStream;
import org.apache.flink.core.fs.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class CorruptTolerantBulkFormatTest {

    private static final long MTIME = 1_756_684_800_000L;

    @TempDir
    java.nio.file.Path dir;

    /** One emitted record plus the position it claimed — positions are half of what is asserted
     * here, because a synthetic record that claims to advance the file position silently drops
     * real data on restore. */
    private record Emitted(Line record, long offset, long skipCount) {
        boolean isKind(Line.Kind kind) {
            return record.kind() == kind;
        }
    }

    private static FileSourceSplit splitFor(java.nio.file.Path file) throws IOException {
        long len = Files.size(file);
        return new FileSourceSplit(
                "split-1", new Path(file.toUri()), 0, len, MTIME, len);
    }

    private static List<Emitted> drain(BulkFormat.Reader<Line> reader) throws IOException {
        List<Emitted> out = new ArrayList<>();
        try (BulkFormat.Reader<Line> r = reader) {
            BulkFormat.RecordIterator<Line> batch;
            while ((batch = r.readBatch()) != null) {
                RecordAndPosition<Line> rec;
                while ((rec = batch.next()) != null) {
                    out.add(new Emitted(
                            rec.getRecord(), rec.getOffset(), rec.getRecordSkipCount()));
                }
                batch.releaseBatch();
            }
        }
        return out;
    }

    private static List<Emitted> readAll(BulkFormat<Line, FileSourceSplit> format,
            java.nio.file.Path file) throws IOException {
        return drain(format.createReader(new Configuration(), splitFor(file)));
    }

    private static List<String> describe(List<Emitted> emitted) {
        return emitted.stream().map(e -> e.record().toString()).toList();
    }

    /** Data lines only — file signals stripped, as the parse operator strips them. */
    private static List<String> dataOnly(List<Emitted> emitted) {
        return emitted.stream()
                .filter(e -> e.isKind(Line.Kind.DATA))
                .map(e -> e.record().text())
                .toList();
    }

    private BulkFormat<Line, FileSourceSplit> format() {
        return new CorruptTolerantBulkFormat(new TextLineInputFormat());
    }

    private java.nio.file.Path plainFile() throws IOException {
        java.nio.file.Path f = dir.resolve("ok.csv");
        Files.writeString(f, "id,name,value\na1,Alice,3.5\n");
        return f;
    }

    /** A whole-file split of {@link #plainFile()} carrying a checkpointed position, as Flink
     * hands one back after a restore. {@code skip} records have already been emitted. */
    private FileSourceSplit restoredSplit(int skip) throws IOException {
        java.nio.file.Path f = plainFile();
        long len = Files.size(f);
        return new FileSourceSplit(
                "split-1", new Path(f.toUri()), 0, len, MTIME, len,
                new String[0], new CheckpointedPosition(CheckpointedPosition.NO_OFFSET, skip));
    }

    /** A tiny per-batch fetch budget, so records are handed up in several batches and a
     * mid-file failure can land after some of them. */
    private static Configuration smallFetch() {
        Configuration c = new Configuration();
        c.set(StreamFormat.FETCH_IO_SIZE, MemorySize.parse("4kb"));
        return c;
    }

    private static int count(List<Emitted> emitted, Line.Kind kind) {
        return (int) emitted.stream().filter(e -> e.isKind(kind)).count();
    }

    private java.nio.file.Path gzipFile(String content, String name) throws IOException {
        java.nio.file.Path f = dir.resolve(name);
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (GZIPOutputStream gz = new GZIPOutputStream(bytes)) {
            gz.write(content.getBytes(StandardCharsets.UTF_8));
        }
        Files.write(f, bytes.toByteArray());
        return f;
    }

    // --- content ------------------------------------------------------------------------

    /** Compression is the stock format's business, not this one's — the same rows either way. */
    @Test
    void readsAHealthyFilePlainOrGzipped() throws Exception {
        List<String> rows = List.of("id,name,value", "a1,Alice,3.5");

        assertEquals(rows, dataOnly(readAll(format(), plainFile())));
        assertEquals(rows, dataOnly(readAll(format(),
                gzipFile("id,name,value\na1,Alice,3.5\n", "ok.csv.gz"))));
    }

    // --- file identity travels on every record -------------------------------------------

    /**
     * The reason this format produces {@link Line} rather than {@code String}: a rejected row
     * three-quarters of the way through an object must still be able to name that object in the
     * DLQ. Every record carries it, not just the file signals.
     */
    @Test
    void everyRecordCarriesItsObjectPathModificationTimeAndSize() throws Exception {
        java.nio.file.Path f = plainFile();
        List<Emitted> out = readAll(format(), f);
        assertTrue(out.size() > 1, "expected the file signal plus data rows");
        for (Emitted e : out) {
            Line line = e.record();
            assertTrue(line.path().endsWith("ok.csv"), "got path " + line.path());
            assertEquals(MTIME, line.modifiedMillis());
            assertEquals(Files.size(f), line.sizeBytes());
        }
    }

    // --- file signals ---------------------------------------------------------------------

    /**
     * The counts are only correct if one split is one whole file: a partial split would report
     * its own FILE_OPEN carrying the <em>full</em> fileSize, multiplying both the file count and
     * the byte count. Declaring the format non-splittable is what guarantees that.
     */
    @Test
    void formatIsNonSplittableSoEverySplitIsAWholeFile() {
        assertFalse(format().isSplittable());
    }

    /**
     * {@code filesOpened} counts files, so every attempt announces its file <b>exactly once,
     * first, and adds nothing else</b> — fresh, empty, resumed mid-file or resumed past the last
     * record. Flink counters reset per attempt, so the re-emission after a restore is not a
     * duplicate: suppressing it would lose the file from the attempt that actually read it.
     *
     * <p>One table rather than one test per shape, because the claim is about the whole set. A
     * shape that stopped announcing would otherwise fail only its own test and read as local.
     */
    @Test
    void everyAttemptAnnouncesItsFileExactlyOnceAndFirst() throws Exception {
        java.nio.file.Path empty = dir.resolve("empty.csv");
        Files.writeString(empty, "");
        record Attempt(String shape, List<Emitted> emitted, int total) { }

        for (Attempt a : List.of(
                new Attempt("fresh split", readAll(format(), plainFile()), 3),
                new Attempt("fresh split, empty object", readAll(format(), empty), 1),
                new Attempt("restored with one record left",
                        drain(format().restoreReader(new Configuration(), restoredSplit(1))), 2),
                new Attempt("restored past the last record",
                        drain(format().restoreReader(new Configuration(), restoredSplit(2))), 1))) {

            String seen = a.shape() + ": " + describe(a.emitted());
            assertEquals(1, count(a.emitted(), Line.Kind.FILE_OPEN), seen);
            assertTrue(a.emitted().get(0).isKind(Line.Kind.FILE_OPEN), seen);
            assertEquals(a.total(), a.emitted().size(), seen);
        }
    }

    // --- positions ----------------------------------------------------------------------

    /**
     * The regression guard for the position finding (invariant 2). With {@code NO_OFFSET} the
     * skip count means "restart this file from the beginning and skip N records", so a FILE_OPEN
     * claiming a record of its own would silently drop the first real line of every file on any
     * restore. It carries the split's resume position instead — which is 0 for a fresh split and
     * the restored count for a resumed one. Seeding from start-of-file instead would make a
     * reader restored at EOF checkpoint "(NO_OFFSET, 0)" and replay the whole object next time.
     */
    @Test
    void fileOpenCarriesTheSplitsResumePositionNeverOneOfItsOwn() throws Exception {
        Emitted fresh = readAll(format(), plainFile()).get(0);
        assertEquals(CheckpointedPosition.NO_OFFSET, fresh.offset());
        assertEquals(0L, fresh.skipCount(),
                "a fresh split resumes at start-of-file, so FILE_OPEN claims no record");

        Emitted restored =
                drain(format().restoreReader(new Configuration(), restoredSplit(2))).get(0);
        assertTrue(restored.isKind(Line.Kind.FILE_OPEN));
        assertEquals(CheckpointedPosition.NO_OFFSET, restored.offset());
        assertEquals(2L, restored.skipCount(),
                "a restored split resumes where it left off, not at start-of-file");
    }

    @Test
    void corruptSignalOnUnopenableFileClaimsNoRecords() throws Exception {
        java.nio.file.Path f = dir.resolve("bad.csv.gz");
        Files.writeString(f, "this is not gzip at all");
        for (Emitted e : readAll(format(), f)) {
            assertEquals(0L, e.skipCount(),
                    "nothing was read, so nothing may claim a record: " + e.record());
        }
    }

    /**
     * A mid-file CORRUPT reports the split's resume position, like every other synthetic record
     * — it does not track the rows read before the failure. The narrow cost: a checkpoint
     * landing between CORRUPT and end-of-split replays the object's readable prefix once more
     * before it is skipped again. At-least-once already permits that, and dedup downstream
     * absorbs it.
     */
    @Test
    void midFileCorruptClaimsTheSplitsResumePositionNotARecordOfItsOwn() throws Exception {
        List<Emitted> out = drain(new CorruptTolerantBulkFormat(
                new FailAfterLines(2000, new ZipException("bad crc")))
                .createReader(smallFetch(), splitFor(bigPlainFile())));

        Emitted last = out.get(out.size() - 1);
        assertTrue(last.isKind(Line.Kind.CORRUPT), "got: " + describe(out));
        assertTrue(out.stream().anyMatch(e -> e.isKind(Line.Kind.DATA)),
                "the fixture must hand up some rows before failing");
        assertEquals(CheckpointedPosition.NO_OFFSET, last.offset());
        assertEquals(0L, last.skipCount(), "a fresh split resumes at start-of-file");
    }

    // --- corruption ---------------------------------------------------------------------

    @Test
    void garbageGzipYieldsCorruptSignalInsteadOfFailing() throws Exception {
        java.nio.file.Path f = dir.resolve("bad.csv.gz");
        Files.writeString(f, "this is not gzip at all");
        List<Emitted> out = readAll(format(), f);

        assertTrue(dataOnly(out).isEmpty(), "no data can be read from it");
        assertTrue(out.get(0).isKind(Line.Kind.FILE_OPEN),
                "a file that cannot be opened was still attempted — it must count as opened");
        Emitted last = out.get(out.size() - 1);
        assertTrue(last.isKind(Line.Kind.CORRUPT));
        assertTrue(last.record().path().endsWith("bad.csv.gz"),
                "the corrupt signal must name the object so the DLQ entry can");
    }

    /** A gzip cut in half: decompresses a prefix of the rows, then throws EOFException. */
    private java.nio.file.Path truncatedGzip() throws IOException {
        StringBuilder content = new StringBuilder("id,name,value\n");
        for (int i = 0; i < 5000; i++) {
            content.append("row-").append(i).append(",name-").append(i).append(",1.0\n");
        }
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (GZIPOutputStream gz = new GZIPOutputStream(bytes)) {
            gz.write(content.toString().getBytes(StandardCharsets.UTF_8));
        }
        byte[] full = bytes.toByteArray();
        byte[] truncated = new byte[full.length / 2];
        System.arraycopy(full, 0, truncated, 0, truncated.length);
        java.nio.file.Path f = dir.resolve("truncated.csv.gz");
        Files.write(f, truncated);
        return f;
    }

    // --- structural corruption vs transient IO ------------------------------------------

    /**
     * A StreamFormat that emits {@code lines} and then fails (or ends) on demand, so the
     * IOException classification can be tested without producing a real network fault.
     * {@code onRead == null} means "clean EOF after the lines".
     */
    private record FakeStreamFormat(
            @Nullable IOException onOpen, List<String> lines, @Nullable IOException onRead)
            implements StreamFormat<String> {

        @Override
        public StreamFormat.Reader<String> createReader(
                Configuration config, FSDataInputStream stream, long fileLen, long splitEnd)
                throws IOException {
            if (onOpen != null) {
                throw onOpen;
            }
            return new StreamFormat.Reader<>() {
                private int next;

                @Override
                public String read() throws IOException {
                    if (next < lines.size()) {
                        return lines.get(next++);
                    }
                    if (onRead != null) {
                        throw onRead;
                    }
                    return null;
                }

                @Override
                public void close() {
                    // nothing to close
                }
            };
        }

        @Override
        public StreamFormat.Reader<String> restoreReader(
                Configuration config, FSDataInputStream stream, long restoredOffset,
                long fileLen, long splitEnd) throws IOException {
            return createReader(config, stream, fileLen, splitEnd);
        }

        @Override
        public boolean isSplittable() {
            return false;
        }

        @Override
        public TypeInformation<String> getProducedType() {
            return Types.STRING;
        }
    }

    /**
     * Reads the real file through the stock line format, then fails after {@code okLines}.
     *
     * <p>Delegating rather than synthesizing lines matters: {@link StreamFormatAdapter} closes
     * a batch on the underlying <em>stream position</em>, not on a record count, so a reader
     * that never advances the stream produces one enormous batch — and a failure then discards
     * every record in it, leaving nothing before the CORRUPT.
     */
    private record FailAfterLines(int okLines, IOException failure)
            implements StreamFormat<String> {

        @Override
        public StreamFormat.Reader<String> createReader(
                Configuration config, FSDataInputStream stream, long fileLen, long splitEnd)
                throws IOException {
            StreamFormat.Reader<String> inner =
                    new TextLineInputFormat().createReader(config, stream, fileLen, splitEnd);
            return new StreamFormat.Reader<>() {
                private int seen;

                @Override
                public String read() throws IOException {
                    if (seen++ >= okLines) {
                        throw failure;
                    }
                    return inner.read();
                }

                @Override
                public void close() throws IOException {
                    inner.close();
                }
            };
        }

        @Override
        public StreamFormat.Reader<String> restoreReader(
                Configuration config, FSDataInputStream stream, long restoredOffset,
                long fileLen, long splitEnd) throws IOException {
            return createReader(config, stream, fileLen, splitEnd);
        }

        @Override
        public boolean isSplittable() {
            return false;
        }

        @Override
        public TypeInformation<String> getProducedType() {
            return Types.STRING;
        }
    }

    /** Big enough that {@link #smallFetch()} closes several batches before the failure. */
    private java.nio.file.Path bigPlainFile() throws IOException {
        StringBuilder content = new StringBuilder("id,name,value\n");
        for (int i = 0; i < 5000; i++) {
            content.append("row-").append(i).append(",name-").append(i).append(",1.0\n");
        }
        java.nio.file.Path f = dir.resolve("big.csv");
        Files.writeString(f, content.toString());
        return f;
    }

    private List<Emitted> readAllThrowing(@Nullable IOException onOpen,
            @Nullable IOException onRead) throws IOException {
        return readAll(
                new CorruptTolerantBulkFormat(
                        new FakeStreamFormat(onOpen, List.of(), onRead)),
                plainFile());
    }

    @Test
    void zipExceptionOnOpenIsCorruptionAndSkipsTheFile() throws Exception {
        List<Emitted> out = readAllThrowing(new ZipException("Not in GZIP format"), null);
        assertTrue(out.get(out.size() - 1).isKind(Line.Kind.CORRUPT), describe(out) + "");
    }

    /** The realistic shape: the decompressing stream wraps the structural failure in a plain
     * IOException, so the whole cause chain has to be inspected. */
    @Test
    void zipExceptionWrappedAsACauseIsStillCorruption() throws Exception {
        List<Emitted> out = readAllThrowing(
                null, new IOException("read of s3 object failed", new ZipException("bad crc")));
        assertTrue(out.get(out.size() - 1).isKind(Line.Kind.CORRUPT), describe(out) + "");
    }

    /**
     * A transient read error must not be silently converted into a permanent skip.
     * It propagates, the task fails, Flink retries the file.
     */
    @Test
    void plainIoExceptionFromReadBatchPropagatesAndSkipsNothing() throws Exception {
        IOException transientFailure = new IOException("Connection reset by peer");
        IOException thrown = assertThrows(IOException.class,
                () -> readAllThrowing(null, transientFailure));
        assertEquals(transientFailure, thrown, "the original failure must reach the task");
    }

    @Test
    void plainIoExceptionOnOpenPropagatesAndSkipsNothing() throws Exception {
        IOException transientFailure = new IOException("503 Slow Down");
        IOException thrown = assertThrows(IOException.class,
                () -> readAllThrowing(transientFailure, null));
        assertEquals(transientFailure, thrown, "the original failure must reach the task");
    }

    /** Invariant 3: it looks like truncation, but S3A raises it for a connection reset too, and
     * a skipped object is never revisited. Propagating costs a restart and loses nothing. */
    @Test
    void eofExceptionIsTransientSoATruncatedReadIsRetriedNotSkipped() throws Exception {
        EOFException truncated = new EOFException("Unexpected end of ZLIB input stream");
        IOException thrown = assertThrows(IOException.class,
                () -> readAllThrowing(null, truncated));
        assertEquals(truncated, thrown, "the original failure must reach the task");
    }

    @Test
    void truncatedGzipPropagatesRatherThanSkippingTheObject() throws Exception {
        assertThrows(IOException.class, () -> readAll(format(), truncatedGzip()),
                "a truncated object must be retried by Flink, never silently skipped");
    }
}
