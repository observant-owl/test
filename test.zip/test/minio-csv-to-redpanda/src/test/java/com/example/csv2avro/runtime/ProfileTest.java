package com.example.csv2avro.runtime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;
import java.util.Set;
import java.util.function.UnaryOperator;
import org.apache.flink.configuration.Configuration;
import org.junit.jupiter.api.Test;

/**
 * The loader and its three derived accessors — {@code sourceS3}, {@code objectPrefix},
 * {@code producerProperties} — plus the {@code dev-local} credential fallback.
 *
 * <p><b>No shipped profile is under test</b> — every case takes its input from a {@code testing-*}
 * fixture whose values are deliberately unlike the real ones, so an assertion cannot pass by
 * coincidence and cannot go red when a deployment's placeholders are filled in. The one case that
 * <em>reads</em> a shipped profile still asserts nothing it contains; see
 * {@link #devLocalTakesItsFourCredentialsFromTheEnvironment()}.
 *
 * <p>Fixtures are named {@code <anything>-type-a.conf} rather than living in a subdirectory: the
 * loader composes {@code profiles/<env>-<type>.conf} and only the type half must be a registered
 * stream id, so the env half carries the fixture's name.
 */
class ProfileTest {

    private static final Set<String> REGISTERED = Set.of("type-a");

    /** No environment variables set — the fallback is inert everywhere but {@code dev-local}. */
    private static final UnaryOperator<String> NO_ENV = name -> null;

    private static Configuration load(String env) {
        return Profile.load(env, "type-a", REGISTERED, NO_ENV);
    }

    // --- selection ------------------------------------------------------------------------

    @Test
    void unknownEnvironmentFailsNamingTheResourceItLookedFor() {
        IllegalStateException e = assertThrows(IllegalStateException.class, () -> load("staging"));
        assertTrue(e.getMessage().contains("profiles/staging-type-a.conf"), e.getMessage());
    }

    /**
     * The type is checked before the resource is read, so a typo in the second argument says
     * what is registered rather than reporting a missing file the user never meant to name.
     */
    @Test
    void aTypeNoDefinitionClaimsFailsNamingTheRegisteredOnes() {
        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> Profile.load("testing-complete", "type-b", REGISTERED, NO_ENV));
        assertTrue(e.getMessage().contains("type-a"), e.getMessage());
        assertTrue(e.getMessage().contains("type-b"), e.getMessage());
    }

    // --- the data MinIO ---------------------------------------------------------------------

    /**
     * The split this whole arrangement exists for: the source gets its own S3 client, so the CSV
     * objects can sit on a different MinIO from checkpoints, savepoints and HA.
     */
    @Test
    void aCompleteSourceS3BlockBecomesTheSourcesOwnFilesystem() {
        S3Settings s3 = Profile.sourceS3(load("testing-complete"));

        assertNotNull(s3, "all four keys present means a dedicated client");
        assertEquals("http://fixture-minio:9000", s3.endpoint());
        assertEquals("eu-central-1", s3.region());
        assertEquals("fixture-bucket", s3.bucket());
    }

    /** Absent block = Flink's s3.* plugin, i.e. the older single-MinIO arrangement. Supported. */
    @Test
    void anAbsentSourceS3BlockFallsBackToFlinksFilesystem() {
        Configuration conf = load("testing-flink-fs");

        assertNull(Profile.sourceS3(conf),
                "no source.s3 block must mean Flink's s3.* plugin, not a failure");
        assertEquals("s3://test-bucket/type-a/", Profile.objectPrefix(conf),
                "the bucket is still needed in this mode — it is what the prefix resolves to");
    }

    /**
     * The one shape a null-tolerant record would let through silently: a block that sets the
     * endpoint and omits a credential looks configured, and would read the STATE MinIO for CSV
     * objects — an empty prefix, indistinguishable from "no new objects yet". Nothing validates
     * the profile; the record simply cannot be built, and the message names the key.
     */
    @Test
    void aPartiallySetSourceS3BlockCannotBuildAnS3Settings() {
        // load() builds the S3Settings for its startup log line, so this surfaces there —
        // during Profile.load, before anything else has read a key.
        NullPointerException e =
                assertThrows(NullPointerException.class, () -> load("testing-partial-s3"));
        assertEquals(Profile.SOURCE_S3_ACCESS_KEY.key(), e.getMessage());
    }

    // --- prefix resolution ------------------------------------------------------------------

    @Test
    void aSchemelessPrefixResolvesAgainstTheBucket() {
        assertEquals("s3://fixture-bucket/some/prefix/",
                Profile.objectPrefix(load("testing-complete")));
    }

    /**
     * One rule, no special cases — and it is what lets {@code SourceContractTest} point the job
     * at a local {@code file:} temp directory without the source needing a test-only mode.
     */
    @Test
    void aPrefixCarryingItsOwnSchemeIsUsedVerbatimAndNeedsNoBucket() {
        assertEquals("file:///tmp/csv2avro-fixture/",
                Profile.objectPrefix(load("testing-scheme-prefix")));
    }

    // --- the dev-local credential fallback --------------------------------------------------

    /**
     * The fallback is scoped to one environment on purpose. A stray CSV_SOURCE_S3_ACCESS_KEY in
     * a production pod must not quietly substitute for a key the profile is supposed to carry.
     */
    @Test
    void theEnvironmentFallbackIsInertOutsideDevLocal() {
        Configuration conf = Profile.load("testing-complete", "type-a", REGISTERED,
                Map.of(Profile.ACCESS_KEY_ENV, "leaked-from-the-environment")::get);

        assertEquals("fixture-access-key", conf.get(Profile.SOURCE_S3_ACCESS_KEY),
                "outside dev-local the profile's key wins, and the variable is not consulted");
    }

    /**
     * The firing half, and <b>the one test that reads a shipped profile</b> — unavoidably so: the
     * fallback keys off {@code Profile.LOCAL_ENV}, which resolves {@code dev-local-type-a.conf},
     * and shadowing that name from src/test/resources would be a far worse trap than this
     * exception.
     *
     * <p>It cannot go red when the placeholders are filled in, because it asserts nothing the
     * profile contains. It asserts what the profile must <em>not</em> contain: all four of these
     * keys are absent there on purpose, so if one is ever added — a credential committed into the
     * jar — the variable stops winning and this fails. That is the regression worth catching.
     */
    @Test
    void devLocalTakesItsFourCredentialsFromTheEnvironment() {
        Map<String, String> env = Map.of(
                Profile.ACCESS_KEY_ENV, "ak-from-env",
                Profile.SECRET_KEY_ENV, "sk-from-env",
                Profile.SASL_JAAS_ENV, "jaas-from-env",
                Profile.REGISTRY_USER_INFO_ENV, "user:info-from-env");

        Configuration conf = Profile.load(Profile.LOCAL_ENV, "type-a", REGISTERED, env::get);

        assertEquals("ak-from-env", conf.get(Profile.SOURCE_S3_ACCESS_KEY));
        assertEquals("sk-from-env", conf.get(Profile.SOURCE_S3_SECRET_KEY));
        assertEquals("jaas-from-env", conf.get(Profile.SASL_JAAS_CONFIG));
        assertEquals("user:info-from-env", conf.get(Profile.REGISTRY_USER_INFO));
    }

    /**
     * A laptop run with no {@code .env} sourced. The fallback writes nothing, so the key stays
     * absent and {@code S3Settings} refuses to build — at startup, naming the key, rather than
     * later as an empty prefix that reads like "no new objects yet".
     *
     * <p>{@code run-local.sh} pre-checks all four variables before launching, so in practice this
     * is the second line of defence. It is the one that survives someone running the jar directly.
     */
    @Test
    void devLocalWithNoEnvironmentFailsAtStartupNamingTheMissingKey() {
        NullPointerException e = assertThrows(NullPointerException.class,
                () -> Profile.load(Profile.LOCAL_ENV, "type-a", REGISTERED, NO_ENV));

        assertEquals(Profile.SOURCE_S3_ACCESS_KEY.key(), e.getMessage(),
                "an unset variable must not quietly become an empty credential either");
    }

    // --- the two open namespaces ------------------------------------------------------------

    /**
     * A Kafka producer and a Schema Registry client are configured separately, and neither
     * tolerates the other's keys. The prefixes are one segment apart, so a prefix view built on
     * the wrong string sweeps in the other's — silently, since both clients ignore what they do
     * not recognise. The failure would surface as a 401 on the first record.
     */
    @Test
    void theProducerAndRegistryNamespacesDoNotLeakIntoEachOther() {
        Configuration conf = load("testing-complete");

        Map<String, String> producer = Profile.producerProperties(conf);
        assertEquals("zstd", producer.get("compression.type"));
        assertEquals("50", producer.get("linger.ms"));
        assertEquals(2, producer.size(),
                "the registry's keys must not reach the producer: " + producer);

        Map<String, String> registry = Profile.registryProperties(conf);
        assertEquals("USER_INFO", registry.get("basic.auth.credentials.source"));
        assertEquals(1, registry.size(),
                "a producer property must not reach the registry client: " + registry);
    }

    // --- conversions and logging ------------------------------------------------------------

    /**
     * Not validation — {@code ParserSettings} needs a {@code char} and there is none to return.
     * It names the key because the alternative message, from deep inside opencsv, would not.
     */
    @Test
    void singleCharRefusesAValueThatIsNotExactlyOneCharacter() {
        Configuration conf = new Configuration();
        conf.set(Profile.DELIMITER, "");

        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> Profile.singleChar(conf, Profile.DELIMITER));
        assertTrue(e.getMessage().contains(Profile.DELIMITER.key()), e.getMessage());
    }

    /**
     * {@code load} logs the effective configuration at startup and this record is part of that
     * line, so an unmasked {@code toString} puts a MinIO secret into the JobManager log. The
     * generated record accessor would do exactly that — this pins the hand-written override.
     */
    @Test
    void s3SettingsNeverPrintsEitherCredential() {
        String printed = Profile.sourceS3(load("testing-complete")).toString();

        assertFalse(printed.contains("fixture-access-key"), printed);
        assertFalse(printed.contains("fixture-secret-key"), printed);
        assertTrue(printed.contains("fixture-bucket"),
                "the non-secret fields are the point of logging it at all");
    }
}
