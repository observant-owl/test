package com.example.csv2avro.core.avro;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.example.csv2avro.core.spi.RejectReason;
import com.example.csv2avro.core.spi.RowRejectedException;
import org.junit.jupiter.api.Test;

class ColsTest {

    @Test
    void parsesOrdinaryDoubles() throws Exception {
        assertEquals(1.5, Cols.optDouble("1.5", "value"));
        assertEquals(-0.25, Cols.optDouble(" -0.25 ", "value"), "surrounding space is trimmed");
        assertNull(Cols.optDouble(null, "value"));
        assertEquals(1.5, Cols.reqDouble("1.5", "value"));
    }

    /**
     * {@code Double.valueOf("NaN")} succeeds, so without an explicit check an undeclared "NaN"
     * sentinel would be written to Avro as a real value and poison every downstream aggregate.
     */
    @Test
    void nonFiniteValuesAreValueFormatRejects() {
        for (String v : new String[] {"NaN", "Infinity", "-Infinity"}) {
            RowRejectedException e = assertThrows(RowRejectedException.class,
                    () -> Cols.optDouble(v, "value"), v);
            assertEquals(RejectReason.VALUE_FORMAT, e.code(), v);
        }
    }

    /** reqDouble is optDouble plus a null check, so it inherits the rejection by composition. */
    @Test
    void reqDoubleInheritsTheNonFiniteRejection() {
        RowRejectedException e = assertThrows(RowRejectedException.class,
                () -> Cols.reqDouble("NaN", "value"));
        assertEquals(RejectReason.VALUE_FORMAT, e.code());
    }
}
