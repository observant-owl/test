package com.example.csv2avro;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.csv2avro.core.config.JobConfig;
import com.example.csv2avro.core.config.StreamConfig;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;

/**
 * Exercises the <b>real</b> config files in the exact stacks the FlinkDeployments pass, which
 * is the only place layer <em>order</em> is checked. {@code JobConfigTest} covers the merge
 * rules on synthetic files; this covers whether the shipped files are actually stacked in an
 * order that produces the intended values.
 *
 * <p>It matters for the repair profile above all: its layer overrides values set in earlier
 * layers, so getting the order wrong is silent — the job starts happily and reads the live
 * prefix instead of the repair one.
 */
class ConfigStackTest {

    private static final Path BASE = Path.of("config", "base.yaml");
    private static final Path DEV = Path.of("config", "env", "dev.yaml");
    private static final Path PROD = Path.of("config", "env", "prod.yaml");
    private static final Path TYPE_A = Path.of("config", "streams", "type-a.yaml");
    private static final Path REPAIR_A = Path.of("config", "repair", "repair-type-a.yaml");

    /** What k8s/overlays/prod/type-a passes. */
    private static JobConfig prodStack() {
        return JobConfig.load(List.of(BASE, PROD, TYPE_A));
    }

    /** What k8s/overlays/dev/type-a passes. */
    private static JobConfig devStack() {
        return JobConfig.load(List.of(BASE, DEV, TYPE_A));
    }

    /** What k8s/overlays/missing-files/type-a passes — one repair layer, always last. */
    private static JobConfig repairStack() {
        return JobConfig.load(List.of(BASE, PROD, TYPE_A, REPAIR_A));
    }

    @Test
    void repairStackRedirectsPrefixAndTopic() {
        StreamConfig live = prodStack().requireStream("type-a");
        StreamConfig repair = repairStack().requireStream("type-a");

        assertNotEquals(live.prefix, repair.prefix,
                "the repair run must not read the live prefix — it would replay everything");
        assertNotEquals(live.topic, repair.topic,
                "the repair run must not write the live topic");
        assertEquals("s3://BUCKET/repair/type-a/", repair.prefix);
        assertEquals("type-a.repair.v1", repair.topic);
    }

    @Test
    void repairStackInheritsTheTypeAndTheInfrastructure() {
        JobConfig live = prodStack();
        JobConfig repair = repairStack();
        StreamConfig liveA = live.requireStream("type-a");
        StreamConfig repairA = repair.requireStream("type-a");

        // A repair reads the same CSV type through the same brokers; only where-from and
        // where-to differ. If any of these ever diverge, the repair is parsing something else.
        assertEquals(liveA.expectedHeader, repairA.expectedHeader);
        assertEquals(liveA.dialect.delimiter, repairA.dialect.delimiter);
        assertEquals(liveA.dialect.charset, repairA.dialect.charset);
        assertEquals(liveA.dialect.nullTokens, repairA.dialect.nullTokens);
        assertEquals(live.kafka.bootstrapServers, repair.kafka.bootstrapServers);
        assertEquals(live.kafka.schemaRegistryUrl, repair.kafka.schemaRegistryUrl);
        assertEquals(live.dlq.topic, repair.dlq.topic,
                "repair rejects share the live DLQ topic on purpose — the job name separates "
                        + "them, see config/repair/repair-type-a.yaml");
    }

    @Test
    void repairStackTakesADistinctJobName() {
        assertNotEquals(prodStack().job.name, repairStack().job.name);
        assertEquals("csv-to-avro-missing-files", repairStack().job.name);
        // Job.jobName appends the id when exactly one stream runs, so the effective name is
        // csv-to-avro-missing-files-type-a: distinct per type and from both live jobs.
        assertEquals(List.of("type-a"), List.copyOf(repairStack().streams.keySet()));
    }

    @Test
    void repairLayerOrderIsLoadBearing() {
        // The one ordering rule left: the repair layer must come after the stream layer whose
        // values it replaces. Put it first and nothing fails — it just reads the live prefix
        // and replays production.
        JobConfig wrong = JobConfig.load(List.of(BASE, PROD, REPAIR_A, TYPE_A));
        assertEquals(prodStack().requireStream("type-a").prefix,
                wrong.requireStream("type-a").prefix,
                "if this ever stops matching the live prefix, the ordering hazard is gone and "
                        + "this test can go with it");
    }

    /**
     * {@code configMapGenerator} flattens paths to basenames, so two config files sharing one
     * would silently overwrite each other in the mount and a deployment would read the wrong
     * layer under the right name. Distinct basenames are what make the {@code key=path}
     * workaround unnecessary — this keeps them distinct.
     */
    @Test
    void everyConfigFileHasAUniqueBasename() throws Exception {
        Map<String, Path> byName = new HashMap<>();
        try (Stream<Path> files = Files.walk(Path.of("config"))) {
            for (Path p : files.filter(f -> f.getFileName().toString().endsWith(".yaml"))
                    .sorted().toList()) {
                Path clash = byName.put(p.getFileName().toString(), p);
                assertNull(clash, "config files share the basename '" + p.getFileName()
                        + "': " + clash + " and " + p + " — configMapGenerator flattens paths, "
                        + "so one would silently overwrite the other in the mount");
            }
        }
    }

    /**
     * Each environment's job name must agree with its FlinkDeployment's {@code metadata.name},
     * because {@code Job.jobName} appends {@code -<streamId>} to it. When they disagree, every
     * {@code job_name}-labelled metric points at a name nobody can find with {@code kubectl}.
     */
    @Test
    void jobNameMatchesTheDeploymentName() throws Exception {
        assertEquals(deploymentName("prod"), prodStack().job.name + "-type-a");
        assertEquals(deploymentName("dev"), devStack().job.name + "-type-a");
        assertEquals(deploymentName("missing-files"), repairStack().job.name + "-type-a");
    }

    /**
     * Every {@code --config} path in every overlay must name a file that the base
     * {@code configMapGenerator} actually ships, and that file must exist on disk.
     *
     * <p>The mount is keyed by flattened basename, so these three lists — the args, the
     * generator, and {@code config/} itself — are coupled by nothing but convention. Moving or
     * renaming a config file silently breaks a deployment at startup otherwise, and there is no
     * kustomize on this machine to catch it at build time.
     */
    @Test
    void everyOverlayArgResolvesToAShippedConfigFile() throws Exception {
        String generator = Files.readString(Path.of("k8s", "base", "kustomization.yaml"));
        Map<String, Path> onDisk = new HashMap<>();
        try (Stream<Path> files = Files.walk(Path.of("config"))) {
            files.filter(f -> f.getFileName().toString().endsWith(".yaml"))
                    .forEach(f -> onDisk.put(f.getFileName().toString(), f));
        }

        try (Stream<Path> overlays = Files.walk(Path.of("k8s", "overlays"))) {
            for (Path k : overlays
                    .filter(f -> f.getFileName().toString().equals("kustomization.yaml"))
                    .sorted().toList()) {
                Matcher m = Pattern.compile("/opt/csv2avro/config/(\\S+\\.yaml)")
                        .matcher(Files.readString(k));
                while (m.find()) {
                    String name = m.group(1);
                    assertTrue(onDisk.containsKey(name),
                            k + " passes --config " + name + ", but no such file exists under "
                                    + "config/ (have: " + onDisk.keySet() + ")");
                    assertTrue(generator.contains("/" + name),
                            k + " passes --config " + name + ", but k8s/base/kustomization.yaml "
                                    + "does not ship it in the ConfigMap");
                }
            }
        }
    }

    /** The reverse direction: a config file nobody ships is a file no deployment can read. */
    @Test
    void everyConfigFileIsShippedInTheConfigMap() throws Exception {
        String generator = Files.readString(Path.of("k8s", "base", "kustomization.yaml"));
        try (Stream<Path> files = Files.walk(Path.of("config"))) {
            for (Path p : files.filter(f -> f.getFileName().toString().endsWith(".yaml"))
                    .sorted().toList()) {
                assertTrue(generator.contains("/" + p.getFileName()),
                        p + " is not listed in k8s/base/kustomization.yaml, so no deployment "
                                + "can read it");
            }
        }
    }

    private static String deploymentName(String overlay) throws Exception {
        String kustomization = Files.readString(
                Path.of("k8s", "overlays", overlay, "type-a", "kustomization.yaml"));
        Matcher m = Pattern.compile("path: /metadata/name\\s*\\n\\s*value: (\\S+)")
                .matcher(kustomization);
        assertTrue(m.find(), "no /metadata/name patch in the " + overlay + " type-a overlay");
        return m.group(1);
    }
}
