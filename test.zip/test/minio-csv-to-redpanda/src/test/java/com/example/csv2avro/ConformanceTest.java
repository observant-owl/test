package com.example.csv2avro;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import com.example.csv2avro.core.config.JobConfig;
import com.example.csv2avro.core.config.StreamConfig;
import com.example.csv2avro.core.csv.LineParser;
import com.example.csv2avro.core.csv.ParserSettings;
import com.example.csv2avro.core.format.Line;
import com.example.csv2avro.core.spi.CsvStreamDefinition;
import com.example.csv2avro.streams.Streams;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import org.apache.avro.specific.SpecificRecordBase;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

/**
 * The conformance harness: every stream in {@code Streams.ALL} must ship a fixture
 * ({@code src/test/resources/fixtures/<id>/input.csv} + {@code expected.json}) and reproduce it
 * exactly through parse + map. A new type is automatically covered — or fails loudly here for a
 * missing fixture. Dialect and expected header come from the real config files, so the fixture
 * also validates the config block.
 *
 * <p>Loads the same layered stack a deployment does — {@code base.yaml} + {@code env/dev.yaml}
 * + <b>every</b> {@code streams/*.yaml}, rather than one type's — because this test iterates
 * all registered definitions and needs all of their blocks populated. Running all of them at
 * once is fine here: no source is ever built, only the parser and the mapper run. Do not
 * "simplify" this to call {@code Sources}. The repair layers are deliberately not in this
 * stack — they only swap a prefix and a topic, neither of which parsing touches;
 * {@code ConfigStackTest} covers them.
 */
class ConformanceTest {

    private static final ObjectMapper JSON = new ObjectMapper();

    @TestFactory
    List<DynamicTest> everyRegisteredStreamReproducesItsFixture() throws Exception {
        JobConfig cfg = JobConfig.load(layeredConfig());
        List<DynamicTest> tests = Streams.ALL.stream()
                .map(def -> DynamicTest.dynamicTest(def.id(), () -> runOne(cfg, def)))
                .toList();
        assertTrue(!tests.isEmpty(), "Streams.ALL is empty — the job would run nothing");
        return tests;
    }

    /** base + dev env + every stream layer, in merge order. */
    private static List<Path> layeredConfig() throws Exception {
        List<Path> layers = new ArrayList<>();
        layers.add(Path.of("config", "base.yaml"));
        layers.add(Path.of("config", "env", "dev.yaml"));
        try (Stream<Path> streamFiles = Files.list(Path.of("config", "streams"))) {
            streamFiles.filter(p -> p.getFileName().toString().endsWith(".yaml"))
                    .sorted()
                    .forEach(layers::add);
        }
        return layers;
    }

    private <T extends SpecificRecordBase> void runOne(JobConfig cfg, CsvStreamDefinition<T> def)
            throws Exception {
        Path fixtureDir = Path.of("src", "test", "resources", "fixtures", def.id());
        Path input = fixtureDir.resolve("input.csv");
        Path expected = fixtureDir.resolve("expected.json");
        assertTrue(Files.isRegularFile(input),
                "missing fixture " + input + " — every stream definition must ship one");
        assertTrue(Files.isRegularFile(expected), "missing fixture " + expected);

        StreamConfig sc = cfg.requireStream(def.id());
        // Built through the same ParserSettings wiring production uses, so the harness cannot
        // drift from what the job actually constructs (a hand-rolled copy here once did).
        LineParser parser = ParserSettings.of(sc, def.id()).newParser();

        ArrayNode actual = JSON.createArrayNode();
        String object = input.toString();
        for (String line : Files.readAllLines(input, Charset.forName(sc.dialect.charset))) {
            LineParser.Outcome o = parser.parse(Line.data(line, object, 0L, 0L));
            switch (o.kind) {
                case ROW -> {
                    // null = the mapper deliberately dropped the row (RowMapper contract), so
                    // it contributes no entry — which makes every fixture that includes a
                    // filtered row an automatic test of that filter.
                    T record = def.mapper().map(o.row);
                    if (record != null) {
                        actual.add(JSON.readTree(record.toString()));
                    }
                }
                case HEADER, BLANK -> { /* dropped, as in production */ }
                case REJECT -> fail("fixture line rejected (" + o.code + " / " + o.reason
                        + "): " + line);
                // Unreachable: the harness only ever feeds Line.Kind.DATA. Listed explicitly
                // because this is a switch *statement*, so Java would not force us to handle
                // new kinds — it would silently ignore them.
                case CORRUPT, FILE_OPEN -> fail("fixture produced a file signal: " + line);
            }
        }

        JsonNode expectedTree = JSON.readTree(Files.readAllBytes(expected));
        assertEquals(expectedTree, actual,
                "stream '" + def.id() + "': mapper output diverges from expected.json");
    }
}
