package com.example.csv2avro;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import com.example.csv2avro.api.CsvStreamDefinition;
import com.example.csv2avro.runtime.CsvConfig;
import com.example.csv2avro.runtime.Line;
import com.example.csv2avro.runtime.LineParser;
import com.example.csv2avro.runtime.ParserSettings;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.flink.configuration.Configuration;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

/**
 * The conformance harness: every stream in {@code Streams.ALL} must ship a fixture
 * ({@code src/test/resources/fixtures/<id>/input.csv} + {@code expected.json}) and reproduce it
 * exactly through parse + map. A new type is automatically covered — or fails loudly here for a
 * missing fixture. Dialect and expected header come from the real profile resources, so the
 * fixture also validates that type's profile.
 *
 * <p>Loads the type's real {@code dev-<id>.conf}, so the fixture is parsed with the dialect and
 * header a deployment actually runs. No source is ever built here, only the parser and the
 * mapper — do not "simplify" this to call {@code Sources}. The prod and repair files are
 * deliberately not used: they differ only in prefix, topic and brokers, none of which parsing
 * touches, and {@code CsvConfigTest} covers them.
 */
class ConformanceTest {

    private static final ObjectMapper JSON = new ObjectMapper();

    @TestFactory
    List<DynamicTest> everyRegisteredStreamReproducesItsFixture() {
        List<DynamicTest> tests = Streams.ALL.stream()
                .map(def -> DynamicTest.dynamicTest(def.id(), () -> runOne(def)))
                .toList();
        assertTrue(!tests.isEmpty(), "Streams.ALL is empty — the job would run nothing");
        return tests;
    }

    /** The type's dev deployment, whose file carries the dialect and header the fixture is
     * parsed with. Every type ships one, so this convention is also what makes a new type's
     * configuration exercised here automatically. */
    private static Configuration configFor(CsvStreamDefinition<?> def) {
        return CsvConfig.load(
                Configuration.fromMap(Map.of(CsvConfig.CONFIG.key(), "dev-" + def.id())),
                Streams.ALL.stream().map(CsvStreamDefinition::id).collect(Collectors.toSet()));
    }

    private <T extends SpecificRecordBase> void runOne(CsvStreamDefinition<T> def)
            throws Exception {
        Path fixtureDir = Path.of("src", "test", "resources", "fixtures", def.id());
        Path input = fixtureDir.resolve("input.csv");
        Path expected = fixtureDir.resolve("expected.json");
        assertTrue(Files.isRegularFile(input),
                "missing fixture " + input + " — every stream definition must ship one");
        assertTrue(Files.isRegularFile(expected), "missing fixture " + expected);

        Configuration conf = configFor(def);
        // Built through the same ParserSettings wiring production uses, so the harness cannot
        // drift from what the job actually constructs (a hand-rolled copy here once did).
        LineParser parser = ParserSettings.of(conf, def.id()).newParser();

        ArrayNode actual = JSON.createArrayNode();
        String object = input.toString();
        for (String line : Files.readAllLines(input,
                Charset.forName(conf.get(CsvConfig.CHARSET)))) {
            LineParser.Outcome o = parser.parse(Line.data(line, object, 0L, 0L));
            switch (o.kind) {
                case ROW -> {
                    // null = the mapper deliberately dropped the row (RowMapper contract), so
                    // it contributes no entry — which makes every fixture that includes a
                    // filtered row an automatic test of that filter.
                    T record = def.mapper().map(o.row);
                    if (record != null) {
                        actual.add(JSON.readTree(record.toString()));
                    }
                }
                case HEADER, BLANK -> { /* dropped, as in production */ }
                case REJECT -> fail("fixture line rejected (" + o.code + " / " + o.reason
                        + "): " + line);
                // Unreachable: the harness only ever feeds Line.Kind.DATA. Listed explicitly
                // because this is a switch *statement*, so Java would not force us to handle
                // new kinds — it would silently ignore them.
                case CORRUPT, FILE_OPEN -> fail("fixture produced a file signal: " + line);
            }
        }

        JsonNode expectedTree = JSON.readTree(Files.readAllBytes(expected));
        assertEquals(expectedTree, actual,
                "stream '" + def.id() + "': mapper output diverges from expected.json");
    }
}
