package com.example.csv2avro;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import com.example.csv2avro.core.config.JobConfig;
import com.example.csv2avro.core.config.StreamConfig;
import com.example.csv2avro.core.csv.LineParser;
import com.example.csv2avro.core.spi.CsvStreamDefinition;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.ServiceLoader;
import org.apache.avro.specific.SpecificRecordBase;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

/**
 * The conformance harness: every ServiceLoader-discovered stream definition must ship a
 * fixture ({@code src/test/resources/fixtures/<id>/input.csv} + {@code expected.json}) and
 * reproduce it exactly through parse + map. A new type is automatically covered — or fails
 * loudly here for a missing fixture. Dialect and expected header come from
 * {@code config/dev.yaml}, so the fixture also validates the config block.
 */
class ConformanceTest {

    private static final ObjectMapper JSON = new ObjectMapper();

    @TestFactory
    @SuppressWarnings("unchecked") // the one allowed raw ServiceLoader boundary
    List<DynamicTest> everyDiscoveredStreamReproducesItsFixture() {
        JobConfig cfg = JobConfig.load(Path.of("config", "dev.yaml"));
        List<DynamicTest> tests = ServiceLoader.load(CsvStreamDefinition.class).stream()
                .map(ServiceLoader.Provider::get)
                .map(def -> DynamicTest.dynamicTest(def.id(), () -> runOne(cfg, def)))
                .toList();
        assertTrue(!tests.isEmpty(), "no stream definitions discovered via ServiceLoader");
        return tests;
    }

    private <T extends SpecificRecordBase> void runOne(JobConfig cfg, CsvStreamDefinition<T> def)
            throws Exception {
        Path fixtureDir = Path.of("src", "test", "resources", "fixtures", def.id());
        Path input = fixtureDir.resolve("input.csv");
        Path expected = fixtureDir.resolve("expected.json");
        assertTrue(Files.isRegularFile(input),
                "missing fixture " + input + " — every stream definition must ship one");
        assertTrue(Files.isRegularFile(expected), "missing fixture " + expected);

        StreamConfig sc = cfg.requireStream(def.id());
        LineParser parser = new LineParser(
                def.id(), sc.expectedHeader,
                sc.dialect.delimiterChar(), sc.dialect.quoteChar(), sc.dialect.escapeChar(),
                new HashSet<>(sc.dialect.nullTokens), true);

        ArrayNode actual = JSON.createArrayNode();
        for (String line : Files.readAllLines(input, Charset.forName(sc.dialect.charset))) {
            LineParser.Outcome o = parser.parse(line);
            switch (o.kind) {
                case ROW -> actual.add(JSON.readTree(def.mapper().map(o.row).toString()));
                case HEADER, BLANK -> { /* dropped, as in production */ }
                case REJECT -> fail("fixture line rejected (" + o.code + " / " + o.reason
                        + "): " + line);
                case CORRUPT -> fail("fixture contained a corrupt sentinel: " + line);
                // Listed explicitly: this is a switch *statement*, so Java would not force us
                // to handle new kinds — it would silently ignore them.
                case FILE_OPEN, FILE_DONE -> fail("fixture contained a file marker: " + line);
            }
        }

        JsonNode expectedTree = JSON.readTree(Files.readAllBytes(expected));
        assertEquals(expectedTree, actual,
                "stream '" + def.id() + "': mapper output diverges from expected.json");
    }
}
