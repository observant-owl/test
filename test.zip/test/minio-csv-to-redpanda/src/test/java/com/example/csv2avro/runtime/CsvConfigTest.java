package com.example.csv2avro.runtime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;
import java.util.Set;
import org.apache.flink.configuration.Configuration;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * Exercises the <b>real</b> configuration resources every FlinkDeployment names.
 *
 * <p>There is no layering to test: one file is the whole configuration, nothing defaults, and
 * {@code spec.flinkConfiguration} cannot override it. So what is left to check is that each
 * shipped file is complete and internally consistent, and that an incomplete one fails loudly.
 *
 * <p>There is deliberately no test that the k8s manifests name these files correctly. The
 * manifests are deployed with {@code kubectl apply -k}, which validates them; regex-scraping
 * YAML from surefire only pretends to.
 */
class CsvConfigTest {

    private static final Set<String> REGISTERED = Set.of("type-a");

    /** What a deployment's spec.flinkConfiguration carries: one key. */
    private static Configuration selection(String config) {
        return Configuration.fromMap(Map.of(CsvConfig.CONFIG.key(), config));
    }

    private static Configuration load(String config) {
        return CsvConfig.load(selection(config), REGISTERED);
    }

    // --- the shipped configurations -------------------------------------------------------

    /**
     * The load-bearing test of the whole design: since no key defaults, a file that forgets one
     * cannot start. Running every shipped file through the real validation is what turns that
     * from a claim into a guarantee — and it covers a new deployment's file automatically.
     */
    @ParameterizedTest
    @ValueSource(strings = {"dev-type-a", "prod-type-a", "missing-files-type-a"})
    void everyShippedConfigurationIsCompleteAndValid(String config) {
        assertEquals("type-a", load(config).get(CsvConfig.STREAM));
    }

    @Test
    void prodAndDevReadTheSameObjectsIntoTheSameTopic() {
        // The environments differ only in the MinIO address they reach the objects through (an
        // s3.* key in the env overlay) and the Redpanda they write to. If these ever diverge,
        // dev has stopped being a rehearsal of prod.
        assertEquals(load("prod-type-a").get(CsvConfig.SOURCE_PREFIX),
                load("dev-type-a").get(CsvConfig.SOURCE_PREFIX));
        assertEquals(load("prod-type-a").get(CsvConfig.TOPIC),
                load("dev-type-a").get(CsvConfig.TOPIC));
        assertNotEquals(load("prod-type-a").get(CsvConfig.BOOTSTRAP_SERVERS),
                load("dev-type-a").get(CsvConfig.BOOTSTRAP_SERVERS));
    }

    @Test
    void theRepairConfigurationRedirectsPrefixAndTopicButKeepsProdsBrokers() {
        Configuration live = load("prod-type-a");
        Configuration repair = load("missing-files-type-a");

        assertNotEquals(live.get(CsvConfig.SOURCE_PREFIX), repair.get(CsvConfig.SOURCE_PREFIX),
                "the repair run must not read the live prefix — it would replay everything");
        assertNotEquals(live.get(CsvConfig.TOPIC), repair.get(CsvConfig.TOPIC),
                "the repair run must not write the live topic");
        assertEquals(live.get(CsvConfig.BOOTSTRAP_SERVERS),
                repair.get(CsvConfig.BOOTSTRAP_SERVERS),
                "a repair writes to production's Redpanda");
        assertEquals(live.get(CsvConfig.DLQ_TOPIC), repair.get(CsvConfig.DLQ_TOPIC),
                "repair rejects share the live DLQ topic on purpose — entries carry the stream "
                        + "id and object key, and the job name separates them");
    }

    // --- selection ------------------------------------------------------------------------

    @Test
    void unknownConfigurationNameFailsNamingTheResource() {
        IllegalStateException e =
                assertThrows(IllegalStateException.class, () -> load("staging-type-a"));
        assertTrue(e.getMessage().contains("profiles/staging-type-a.conf"), e.getMessage());
    }

    @Test
    void missingSelectionKeyFailsAtStartup() {
        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> CsvConfig.load(new Configuration(), REGISTERED));
        assertTrue(e.getMessage().contains(CsvConfig.CONFIG.key()), e.getMessage());
    }

    @Test
    void aStreamIdNoDefinitionClaimsFailsNamingTheRegisteredOnes() {
        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> CsvConfig.load(selection("prod-type-a"), Set.of("type-b")));
        assertTrue(e.getMessage().contains("type-a"), e.getMessage());
        assertTrue(e.getMessage().contains("type-b"), e.getMessage());
    }

    // --- validation -----------------------------------------------------------------------

    /**
     * Every gap named at once: one restart per deployment, not one per mistake. This is also
     * what makes a typo'd key loud — a mistyped {@code csv2avro.dialect.charsett} is reported
     * as {@code csv2avro.dialect.charset} missing, because nothing defaults.
     */
    @Test
    void anIncompleteConfigurationNamesEveryMissingKeyAtOnce() {
        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> load("testing/incomplete"));

        String message = e.getMessage();
        assertTrue(message.contains(CsvConfig.TOPIC.key()), message);
        assertTrue(message.contains(CsvConfig.EXPECTED_HEADER.key()), message);
        assertTrue(message.contains(CsvConfig.BOOTSTRAP_SERVERS.key()), message);
        assertTrue(message.contains(CsvConfig.SCHEMA_REGISTRY_URL.key()), message);
        assertTrue(message.contains(CsvConfig.DLQ_TOPIC.key()), message);
        assertTrue(message.contains(CsvConfig.CHARSET.key()), message);
    }

    /**
     * An unparseable typed value must be collected like any other error, not thrown from the
     * getter — otherwise the first bad duration hides every remaining mistake in the file.
     */
    @Test
    void anUnparseableValueIsCollectedAlongsideTheOtherErrors() {
        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> load("testing/bad-values"));

        String message = e.getMessage();
        assertTrue(message.contains(CsvConfig.MONITOR_INTERVAL.key()), message);
        assertTrue(message.contains(CsvConfig.DELIMITER.key()),
                "a multi-character delimiter must be reported too, not hidden by the duration: "
                        + message);
        assertTrue(message.contains("UTF-9"), message);
    }

    @Test
    void aNonPositivePollIntervalIsABusyLoopAndFails() {
        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> load("testing/zero-interval"));
        assertTrue(e.getMessage().contains(CsvConfig.MONITOR_INTERVAL.key()), e.getMessage());
    }

    // --- dialect --------------------------------------------------------------------------

    /**
     * Flink's list syntax quotes, so {@code ''} is an empty element — which is why there is no
     * separate "empty is null" flag. This is the assertion that pins that.
     */
    @Test
    void quotedEmptyStringIsANullTokenLikeAnyOther() {
        ParserSettings settings = ParserSettings.of(load("prod-type-a"), "type-a");

        assertEquals(Set.of("", "NULL"), settings.nullTokens());
        assertEquals(',', settings.delimiter());
        assertEquals('"', settings.quote());
        assertNull(settings.escape(), "absent escape = RFC 4180 doubled quotes");
    }

    @Test
    void producerPropertiesAreCollectedByPrefix() {
        assertEquals("zstd",
                CsvConfig.producerProperties(load("prod-type-a")).get("compression.type"));
    }

    // --- job name -------------------------------------------------------------------------

    /**
     * The job name is the {@code job_name} label on every metric, and it comes from the id the
     * operator derives from {@code metadata.name} — so it cannot name a deployment that
     * {@code kubectl} has never heard of. Nothing in a configuration file can set it.
     */
    @Test
    void jobNameComesFromTheOperatorsClusterIdAndFallsBackOutsideKubernetes() {
        Configuration withOperator = selection("prod-type-a");
        withOperator.setString("kubernetes.cluster-id", "csv-to-avro-prod-type-a");

        assertEquals("csv-to-avro-prod-type-a", CsvConfig.jobName(withOperator, "type-a"));
        assertEquals("csv2avro-type-a", CsvConfig.jobName(new Configuration(), "type-a"));
    }
}
