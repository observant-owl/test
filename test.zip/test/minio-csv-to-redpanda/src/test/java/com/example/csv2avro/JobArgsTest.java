package com.example.csv2avro;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;

/**
 * The command line is written once into a FlinkDeployment manifest and never typed
 * interactively, so nobody ever sees a warning about it. Every one of these cases would
 * otherwise mean a job that starts with the wrong config stack and looks healthy.
 */
class JobArgsTest {

    @Test
    void singleConfigIsAccepted() {
        assertEquals(List.of(Path.of("config/base.yaml")),
                Job.Args.parse(new String[] {"--config", "config/base.yaml"}).configPaths());
    }

    /** Order is the merge order, so it must survive parsing exactly as written. */
    @Test
    void repeatedConfigsKeepTheirOrder() {
        Job.Args args = Job.Args.parse(new String[] {
            "--config", "base.yaml",
            "--config", "env/prod.yaml",
            "--config", "streams/type-a.yaml",
        });
        assertEquals(
                List.of(Path.of("base.yaml"), Path.of("env/prod.yaml"),
                        Path.of("streams/type-a.yaml")),
                args.configPaths());
    }

    @Test
    void missingConfigFails() {
        IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
                () -> Job.Args.parse(new String[] {}));
        assertTrue(e.getMessage().contains("--config"), e.getMessage());
    }

    /**
     * The important one: a typo'd or leftover flag must stop the job rather than be skipped.
     * Silently ignoring it is how a deployment ends up running the base layer alone.
     */
    @Test
    void unknownTokenFails() {
        assertThrows(IllegalArgumentException.class, () -> Job.Args.parse(new String[] {
            "--config", "base.yaml", "--stream", "type-a",
        }));
        assertThrows(IllegalArgumentException.class, () -> Job.Args.parse(new String[] {
            "base.yaml",
        }));
        assertThrows(IllegalArgumentException.class, () -> Job.Args.parse(new String[] {
            "--conifg", "base.yaml",
        }));
    }

    /** A trailing --config must not be read as "zero layers, that's fine". */
    @Test
    void configWithoutAValueFails() {
        IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
                () -> Job.Args.parse(new String[] {"--config", "base.yaml", "--config"}));
        assertTrue(e.getMessage().contains("needs a value"), e.getMessage());
    }
}
