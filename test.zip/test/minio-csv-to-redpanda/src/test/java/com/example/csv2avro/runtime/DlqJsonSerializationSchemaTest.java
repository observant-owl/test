package com.example.csv2avro.runtime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The DLQ payload's wire shape — the only artefact of a rejected row anyone reads by hand, and
 * one that breaks quietly: a renamed field still serializes and still produces into Kafka.
 * Jackson binds a {@code record} through its canonical constructor, so reordering or renaming a
 * {@link DlqRecord} component silently rewrites this JSON.
 */
class DlqJsonSerializationSchemaTest {

    private static final ObjectMapper JSON = new ObjectMapper();

    private DlqJsonSerializationSchema schema;

    @BeforeEach
    void setUp() {
        schema = new DlqJsonSerializationSchema();
        // The mapper is transient and built in open(), because Flink ships the schema to the task
        // serialized. Skipping this in a test would pass for the wrong reason.
        schema.open(null);
    }

    private JsonNode serialize(DlqRecord record) throws Exception {
        return JSON.readTree(new String(schema.serialize(record), StandardCharsets.UTF_8));
    }

    @Test
    void aRowLevelEntryCarriesEveryFieldUnderItsDocumentedName() throws Exception {
        JsonNode json = serialize(new DlqRecord(
                "type-a", "column-count: expected 3, got 2", "a1,Alice",
                "s3://bucket/type-a/x.csv.gz", 1_700_000_000_000L));

        assertEquals("type-a", json.get("streamId").asText());
        assertEquals("column-count: expected 3, got 2", json.get("reason").asText());
        assertEquals("a1,Alice", json.get("rawLine").asText());
        assertEquals("s3://bucket/type-a/x.csv.gz", json.get("objectKey").asText());
        assertEquals(1_700_000_000_000L, json.get("timestamp").asLong());
        assertEquals(5, json.size(), "an unexpected field appeared: " + json);
    }

    /**
     * A corrupt-file entry has no row. The field must still be present and null rather than
     * omitted — a consumer distinguishing file-level from row-level entries reads it either way,
     * and an absent key and a null one are not the same thing to most JSON parsers.
     */
    @Test
    void aFileLevelEntryKeepsRawLineAsAnExplicitNull() throws Exception {
        JsonNode json = serialize(DlqRecord.of(
                "type-a", "corrupt-file: not gzip", null, "s3://bucket/type-a/x.csv.gz"));

        assertTrue(json.has("rawLine"), "the field must be present, not omitted: " + json);
        assertTrue(json.get("rawLine").isNull(), json.toString());
    }

    /**
     * The raw line is arbitrary bytes from someone else's file, so it is the field most likely to
     * carry something that breaks a naive encoder. It must be escaped, not dropped or mangled.
     */
    @Test
    void aRawLineContainingQuotesNewlinesAndNonAsciiSurvivesIntact() throws Exception {
        String nasty = "a1,\"He said \"\"hi\"\"\",naïve\ttab\\slash";
        JsonNode json = serialize(DlqRecord.of("type-a", "malformed-csv", nasty, "s3://b/x"));

        assertEquals(nasty, json.get("rawLine").asText());
    }

    /** Serializing before open() is a wiring bug, and it must not be mistaken for bad data. */
    @Test
    void serializingBeforeOpenFailsRatherThanProducingNothing() {
        assertThrows(NullPointerException.class,
                () -> new DlqJsonSerializationSchema().serialize(
                        DlqRecord.of("type-a", "reason", "line", "object")));
    }

    /** {@code of} is what production calls; the timestamp it stamps must reach the payload. */
    @Test
    void theFactoryStampsAWallClockTimestamp() throws Exception {
        long before = System.currentTimeMillis();
        JsonNode json = serialize(DlqRecord.of("type-a", "reason", "line", "object"));
        long after = System.currentTimeMillis();

        long stamped = json.get("timestamp").asLong();
        assertTrue(stamped >= before && stamped <= after,
                "timestamp " + stamped + " outside [" + before + ", " + after + "]");
    }
}
