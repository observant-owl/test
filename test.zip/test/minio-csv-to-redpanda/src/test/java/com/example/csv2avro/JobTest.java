package com.example.csv2avro;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

/**
 * The one thing {@link Job#main} decides before any Flink API is touched: which profile to read.
 * Everything after that is {@code assemble}, which {@code JobGraphTest} covers.
 */
class JobTest {

    static Stream<Arguments> wrongArgumentCounts() {
        // Each String[] is one argv, so it has to be wrapped — JUnit would otherwise spread it
        // across the parameter list.
        return Stream.of(
                Arguments.of((Object) new String[] {}),
                Arguments.of((Object) new String[] {"prod"}),
                Arguments.of((Object) new String[] {"prod", "type-a", "extra"}));
    }

    /**
     * Silently ignoring a missing or leftover argument is how a deployment ends up running a
     * configuration nobody chose — one kustomize layer forgetting its argument must fail here,
     * not start something plausible. The guard runs before any Flink API, which is what makes
     * this testable without a cluster.
     */
    @ParameterizedTest
    @MethodSource("wrongArgumentCounts")
    void anyArgumentCountButTwoFailsNamingBoth(String[] argv) {
        Exception e = assertThrows(IllegalArgumentException.class, () -> Job.main(argv));
        assertTrue(e.getMessage().contains("<env> <type>"), e.getMessage());
    }
}
