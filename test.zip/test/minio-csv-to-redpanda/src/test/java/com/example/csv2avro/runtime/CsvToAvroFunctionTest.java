package com.example.csv2avro.runtime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.csv2avro.api.CsvStreamDefinition;
import com.example.csv2avro.api.RejectReason;
import com.example.csv2avro.api.RowMapper;
import com.example.csv2avro.api.RowRejectedException;
import com.example.csv2avro.generated.TypeA;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.TimerService;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The routing nobody else covers: which outcome goes to the main output, which to the DLQ side
 * output, which is silently dropped, and which counter each increments.
 *
 * <p>{@code LineParserTest} pins how a line is classified and {@code StreamMetricsTest} pins how
 * counters are named, but between them sat the operator's central claim — <b>every line is
 * accounted for exactly once, so "rows that vanished" is unreachable</b> — with no test at all.
 * That claim is a statement about this class.
 */
class CsvToAvroFunctionTest {

    private static final String OBJECT = "s3://bucket/type-a/x.csv.gz";
    private static final String BASE = "csv2avro.stream";

    private final OutputTag<DlqRecord> dlqTag =
            new OutputTag<>("type-a-dlq", TypeInformation.of(DlqRecord.class));

    private RecordingMetricGroup metrics;
    private List<TypeA> emitted;
    private List<DlqRecord> dlq;

    @BeforeEach
    void setUp() {
        metrics = new RecordingMetricGroup();
        emitted = new ArrayList<>();
        dlq = new ArrayList<>();
    }

    /** The real prod configuration, so the dialect under test is the one that ships. */
    private static Configuration config() {
        return CsvConfig.load(
                Configuration.fromMap(Map.of(CsvConfig.CONFIG.key(), "prod-type-a")),
                Set.of("type-a"));
    }

    private CsvToAvroFunction<TypeA> function(RowMapper<TypeA> mapper) {
        CsvToAvroFunction<TypeA> fn = new CsvToAvroFunction<>(config(),
                new CsvStreamDefinition<>("type-a", TypeA.class, mapper), dlqTag);
        fn.initialize(metrics);
        return fn;
    }

    /** The stock mapper: id required, name and value optional. */
    private CsvToAvroFunction<TypeA> function() {
        return function(row -> TypeA.newBuilder()
                .setId(row.require("id"))
                .setName(row.get("name"))
                .setValue(row.get("value") == null ? null : Double.valueOf(row.get("value")))
                .build());
    }

    private void feed(CsvToAvroFunction<TypeA> fn, Line line) {
        fn.processElement(line, context(fn), collector());
    }

    private static Line data(String text) {
        return Line.data(text, OBJECT, 1_700_000_000_000L, 4096);
    }

    private long counter(String name) {
        return metrics.counterAt(BASE + "." + name).getCount();
    }

    private long rejected(RejectReason reason) {
        return metrics.counterAt(BASE + ".reason.rowsRejected",
                Map.of("reason", reason.label())).getCount();
    }

    // --- the four destinations -------------------------------------------------------------

    @Test
    void aGoodRowGoesToTheMainOutputAndNowhereElse() {
        feed(function(), data("a1,Alice,3.5"));

        assertEquals(1, emitted.size());
        assertEquals("a1", emitted.get(0).getId());
        assertTrue(dlq.isEmpty(), "a good row must not also reach the DLQ");
        assertEquals(1, counter("recordsOut"));
    }

    @Test
    void aRejectedRowGoesToTheDlqWithItsRawLineAndObjectAndNotToKafka() {
        feed(function(), data("a1,Alice"));   // two fields, three columns

        assertTrue(emitted.isEmpty(), "a rejected row must never reach the topic");
        assertEquals(1, dlq.size());
        assertEquals("a1,Alice", dlq.get(0).rawLine);
        assertEquals(OBJECT, dlq.get(0).objectKey,
                "a rejected row three-quarters through an object must still name that object");
        assertEquals("type-a", dlq.get(0).streamId);
        assertEquals(1, rejected(RejectReason.COLUMN_COUNT));
        assertEquals(0, counter("recordsOut"));
    }

    /**
     * The DLQ payload must carry the same reason label the Prometheus counter does, or the two
     * signals disagree about the same row.
     */
    @Test
    void theDlqReasonIsPrefixedWithTheBoundedLabel() {
        feed(function(), data("a1,Alice"));

        assertTrue(dlq.get(0).reason.startsWith(RejectReason.COLUMN_COUNT.label() + ":"),
                "reason was: " + dlq.get(0).reason);
    }

    /** A mapper returning null is a deliberate filter, not an error: counted, written nowhere. */
    @Test
    void aDroppedRowIsCountedAndWritesNothingAnywhere() {
        feed(function(row -> null), data("a1,Alice,3.5"));

        assertTrue(emitted.isEmpty());
        assertTrue(dlq.isEmpty(), "a drop must not look like a reject — it would skew the alert");
        assertEquals(1, counter("rowsDropped"));
        assertEquals(0, counter("recordsOut"));
    }

    @Test
    void aRowRejectedExceptionFromTheMapperCountsUnderItsOwnReason() {
        feed(function(row -> {
            throw new RowRejectedException(RejectReason.MAPPER_OTHER, "nope");
        }), data("a1,Alice,3.5"));

        assertTrue(emitted.isEmpty());
        assertEquals(1, dlq.size());
        assertEquals(1, rejected(RejectReason.MAPPER_OTHER));
    }

    /**
     * A mapper bug is not bad data: the task must die rather than mangle records. The DLQ entry
     * is written on the way out because the counter rarely survives to be scraped.
     */
    @Test
    void aMapperBugWritesTheDlqEntryAndThenFailsTheTask() {
        CsvToAvroFunction<TypeA> fn = function(row -> {
            throw new IllegalStateException("bug");
        });

        assertThrows(IllegalStateException.class, () -> feed(fn, data("a1,Alice,3.5")));
        assertEquals(1, dlq.size(), "the DLQ entry must be written before the throw");
        assertTrue(dlq.get(0).reason.startsWith("mapper-failure:"), dlq.get(0).reason);
        assertEquals(1, counter("mapperFailures"));
        assertTrue(emitted.isEmpty());
    }

    // --- file signals are consumed, never forwarded ------------------------------------------

    @Test
    void fileSignalsAreCountedAndForwardedNowhere() {
        CsvToAvroFunction<TypeA> fn = function();
        feed(fn, Line.fileOpen(OBJECT, 1_700_000_000_000L, 4096));

        assertTrue(emitted.isEmpty(), "nothing synthetic may reach Kafka");
        assertTrue(dlq.isEmpty());
        assertEquals(1, counter("filesOpened"));
        assertEquals(1_700_000_000_000L, metrics.longGaugeAt(BASE + ".newestFileModifiedMillis")
                .getValue());
    }

    @Test
    void aCorruptFileIsCountedAndRecordedInTheDlqWithNoRawLine() {
        feed(function(), Line.corrupt(OBJECT, 1_700_000_000_000L, 4096));

        assertTrue(emitted.isEmpty());
        assertEquals(1, dlq.size());
        assertEquals(OBJECT, dlq.get(0).objectKey);
        assertEquals(null, dlq.get(0).rawLine, "a file-level entry has no row");
        assertEquals(1, counter("corruptFilesSkipped"));
    }

    @Test
    void headerAndBlankLinesAreDroppedIntoTheirOwnCounters() {
        CsvToAvroFunction<TypeA> fn = function();
        feed(fn, data("id,name,value"));
        feed(fn, data(""));

        assertTrue(emitted.isEmpty());
        assertTrue(dlq.isEmpty());
        assertEquals(1, counter("headerLinesDropped"));
        assertEquals(1, counter("blankLinesDropped"));
    }

    // --- the whole point ---------------------------------------------------------------------

    /**
     * Every line lands in exactly one place and increments exactly one counter. This is the
     * assertion CLAUDE.md's "rows that vanished is not a reachable state" actually rests on.
     */
    @Test
    void everyLineIsAccountedForExactlyOnce() {
        CsvToAvroFunction<TypeA> fn = function(row ->
                "skip".equals(row.get("name")) ? null : TypeA.newBuilder()
                        .setId(row.require("id")).setName(row.get("name")).build());

        feed(fn, Line.fileOpen(OBJECT, 1L, 1L));
        feed(fn, data("id,name,value"));        // header
        feed(fn, data(""));                     // blank
        feed(fn, data("a1,Alice,3.5"));         // row
        feed(fn, data("a2,skip,1"));            // dropped by the mapper
        feed(fn, data("a3,Bob"));               // column-count reject
        feed(fn, data("a4,\"unclosed,1"));      // malformed reject

        long accounted = counter("recordsOut") + counter("rowsDropped")
                + counter("headerLinesDropped") + counter("blankLinesDropped")
                + counter("filesOpened")
                + rejected(RejectReason.COLUMN_COUNT) + rejected(RejectReason.MALFORMED_CSV);

        assertEquals(7, accounted, "7 lines in, " + accounted + " accounted for — registered: "
                + metrics.all());
        assertEquals(1, emitted.size());
        assertEquals(2, dlq.size(), "only the two rejects belong in the DLQ");
    }

    // --- stubs -------------------------------------------------------------------------------

    private Collector<TypeA> collector() {
        return new Collector<>() {
            @Override
            public void collect(TypeA record) {
                emitted.add(record);
            }

            @Override
            public void close() {
            }
        };
    }

    /**
     * Records side output instead of routing it, so the DLQ branch is observable.
     *
     * <p>Built from the function under test rather than a fresh one: {@code Context} is an inner
     * class and needs some outer instance, but constructing a second function would register a
     * second set of counters into the same metric group and make every count ambiguous.
     */
    private ProcessFunction<Line, TypeA>.Context context(CsvToAvroFunction<TypeA> fn) {
        return fn.new Context() {
            @Override
            public Long timestamp() {
                return null;
            }

            @Override
            public TimerService timerService() {
                throw new UnsupportedOperationException("this operator registers no timers");
            }

            @Override
            public <X> void output(OutputTag<X> tag, X value) {
                assertEquals(dlqTag.getId(), tag.getId(), "the only side output is the DLQ");
                dlq.add((DlqRecord) value);
            }
        };
    }
}
