package com.example.csv2avro.core.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.csv2avro.core.csv.LineParser.Outcome;
import com.example.csv2avro.core.format.Line;
import com.example.csv2avro.core.spi.RejectReason;
import com.example.csv2avro.core.spi.RowRejectedException;
import java.util.Set;
import org.junit.jupiter.api.Test;

class LineParserTest {

    private static final String OBJECT = "s3://bucket/type-a/x.csv.gz";

    private static LineParser parser() {
        return new LineParser("type-a", "id,name,value", ',', '"', null, Set.of("", "NULL"));
    }

    /** A data line as it arrives from the source, carrying its file identity. */
    private static Line data(String text) {
        return Line.data(text, OBJECT, 1_700_000_000_000L, 4096);
    }

    @Test
    void parsesPlainRow() throws Exception {
        Outcome o = parser().parse(data("a1,Alice,3.5"));
        assertEquals(Outcome.Kind.ROW, o.kind);
        assertEquals("a1", o.row.get("id"));
        assertEquals("Alice", o.row.require("name"));
        assertEquals("3.5", o.row.get("value"));
        assertEquals("a1,Alice,3.5", o.row.rawLine());
    }

    @Test
    void parsesQuotedDelimiterAndDoubledQuotes() {
        Outcome o = parser().parse(data("a1,\"Smith, \"\"Bob\"\"\",1"));
        assertEquals(Outcome.Kind.ROW, o.kind);
        assertEquals("Smith, \"Bob\"", o.row.get("name"));
    }

    @Test
    void nullTokensBecomeNull() {
        Outcome o = parser().parse(data("a1,NULL,"));
        assertEquals(Outcome.Kind.ROW, o.kind);
        assertNull(o.row.get("name"));
        assertNull(o.row.get("value"));
    }

    @Test
    void requireOnNullRejectsRow() {
        Outcome o = parser().parse(data("a1,NULL,2"));
        assertThrows(RowRejectedException.class, () -> o.row.require("name"));
    }

    @Test
    void unknownColumnIsABugNotBadData() {
        Outcome o = parser().parse(data("a1,Alice,3.5"));
        assertThrows(IllegalArgumentException.class, () -> o.row.get("nope"));
    }

    // --- header lines are dropped wherever they appear ------------------------------------

    @Test
    void dropsExactHeaderLine() {
        assertEquals(Outcome.Kind.HEADER, parser().parse(data("id,name,value")).kind);
    }

    @Test
    void dropsHeaderWithBomAndCr() {
        assertEquals(Outcome.Kind.HEADER, parser().parse(data("\uFEFFid,name,value\r")).kind);
    }

    @Test
    void dropsQuotedVariantOfSameHeader() {
        assertEquals(Outcome.Kind.HEADER, parser().parse(data("\"id\",\"name\",\"value\"")).kind);
    }

    @Test
    void blankLinesAreDroppedSilently() {
        assertEquals(Outcome.Kind.BLANK, parser().parse(data("")).kind);
        assertEquals(Outcome.Kind.BLANK, parser().parse(data("\r")).kind);
    }

    // --- the header is assumed stable; a changed one is ordinary bad data ------------------

    /**
     * The documented consequence of dropping header-drift detection: an added or removed
     * column makes every line of the file a column-count reject, so the change is loud in the
     * DLQ rate and in {@code recordsOut} going flat. Nothing wrong is written to Kafka.
     */
    @Test
    void addedColumnIsAnOrdinaryColumnCountReject() {
        Outcome o = parser().parse(data("id,name,value,extra"));
        assertEquals(Outcome.Kind.REJECT, o.kind);
        assertEquals(RejectReason.COLUMN_COUNT, o.code);
    }

    /**
     * The known blind spot, asserted so it stays a deliberate choice rather than a surprise: a
     * same-count reorder binds values positionally against the pinned header, so the row is
     * accepted with its values in the wrong fields. Stop the job before a known header change.
     */
    @Test
    void sameCountReorderIsAcceptedWithValuesInTheWrongColumns() {
        Outcome o = parser().parse(data("Alice,a1,3.5"));
        assertEquals(Outcome.Kind.ROW, o.kind);
        assertEquals("Alice", o.row.get("id"), "bound by position, not by the new header");
    }

    @Test
    void wrongColumnCountIsRejected() {
        Outcome o = parser().parse(data("a1,Alice"));
        assertEquals(Outcome.Kind.REJECT, o.kind);
        assertTrue(o.reason.startsWith("column-count"));
    }

    /**
     * A data row that happens to carry column-name-shaped values is a row, not a header. Only
     * a line equal to the <em>whole</em> pinned header is dropped.
     */
    @Test
    void dataRowFullOfColumnNamesIsStillARow() {
        Outcome o = parser().parse(data("name,value,7"));
        assertEquals(Outcome.Kind.ROW, o.kind);
        assertEquals("name", o.row.get("id"));
    }

    // --- parser reuse: the invariant that makes it safe -----------------------------------

    /**
     * <b>The regression test for the CSVParser reuse in {@code LineParser.splitCsv}.</b>
     *
     * <p>The parser is kept alive across lines, so a line that fails mid-token would leave the
     * lexer dangling. Without the rebuild-on-failure, the line after a malformed one is
     * silently swallowed and the line after <em>that</em> arrives with its first character
     * eaten — corruption written straight to Kafka, with nothing in any counter. This asserts
     * that a single parser instance handles the sequence exactly as if each line were parsed
     * on its own.
     *
     * <p>If this test is deleted, the reuse must be deleted with it.
     */
    @Test
    void malformedLineDoesNotCorruptTheFollowingLines() {
        LineParser p = parser();

        assertEquals(RejectReason.MALFORMED_CSV, p.parse(data("a1,\"unclosed,3.5")).code);

        Outcome next = p.parse(data("a2,Bob,1.5"));
        assertEquals(Outcome.Kind.ROW, next.kind, "the line after a malformed one must survive");
        assertEquals("a2", next.row.get("id"), "its first character must not have been eaten");
        assertEquals("Bob", next.row.get("name"));

        Outcome after = p.parse(data("a3,Carol,2.5"));
        assertEquals(Outcome.Kind.ROW, after.kind);
        assertEquals("a3", after.row.get("id"));
        assertEquals("Carol", after.row.get("name"));
    }

    /** Several malformed lines in a row must not compound the damage. */
    @Test
    void consecutiveMalformedLinesEachRejectAndThenRecover() {
        LineParser p = parser();
        for (int i = 0; i < 3; i++) {
            assertEquals(RejectReason.MALFORMED_CSV, p.parse(data("x,\"open" + i)).code);
        }
        Outcome good = p.parse(data("a9,Zoe,9.5"));
        assertEquals(Outcome.Kind.ROW, good.kind);
        assertEquals("a9", good.row.get("id"));
        assertEquals("Zoe", good.row.get("name"));
    }

    /** A malformed <em>first</em> line, before the parser has handled anything else. */
    @Test
    void malformedFirstLineDoesNotPoisonTheParser() {
        LineParser p = parser();
        assertEquals(RejectReason.MALFORMED_CSV, p.parse(data("bad,\"unbalanced,quote")).code);
        Outcome o = p.parse(data("a1,Alice,3.5"));
        assertEquals(Outcome.Kind.ROW, o.kind);
        assertEquals("a1", o.row.get("id"));
    }

    /** Blank and header lines are interleaved with data through the same reused parser. */
    @Test
    void reusedParserHandlesAMixedFileInOrder() {
        LineParser p = parser();
        assertEquals(Outcome.Kind.HEADER, p.parse(data("id,name,value")).kind);
        assertEquals(Outcome.Kind.ROW, p.parse(data("a1,Alice,1")).kind);
        assertEquals(Outcome.Kind.BLANK, p.parse(data("")).kind);
        assertEquals(Outcome.Kind.ROW, p.parse(data("a2,Bob,2")).kind);
        assertEquals(RejectReason.MALFORMED_CSV, p.parse(data("a3,\"oops")).code);
        Outcome last = p.parse(data("a4,Dan,4"));
        assertEquals(Outcome.Kind.ROW, last.kind);
        assertEquals("a4", last.row.get("id"));
        assertEquals("Dan", last.row.get("name"));
    }

    // --- file signals ---------------------------------------------------------------------

    @Test
    void corruptSignalCarriesObjectKey() {
        Outcome o = parser().parse(Line.corrupt(OBJECT, 1_700_000_000_000L, 42));
        assertEquals(Outcome.Kind.CORRUPT, o.kind);
        assertEquals(OBJECT, o.objectPath());
    }

    @Test
    void fileOpenBecomesItsOwnKindAndCarriesFileFacts() {
        Outcome open = parser().parse(Line.fileOpen(OBJECT, 1_700_000_000_000L, 4096));
        assertEquals(Outcome.Kind.FILE_OPEN, open.kind);
        assertEquals(OBJECT, open.objectPath());
        assertEquals(1_700_000_000_000L, open.line.modifiedMillis);
        assertEquals(4096L, open.line.sizeBytes,
                "the size the byte counter is incremented by, so it must survive the round trip");
    }

    /** Every outcome can name its object — that is what makes a DLQ entry actionable. */
    @Test
    void everyOutcomeNamesItsObject() {
        LineParser p = parser();
        assertEquals(OBJECT, p.parse(data("a1,Alice,3.5")).objectPath());
        assertEquals(OBJECT, p.parse(data("a1,Alice")).objectPath());
        assertEquals(OBJECT, p.parse(data("a1,\"unclosed")).objectPath());
        assertEquals(OBJECT, p.parse(data("id,name,value")).objectPath());
    }

    // --- reject codes ---------------------------------------------------------------------

    @Test
    void everyRejectionCarriesABoundedCode() {
        assertEquals(RejectReason.COLUMN_COUNT, parser().parse(data("a1,Alice")).code);
        // An unterminated quote is not parseable CSV at all.
        assertEquals(RejectReason.MALFORMED_CSV, parser().parse(data("a1,\"unclosed,3.5")).code);
    }

    @Test
    void requireOnNullIsMissingRequiredNotMapperOther() {
        Outcome o = parser().parse(data("a1,NULL,2"));
        RowRejectedException e =
                assertThrows(RowRejectedException.class, () -> o.row.require("name"));
        assertEquals(RejectReason.MISSING_REQUIRED, e.code());
    }

    @Test
    void duplicateHeaderColumnsAreAConfigError() {
        assertThrows(IllegalArgumentException.class,
                () -> new LineParser("x", "id,id,value", ',', '"', null, Set.of("")));
    }
}
