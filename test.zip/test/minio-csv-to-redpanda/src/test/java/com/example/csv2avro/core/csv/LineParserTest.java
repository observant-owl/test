package com.example.csv2avro.core.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.csv2avro.core.csv.LineParser.Outcome;
import com.example.csv2avro.core.format.FileMarker;
import com.example.csv2avro.core.spi.RejectReason;
import com.example.csv2avro.core.spi.RowRejectedException;
import java.util.Set;
import org.junit.jupiter.api.Test;

class LineParserTest {

    private static LineParser parser(boolean haltOnDrift) {
        return new LineParser(
                "type-a", "id,name,value", ',', '"', null, Set.of("", "NULL"), haltOnDrift);
    }

    @Test
    void parsesPlainRow() throws Exception {
        Outcome o = parser(true).parse("a1,Alice,3.5");
        assertEquals(Outcome.Kind.ROW, o.kind);
        assertEquals("a1", o.row.get("id"));
        assertEquals("Alice", o.row.require("name"));
        assertEquals("3.5", o.row.get("value"));
        assertEquals("a1,Alice,3.5", o.row.rawLine());
    }

    @Test
    void parsesQuotedDelimiterAndDoubledQuotes() {
        Outcome o = parser(true).parse("a1,\"Smith, \"\"Bob\"\"\",1");
        assertEquals(Outcome.Kind.ROW, o.kind);
        assertEquals("Smith, \"Bob\"", o.row.get("name"));
    }

    @Test
    void nullTokensBecomeNull() {
        Outcome o = parser(true).parse("a1,NULL,");
        assertEquals(Outcome.Kind.ROW, o.kind);
        assertNull(o.row.get("name"));
        assertNull(o.row.get("value"));
    }

    @Test
    void requireOnNullRejectsRow() {
        Outcome o = parser(true).parse("a1,NULL,2");
        assertThrows(RowRejectedException.class, () -> o.row.require("name"));
    }

    @Test
    void unknownColumnIsABugNotBadData() {
        Outcome o = parser(true).parse("a1,Alice,3.5");
        assertThrows(IllegalArgumentException.class, () -> o.row.get("nope"));
    }

    @Test
    void dropsExactHeaderLine() {
        assertEquals(Outcome.Kind.HEADER, parser(true).parse("id,name,value").kind);
    }

    @Test
    void dropsHeaderWithBomAndCr() {
        assertEquals(Outcome.Kind.HEADER, parser(true).parse("﻿id,name,value\r").kind);
    }

    @Test
    void dropsQuotedVariantOfSameHeader() {
        assertEquals(Outcome.Kind.HEADER, parser(true).parse("\"id\",\"name\",\"value\"").kind);
    }

    @Test
    void blankLinesAreDroppedSilently() {
        assertEquals(Outcome.Kind.BLANK, parser(true).parse("").kind);
        assertEquals(Outcome.Kind.BLANK, parser(true).parse("\r").kind);
    }

    @Test
    void wrongColumnCountIsRejected() {
        Outcome o = parser(true).parse("a1,Alice");
        assertEquals(Outcome.Kind.REJECT, o.kind);
        assertTrue(o.reason.startsWith("column-count"));
    }

    @Test
    void addedColumnHeaderHaltsTheType() {
        assertThrows(HeaderDriftException.class,
                () -> parser(true).parse("id,name,value,extra"));
    }

    @Test
    void reorderedHeaderHaltsTheType() {
        assertThrows(HeaderDriftException.class, () -> parser(true).parse("name,id,value"));
    }

    @Test
    void driftBecomesRejectWhenHaltDisabled() {
        Outcome o = parser(false).parse("id,name,value,extra");
        assertEquals(Outcome.Kind.REJECT, o.kind);
        assertTrue(o.reason.startsWith("header-drift-suspect"));
    }

    @Test
    void dataRowContainingOneColumnNameDoesNotTripDrift() {
        // "name" as a value: 1 hit < max(2, 2) threshold
        Outcome o = parser(true).parse("a1,name,7");
        assertEquals(Outcome.Kind.ROW, o.kind);
    }

    @Test
    void corruptMarkerCarriesObjectKey() {
        Outcome o = parser(true).parse(FileMarker.encode(
                FileMarker.Kind.CORRUPT, "s3://bucket/type-a/x.csv.gz", 1_700_000_000_000L, 42));
        assertEquals(Outcome.Kind.CORRUPT, o.kind);
        assertEquals("s3://bucket/type-a/x.csv.gz", o.objectKey);
        assertTrue(FileMarker.encode(FileMarker.Kind.CORRUPT, "x", 1, 2)
                .startsWith(LineParser.CORRUPT_SENTINEL_PREFIX));
    }

    @Test
    void fileMarkersBecomeTheirOwnKindsAndCarryFileFacts() {
        Outcome open = parser(true).parse(FileMarker.encode(
                FileMarker.Kind.OPEN, "s3://bucket/type-a/x.csv.gz", 1_700_000_000_000L, 4096));
        assertEquals(Outcome.Kind.FILE_OPEN, open.kind);
        assertEquals("s3://bucket/type-a/x.csv.gz", open.objectKey);
        assertEquals(1_700_000_000_000L, open.fileModifiedMillis);
        assertEquals(4096L, open.fileSizeBytes);

        Outcome done = parser(true).parse(FileMarker.encode(
                FileMarker.Kind.DONE, "s3://bucket/type-a/x.csv.gz", 1_700_000_000_000L, 4096));
        assertEquals(Outcome.Kind.FILE_DONE, done.kind);
    }

    @Test
    void everyRejectionCarriesABoundedCode() {
        assertEquals(RejectReason.COLUMN_COUNT, parser(true).parse("a1,Alice").code);
        assertEquals(RejectReason.HEADER_DRIFT_SUSPECT,
                parser(false).parse("id,name,value,extra").code);
        // An unterminated quote is not parseable CSV at all.
        assertEquals(RejectReason.MALFORMED_CSV, parser(true).parse("a1,\"unclosed,3.5").code);
    }

    @Test
    void requireOnNullIsMissingRequiredNotMapperOther() {
        Outcome o = parser(true).parse("a1,NULL,2");
        RowRejectedException e =
                assertThrows(RowRejectedException.class, () -> o.row.require("name"));
        assertEquals(RejectReason.MISSING_REQUIRED, e.code());
    }

    @Test
    void duplicateHeaderColumnsAreAConfigError() {
        assertThrows(IllegalArgumentException.class,
                () -> new LineParser("x", "id,id,value", ',', '"', null, Set.of(""), true));
    }
}
