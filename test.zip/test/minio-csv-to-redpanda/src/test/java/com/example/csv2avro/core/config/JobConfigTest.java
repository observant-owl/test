package com.example.csv2avro.core.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class JobConfigTest {

    @TempDir
    Path dir;

    private static final String VALID = """
            job:
              name: test
            kafka:
              bootstrapServers: "localhost:9092"
              schemaRegistryUrl: "http://localhost:8081"
            streams:
              type-a:
                prefix: "s3://b/type-a/"
                topic: "type-a.v1"
                expectedHeader: "id,name,value"
                dialect:
                  nullTokens: ["", "NULL"]
            """;

    // --- layered loading ---------------------------------------------------------------

    /** Layer 1: shared defaults only — it mentions no stream at all. */
    private static final String L_BASE = """
            job:
              name: csv-to-avro
            kafka:
              bootstrapServers: "base:9092"
              schemaRegistryUrl: "http://base:8081"
              properties:
                compression.type: "zstd"
            source:
              monitorIntervalSeconds: 30
            """;

    /** Layer 2: environment — infra endpoints only. Dev and prod read the same objects, so no
     * stream values are env-specific. */
    private static final String L_ENV = """
            job:
              name: csv-to-avro-dev
            kafka:
              bootstrapServers: "dev:19092"
            """;

    /** Layer 3: the type — env-invariant, and the layer whose presence puts the stream in the
     * job at all. */
    private static final String L_TYPE = """
            streams:
              type-a:
                prefix: "s3://BUCKET/type-a/"
                topic: "type-a.v1"
                expectedHeader: "id,name,value"
                dialect:
                  nullTokens: ["", "NULL"]
            """;

    private List<Path> layers(String... yamls) throws IOException {
        List<Path> paths = new ArrayList<>();
        for (int i = 0; i < yamls.length; i++) {
            Path f = dir.resolve("layer-" + i + ".yaml");
            Files.writeString(f, yamls[i]);
            paths.add(f);
        }
        return paths;
    }

    /**
     * The shape every deployment uses: the type layer is the only one that mentions a stream,
     * over infrastructure the env layer supplies, over base defaults. This is the whole point of
     * layering — no layer restates another's fields.
     */
    @Test
    void streamBlockIsAssembledAcrossAllThreeLayers() throws Exception {
        JobConfig cfg = JobConfig.load(layers(L_BASE, L_ENV, L_TYPE));
        StreamConfig sc = cfg.requireStream("type-a");

        assertEquals("s3://BUCKET/type-a/", sc.prefix, "from the type layer");
        assertEquals("type-a.v1", sc.topic, "from the type layer");
        assertEquals("dev:19092", cfg.kafka.bootstrapServers, "from the env layer");
        cfg.validateAgainst(Set.of("type-a"));
    }

    @Test
    void laterLayerOverridesScalarsAndUntouchedKeysSurvive() throws Exception {
        JobConfig cfg = JobConfig.load(layers(L_BASE, L_ENV, L_TYPE));

        assertEquals("csv-to-avro-dev", cfg.job.name, "the env layer wins");
        assertEquals("dev:19092", cfg.kafka.bootstrapServers, "the env layer wins");
        assertEquals("http://base:8081", cfg.kafka.schemaRegistryUrl,
                "a key no later layer mentions must survive, not be wiped by the merge");
        assertEquals(1, cfg.parallelism(cfg.requireStream("type-a")),
                "a section no layer mentions keeps its code default");
    }

    @Test
    void mapsMergeKeyByKeyButArraysAreReplacedWholesale() throws Exception {
        JobConfig cfg = JobConfig.load(layers(L_BASE, L_ENV, L_TYPE, """
                kafka:
                  properties:
                    linger.ms: "50"
                streams:
                  type-a:
                    dialect:
                      nullTokens: ["N/A"]
                """));

        assertEquals("zstd", cfg.kafka.properties.get("compression.type"),
                "adding one property must not drop the others");
        assertEquals("50", cfg.kafka.properties.get("linger.ms"));
        assertEquals(List.of("N/A"), cfg.requireStream("type-a").dialect.nullTokens,
                "arrays are replaced, not concatenated — documented in config/base.yaml");
    }

    /** A typo must fail wherever it is: the merged tree is bound once, strictly. */
    @Test
    void unknownKeyInAnyLayerFails() throws Exception {
        assertThrows(UncheckedIOException.class,
                () -> JobConfig.load(layers(L_BASE + "\ntypo-in-base: 1\n", L_ENV, L_TYPE)));
        assertThrows(UncheckedIOException.class,
                () -> JobConfig.load(layers(L_BASE, L_ENV + "\ntypo-in-env: 1\n", L_TYPE)));
        assertThrows(UncheckedIOException.class,
                () -> JobConfig.load(layers(L_BASE, L_ENV, L_TYPE, """
                        streams:
                          type-a:
                            typoInType: 1
                        """)));
    }

    @Test
    void nonPositiveMonitorIntervalFails() throws Exception {
        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> JobConfig.load(layers(L_BASE, L_ENV, L_TYPE, """
                        streams:
                          type-a:
                            monitorIntervalSeconds: 0
                        """)));
        assertTrue(e.getMessage().contains("monitorIntervalSeconds"), e.getMessage());
    }

    // --- per-stream override resolution ------------------------------------------------

    @Test
    void overridesFallBackToTheSharedValueWhenAbsent() throws Exception {
        JobConfig cfg = JobConfig.load(layers(L_BASE, L_ENV, L_TYPE));
        StreamConfig sc = cfg.requireStream("type-a");

        assertEquals(30L, cfg.monitorIntervalSeconds(sc));
        assertEquals(1, cfg.parallelism(sc));
    }

    @Test
    void perStreamOverridesWin() throws Exception {
        JobConfig cfg = JobConfig.load(layers(L_BASE, L_ENV, L_TYPE, """
                streams:
                  type-a:
                    monitorIntervalSeconds: 300
                    parallelism: 4
                """));
        StreamConfig sc = cfg.requireStream("type-a");

        assertEquals(300L, cfg.monitorIntervalSeconds(sc));
        assertEquals(4, cfg.parallelism(sc));
    }

    @Test
    void validConfigLoads() throws Exception {
        JobConfig cfg = JobConfig.load(layers(VALID));
        StreamConfig sc = cfg.requireStream("type-a");
        assertEquals("type-a.v1", sc.topic);
        assertEquals(',', sc.dialect.delimiterChar());
        assertEquals(1, cfg.parallelism(sc));
        cfg.validateAgainst(Set.of("type-a"));
    }

    @Test
    void missingExpectedHeaderFails() throws Exception {
        List<Path> f = layers(VALID.replace("expectedHeader: \"id,name,value\"", ""));
        IllegalStateException e =
                assertThrows(IllegalStateException.class, () -> JobConfig.load(f));
        assertTrue(e.getMessage().contains("expectedHeader"));
    }

    @Test
    void missingPrefixFails() throws Exception {
        List<Path> f = layers(VALID.replace("prefix: \"s3://b/type-a/\"", ""));
        IllegalStateException e =
                assertThrows(IllegalStateException.class, () -> JobConfig.load(f));
        assertTrue(e.getMessage().contains("'prefix' missing"), e.getMessage());
    }

    @Test
    void multiCharDelimiterFails() throws Exception {
        List<Path> f = layers(VALID.replace("nullTokens: [\"\", \"NULL\"]", "delimiter: \",,\""));
        assertThrows(IllegalStateException.class, () -> JobConfig.load(f));
    }

    /**
     * The reverse of {@link #configBlockWithoutDefinitionFails}, and deliberately <em>not</em> an
     * error: a discovered definition nobody configured is a type nobody deployed. Requiring a
     * stub for it would mean registering type-b breaks type-a's deployment.
     */
    @Test
    void definitionWithoutConfigBlockIsSimplyNotRun() throws Exception {
        JobConfig cfg = JobConfig.load(layers(VALID));
        cfg.validateAgainst(Set.of("type-a", "type-b"));
    }

    @Test
    void configBlockWithoutDefinitionFails() throws Exception {
        JobConfig cfg = JobConfig.load(layers(VALID));
        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> cfg.validateAgainst(Set.of()));
        assertTrue(e.getMessage().contains("type-a"));
    }

    // --- null blocks and conditional infrastructure validation --------------------------

    /**
     * {@code deepMerge} replaces explicit nulls wholesale, so a bare {@code dialect:} in an
     * overlay binds null over the field initializer. That has to read as a config error, not as
     * an NPE from inside validation.
     */
    @Test
    void explicitlyNullDialectIsAReadableErrorNotAnNpe() throws Exception {
        List<Path> f = layers(L_BASE, L_ENV, L_TYPE, """
                streams:
                  type-a:
                    dialect:
                """);
        IllegalStateException e =
                assertThrows(IllegalStateException.class, () -> JobConfig.load(f));
        assertTrue(e.getMessage().contains("stream 'type-a': 'dialect' block is null/missing"),
                e.getMessage());
    }

    /**
     * Every stream writes to Kafka. The kafka section normally comes from the env layer, so
     * "forgot to pass {@code --config config/env/prod.yaml}" is the failure this catches — and
     * it has to name every missing key at once, not one per restart.
     */
    @Test
    void missingKafkaSectionListsEveryMissingKeyAtOnce() throws Exception {
        List<Path> f = layers("""
                job:
                  name: test
                dlq:
                  topic: ""
                streams:
                  type-a:
                    prefix: "s3://b/type-a/"
                    topic: "type-a.v1"
                    expectedHeader: "id,name,value"
                """);
        IllegalStateException e =
                assertThrows(IllegalStateException.class, () -> JobConfig.load(f));
        assertTrue(e.getMessage().contains("kafka.bootstrapServers"), e.getMessage());
        assertTrue(e.getMessage().contains("kafka.schemaRegistryUrl"), e.getMessage());
        assertTrue(e.getMessage().contains("dlq.topic"), e.getMessage());
        assertTrue(e.getMessage().contains("--config"),
                "the error must hint at the layer that normally supplies it: " + e.getMessage());
    }

    /**
     * There is no enable flag, so a half-filled block is never "a stream that is off" — it is a
     * stream that will run without a topic. It has to fail at startup, naming every gap at once.
     */
    @Test
    void everyConfiguredStreamIsValidatedInFull() throws Exception {
        List<Path> f = layers(VALID + """
                  type-b:
                    prefix: "s3://b/type-b/"
                """);
        IllegalStateException e =
                assertThrows(IllegalStateException.class, () -> JobConfig.load(f));
        assertTrue(e.getMessage().contains("stream 'type-b': 'topic' missing"), e.getMessage());
        assertTrue(e.getMessage().contains("expectedHeader"), e.getMessage());
    }
}
