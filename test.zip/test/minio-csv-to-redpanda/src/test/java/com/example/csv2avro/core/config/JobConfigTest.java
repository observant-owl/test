package com.example.csv2avro.core.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class JobConfigTest {

    @TempDir
    Path dir;

    private static final String VALID = """
            job:
              name: test
            kafka:
              bootstrapServers: "localhost:9092"
              schemaRegistryUrl: "http://localhost:8081"
            source:
              kind: stock
              mode: bounded
            streams:
              type-a:
                prefix: "s3://b/type-a/"
                topic: "type-a.v1"
                expectedHeader: "id,name,value"
                dialect:
                  nullTokens: ["", "NULL"]
            """;

    private Path write(String yaml) throws IOException {
        Path f = dir.resolve("cfg.yaml");
        Files.writeString(f, yaml);
        return f;
    }

    @Test
    void validConfigLoads() throws Exception {
        JobConfig cfg = JobConfig.load(write(VALID));
        StreamConfig sc = cfg.requireStream("type-a");
        assertEquals("type-a.v1", sc.topic);
        assertEquals(',', sc.dialect.delimiterChar());
        assertEquals(1, cfg.sourceParallelism(sc));
        cfg.validateAgainst(Set.of("type-a"));
    }

    @Test
    void unknownYamlKeyFailsLoudly() throws Exception {
        Path f = write(VALID + "\ntypo-section:\n  x: 1\n");
        assertThrows(UncheckedIOException.class, () -> JobConfig.load(f));
    }

    @Test
    void missingExpectedHeaderFails() throws Exception {
        Path f = write(VALID.replace("expectedHeader: \"id,name,value\"", ""));
        IllegalStateException e =
                assertThrows(IllegalStateException.class, () -> JobConfig.load(f));
        assertTrue(e.getMessage().contains("expectedHeader"));
    }

    @Test
    void multiCharDelimiterFails() throws Exception {
        Path f = write(VALID.replace("nullTokens: [\"\", \"NULL\"]", "delimiter: \",,\""));
        assertThrows(IllegalStateException.class, () -> JobConfig.load(f));
    }

    @Test
    void definitionWithoutConfigBlockFails() throws Exception {
        JobConfig cfg = JobConfig.load(write(VALID));
        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> cfg.validateAgainst(Set.of("type-a", "type-b")));
        assertTrue(e.getMessage().contains("type-b"));
    }

    @Test
    void configBlockWithoutDefinitionFails() throws Exception {
        JobConfig cfg = JobConfig.load(write(VALID));
        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> cfg.validateAgainst(Set.of()));
        assertTrue(e.getMessage().contains("type-a"));
    }

    @Test
    void disabledStreamMayStaySparse() throws Exception {
        JobConfig cfg = JobConfig.load(write(VALID + """
                  type-b:
                    enabled: false
                """));
        cfg.validateAgainst(Set.of("type-a", "type-b"));
    }
}
