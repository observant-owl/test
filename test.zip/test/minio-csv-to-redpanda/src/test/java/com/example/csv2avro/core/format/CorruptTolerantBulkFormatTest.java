package com.example.csv2avro.core.format;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.csv2avro.core.csv.LineParser;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPOutputStream;
import org.apache.flink.connector.file.src.util.CheckpointedPosition;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.connector.file.src.FileSourceSplit;
import org.apache.flink.connector.file.src.reader.BulkFormat;
import org.apache.flink.connector.file.src.reader.TextLineInputFormat;
import org.apache.flink.connector.file.src.util.RecordAndPosition;
import org.apache.flink.core.fs.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class CorruptTolerantBulkFormatTest {

    private static final long MTIME = 1_756_684_800_000L;

    @TempDir
    java.nio.file.Path dir;

    /** One emitted record plus the position it claimed — positions are half of what is asserted
     * here, because a synthetic record that claims to advance the file position silently drops
     * real data on restore. */
    private record Emitted(String record, long offset, long skipCount) {
        boolean isMarkerOf(FileMarker.Kind kind) {
            FileMarker m = FileMarker.decode(record);
            return m != null && m.kind() == kind;
        }
    }

    private static FileSourceSplit splitFor(java.nio.file.Path file) throws IOException {
        long len = Files.size(file);
        return new FileSourceSplit(
                "split-1", new Path(file.toUri()), 0, len, MTIME, len);
    }

    private static List<Emitted> drain(BulkFormat.Reader<String> reader) throws IOException {
        List<Emitted> out = new ArrayList<>();
        try (BulkFormat.Reader<String> r = reader) {
            BulkFormat.RecordIterator<String> batch;
            while ((batch = r.readBatch()) != null) {
                RecordAndPosition<String> rec;
                while ((rec = batch.next()) != null) {
                    out.add(new Emitted(
                            rec.getRecord(), rec.getOffset(), rec.getRecordSkipCount()));
                }
                batch.releaseBatch();
            }
        }
        return out;
    }

    private static List<Emitted> readAll(BulkFormat<String, FileSourceSplit> format,
            java.nio.file.Path file) throws IOException {
        return drain(format.createReader(new Configuration(), splitFor(file)));
    }

    private static List<String> records(List<Emitted> emitted) {
        return emitted.stream().map(Emitted::record).toList();
    }

    /** Data lines only — markers stripped, as the parse operator strips them. */
    private static List<String> dataOnly(List<Emitted> emitted) {
        return emitted.stream()
                .filter(e -> FileMarker.decode(e.record()) == null)
                .map(Emitted::record)
                .toList();
    }

    private BulkFormat<String, FileSourceSplit> format() {
        return new CorruptTolerantBulkFormat(new TextLineInputFormat());
    }

    private BulkFormat<String, FileSourceSplit> formatWithoutMarkers() {
        return new CorruptTolerantBulkFormat(new TextLineInputFormat(), false);
    }

    private java.nio.file.Path plainFile() throws IOException {
        java.nio.file.Path f = dir.resolve("ok.csv");
        Files.writeString(f, "id,name,value\na1,Alice,3.5\n");
        return f;
    }

    private java.nio.file.Path gzipFile(String content, String name) throws IOException {
        java.nio.file.Path f = dir.resolve(name);
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (GZIPOutputStream gz = new GZIPOutputStream(bytes)) {
            gz.write(content.getBytes(StandardCharsets.UTF_8));
        }
        Files.write(f, bytes.toByteArray());
        return f;
    }

    // --- content ------------------------------------------------------------------------

    @Test
    void readsHealthyPlainFile() throws Exception {
        assertEquals(List.of("id,name,value", "a1,Alice,3.5"),
                dataOnly(readAll(format(), plainFile())));
    }

    @Test
    void readsHealthyGzipFile() throws Exception {
        java.nio.file.Path f = gzipFile("id,name,value\na1,Alice,3.5\n", "ok.csv.gz");
        assertEquals(List.of("id,name,value", "a1,Alice,3.5"), dataOnly(readAll(format(), f)));
    }

    @Test
    void markersDisabledReproducesTheOldRecordStreamExactly() throws Exception {
        assertEquals(List.of("id,name,value", "a1,Alice,3.5"),
                records(readAll(formatWithoutMarkers(), plainFile())));
    }

    // --- file boundaries ----------------------------------------------------------------

    @Test
    void healthyFileIsBracketedByOpenAndDone() throws Exception {
        List<Emitted> out = readAll(format(), plainFile());
        assertTrue(out.get(0).isMarkerOf(FileMarker.Kind.OPEN), "first record must be OPEN");
        assertTrue(out.get(out.size() - 1).isMarkerOf(FileMarker.Kind.DONE),
                "last record must be DONE");
        assertEquals(4, out.size(), "OPEN + 2 lines + DONE, got: " + records(out));
    }

    @Test
    void markersCarryTheObjectPathModificationTimeAndSize() throws Exception {
        java.nio.file.Path f = plainFile();
        FileMarker open = FileMarker.decode(readAll(format(), f).get(0).record());
        assertNotNull(open);
        assertEquals(MTIME, open.modifiedMillis());
        assertEquals(Files.size(f), open.sizeBytes());
        assertTrue(open.path().endsWith("ok.csv"), "got path " + open.path());
    }

    @Test
    void emptyFileStillReportsOpenAndDone() throws Exception {
        java.nio.file.Path f = dir.resolve("empty.csv");
        Files.writeString(f, "");
        List<Emitted> out = readAll(format(), f);
        assertEquals(2, out.size(), "expected exactly OPEN + DONE");
        assertTrue(out.get(0).isMarkerOf(FileMarker.Kind.OPEN));
        assertTrue(out.get(1).isMarkerOf(FileMarker.Kind.DONE));
    }

    /**
     * A restored split must not re-announce the file, or every checkpoint restore would inflate
     * filesOpened. {@code getReaderPosition().isEmpty()} is what distinguishes the two cases.
     */
    @Test
    void restoredSplitDoesNotReEmitOpen() throws Exception {
        java.nio.file.Path f = plainFile();
        long len = Files.size(f);
        FileSourceSplit restored = new FileSourceSplit(
                "split-1", new Path(f.toUri()), 0, len, MTIME, len,
                new String[0], new CheckpointedPosition(CheckpointedPosition.NO_OFFSET, 1));

        List<Emitted> out = drain(format().restoreReader(new Configuration(), restored));
        assertTrue(out.stream().noneMatch(e -> e.isMarkerOf(FileMarker.Kind.OPEN)),
                "restore must not re-emit OPEN, got: " + records(out));
        assertTrue(out.get(out.size() - 1).isMarkerOf(FileMarker.Kind.DONE),
                "the file still completes, so DONE is still due");
    }

    // --- positions ----------------------------------------------------------------------

    /**
     * The regression guard for the position finding. With {@code NO_OFFSET} the skip count means
     * "restart this file from the beginning and skip N records". An OPEN marker claiming skip
     * count 1 would therefore silently drop the first real line of every file on any checkpoint
     * restore. Markers must inherit a position, never invent one.
     */
    @Test
    void openClaimsNoRecordsAndDoneInheritsTheLastRealPosition() throws Exception {
        List<Emitted> out = readAll(format(), plainFile());
        Emitted open = out.get(0);
        Emitted lastData = out.get(out.size() - 2);
        Emitted done = out.get(out.size() - 1);

        assertEquals(0L, open.skipCount(),
                "OPEN must not claim a record: skip count 1 would drop the file's first line");
        assertEquals(lastData.offset(), done.offset(), "DONE must inherit the last position");
        assertEquals(lastData.skipCount(), done.skipCount(),
                "DONE must inherit the last position");
    }

    @Test
    void corruptMarkerOnUnopenableFileClaimsNoRecords() throws Exception {
        java.nio.file.Path f = dir.resolve("bad.csv.gz");
        Files.writeString(f, "this is not gzip at all");
        for (Emitted e : readAll(format(), f)) {
            assertEquals(0L, e.skipCount(),
                    "nothing was read, so no marker may claim a record: " + e.record());
        }
    }

    // --- corruption ---------------------------------------------------------------------

    @Test
    void garbageGzipYieldsCorruptMarkerInsteadOfFailing() throws Exception {
        java.nio.file.Path f = dir.resolve("bad.csv.gz");
        Files.writeString(f, "this is not gzip at all");
        List<Emitted> out = readAll(format(), f);

        assertTrue(dataOnly(out).isEmpty(), "no data can be read from it");
        assertTrue(out.get(0).isMarkerOf(FileMarker.Kind.OPEN),
                "a file that cannot be opened was still attempted — it must count as opened");
        Emitted last = out.get(out.size() - 1);
        assertTrue(last.isMarkerOf(FileMarker.Kind.CORRUPT));
        assertTrue(last.record().startsWith(LineParser.CORRUPT_SENTINEL_PREFIX));
        assertTrue(last.record().endsWith("bad.csv.gz"));
        assertTrue(out.stream().noneMatch(e -> e.isMarkerOf(FileMarker.Kind.DONE)),
                "a skipped file must never report DONE — that is the data-loss signal");
    }

    @Test
    void corruptMarkerIsStillEmittedWithMarkersDisabled() throws Exception {
        java.nio.file.Path f = dir.resolve("bad.csv.gz");
        Files.writeString(f, "this is not gzip at all");
        List<Emitted> out = readAll(formatWithoutMarkers(), f);
        assertEquals(1, out.size(), "exactly the corrupt marker, got: " + records(out));
        assertTrue(out.get(0).isMarkerOf(FileMarker.Kind.CORRUPT));
    }

    @Test
    void truncatedGzipYieldsCorruptMarkerAsLastRecordAndNoDone() throws Exception {
        StringBuilder content = new StringBuilder("id,name,value\n");
        for (int i = 0; i < 5000; i++) {
            content.append("row-").append(i).append(",name-").append(i).append(",1.0\n");
        }
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (GZIPOutputStream gz = new GZIPOutputStream(bytes)) {
            gz.write(content.toString().getBytes(StandardCharsets.UTF_8));
        }
        byte[] full = bytes.toByteArray();
        byte[] truncated = new byte[full.length / 2];
        System.arraycopy(full, 0, truncated, 0, truncated.length);
        java.nio.file.Path f = dir.resolve("truncated.csv.gz");
        Files.write(f, truncated);

        List<Emitted> out = readAll(format(), f);
        Emitted last = out.get(out.size() - 1);
        assertTrue(last.isMarkerOf(FileMarker.Kind.CORRUPT),
                "last record must be the corrupt-file marker");
        assertTrue(out.stream().noneMatch(e -> e.isMarkerOf(FileMarker.Kind.DONE)));
        // How much decompressed before the failure is not specified — at-least-once, dedup
        // downstream. Only the marker sequence is contractual.
    }
}
