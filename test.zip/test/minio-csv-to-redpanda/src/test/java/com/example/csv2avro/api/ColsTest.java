package com.example.csv2avro.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import org.junit.jupiter.api.Test;

/**
 * {@code Cols} is what makes invariant 8 true: every non-string conversion routes through here so
 * a bad value becomes a counted DLQ entry naming the column, instead of an uncaught
 * {@code NumberFormatException} that kills the task.
 *
 * <p>So the two things worth pinning are which {@link RejectReason} each failure carries — the
 * DLQ-rate alert and the Prometheus label both depend on drop/reject/missing being distinct — and
 * the conversions whose *correct* answer is easy to get subtly wrong: decimal scale, timestamp
 * zone, and integer overflow.
 */
class ColsTest {

    private static final DateTimeFormatter TS =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private static RowRejectedException rejects(Executable call) {
        return assertThrows(RowRejectedException.class, call::run);
    }

    @FunctionalInterface
    private interface Executable {
        void run() throws Exception;
    }

    // --- doubles (pre-existing) ---------------------------------------------------------------

    @Test
    void parsesOrdinaryDoubles() throws Exception {
        assertEquals(1.5, Cols.optDouble("1.5", "value"));
        assertEquals(-0.25, Cols.optDouble(" -0.25 ", "value"), "surrounding space is trimmed");
        assertNull(Cols.optDouble(null, "value"));
        assertEquals(1.5, Cols.reqDouble("1.5", "value"));
    }

    /**
     * {@code Double.valueOf("NaN")} succeeds, so without an explicit check an undeclared "NaN"
     * sentinel would be written to Avro as a real value and poison every downstream aggregate.
     */
    @Test
    void nonFiniteValuesAreValueFormatRejects() {
        for (String v : new String[] {"NaN", "Infinity", "-Infinity"}) {
            assertEquals(RejectReason.VALUE_FORMAT,
                    rejects(() -> Cols.optDouble(v, "value")).code(), v);
        }
    }

    /** reqDouble is optDouble plus a null check, so it inherits the rejection by composition. */
    @Test
    void reqDoubleInheritsTheNonFiniteRejection() {
        assertEquals(RejectReason.VALUE_FORMAT,
                rejects(() -> Cols.reqDouble("NaN", "value")).code());
    }

    // --- the two reject reasons must stay distinct ---------------------------------------------

    /**
     * Missing and malformed are different alerts and different Prometheus labels. A required
     * column that is absent must never be reported as a format problem, or the DLQ says the
     * upstream sent garbage when it actually sent nothing.
     */
    @Test
    void aMissingRequiredValueIsMissingRequiredNotValueFormat() {
        assertEquals(RejectReason.MISSING_REQUIRED,
                rejects(() -> Cols.reqString(null, "id")).code());
        assertEquals(RejectReason.MISSING_REQUIRED,
                rejects(() -> Cols.reqLong(null, "n")).code());
        assertEquals(RejectReason.MISSING_REQUIRED,
                rejects(() -> Cols.reqBool(null, "flag")).code());
        assertEquals(RejectReason.MISSING_REQUIRED,
                rejects(() -> Cols.reqDecimal(null, "amount", 2)).code());
    }

    /** An empty cell is a *format* failure, not a missing one — emptiness only means null if the
     * type declares it in {@code csv2avro.dialect.null-tokens}, which happens before Cols. */
    @Test
    void anEmptyStringIsAFormatRejectNotAMissingOne() {
        assertEquals(RejectReason.VALUE_FORMAT, rejects(() -> Cols.reqLong("", "n")).code());
    }

    /** Whoever reads the DLQ needs to know which column and which value. */
    @Test
    void theRejectionMessageNamesTheColumnAndTheOffendingValue() {
        String message = rejects(() -> Cols.optInt("twelve", "quantity")).getMessage();

        assertTrue(message.contains("quantity"), message);
        assertTrue(message.contains("twelve"), message);
    }

    // --- null in, null out ---------------------------------------------------------------------

    @Test
    void everyOptionalConversionPassesNullThrough() throws Exception {
        assertNull(Cols.optLong(null, "c"));
        assertNull(Cols.optInt(null, "c"));
        assertNull(Cols.optBool(null, "c"));
        assertNull(Cols.optDecimal(null, "c", 2));
        assertNull(Cols.optTimestampMillis(null, "c", TS, ZoneId.of("UTC")));
        assertNull(Cols.optEpochDays(null, "c", DateTimeFormatter.ISO_DATE));
        assertNull(Cols.trim(null));
        assertNull(Cols.emptyToNull(null));
        assertNull(Cols.upper(null));
        assertNull(Cols.lower(null));
    }

    // --- integers -----------------------------------------------------------------------------

    @Test
    void integersParseAndTrim() throws Exception {
        assertEquals(42L, Cols.optLong(" 42 ", "n"));
        assertEquals(-7, Cols.optInt("-7", "n"));
        assertEquals(42L, Cols.reqLong("42", "n"));
        assertEquals(-7, Cols.reqInt("-7", "n"));
    }

    /**
     * A value one past {@code Integer.MAX_VALUE} must be rejected, never silently truncated —
     * {@code Integer.valueOf} throws, which is exactly why the conversion goes through Cols.
     */
    @Test
    void anIntegerTooLargeForItsTypeIsRejected() {
        assertEquals(RejectReason.VALUE_FORMAT,
                rejects(() -> Cols.optInt("2147483648", "n")).code());
        assertEquals(RejectReason.VALUE_FORMAT,
                rejects(() -> Cols.optLong("9223372036854775808", "n")).code());
    }

    @Test
    void aNonNumericValueIsRejected() {
        assertEquals(RejectReason.VALUE_FORMAT, rejects(() -> Cols.optLong("1.5", "n")).code(),
                "a decimal is not a long");
        assertEquals(RejectReason.VALUE_FORMAT, rejects(() -> Cols.optInt("0x1F", "n")).code());
    }

    // --- booleans -----------------------------------------------------------------------------

    @Test
    void booleansAcceptTheDocumentedTokensCaseInsensitively() throws Exception {
        for (String t : new String[] {"true", "TRUE", " True ", "1", "yes", "Y"}) {
            assertEquals(Boolean.TRUE, Cols.optBool(t, "flag"), t);
        }
        for (String f : new String[] {"false", "FALSE", " False ", "0", "no", "N"}) {
            assertEquals(Boolean.FALSE, Cols.optBool(f, "flag"), f);
        }
    }

    /**
     * <b>Regression guard for a deliberate decision.</b> commons-lang3's
     * {@code BooleanUtils.toBooleanObject} is on the classpath and looks like a free replacement,
     * but it also accepts {@code on}/{@code off}/{@code t}/{@code f}. Swapping it in would stop
     * these rows reaching the DLQ and start coercing them — silently. If this test fails, someone
     * widened the accepted set; that is a data-quality change, not a refactor.
     */
    @Test
    void booleansRejectTokensOutsideTheDocumentedSet() {
        for (String v : new String[] {"on", "off", "t", "f", "2", "maybe", ""}) {
            assertEquals(RejectReason.VALUE_FORMAT,
                    rejects(() -> Cols.optBool(v, "flag")).code(), v);
        }
    }

    // --- decimals -----------------------------------------------------------------------------

    @Test
    void decimalsAreScaledToTheSchemaScale() throws Exception {
        assertEquals(new BigDecimal("1.50"), Cols.optDecimal("1.5", "amount", 2),
                "a shorter value is padded to the schema's scale");
        assertEquals(new BigDecimal("1.55"), Cols.optDecimal(" 1.55 ", "amount", 2));
        assertEquals(new BigDecimal("3.00"), Cols.reqDecimal("3", "amount", 2));
    }

    /**
     * {@code RoundingMode.UNNECESSARY} on purpose: more fractional digits than the Avro schema
     * holds is a rejected row, never a quietly rounded number in a financial column.
     */
    @Test
    void aDecimalWithTooManyFractionalDigitsIsRejectedNotRounded() {
        assertEquals(RejectReason.VALUE_FORMAT,
                rejects(() -> Cols.optDecimal("1.555", "amount", 2)).code());
    }

    /** Parsed via BigDecimal, never double, so no value is lost to binary floating point. */
    @Test
    void decimalsKeepPrecisionADoubleWouldLose() throws Exception {
        String exact = "12345678901234567890.12";

        assertEquals(new BigDecimal(exact), Cols.optDecimal(exact, "amount", 2));
    }

    // --- dates and timestamps -------------------------------------------------------------------

    /**
     * The source timezone is a parameter and must actually be used. Reading a local timestamp in
     * the JVM's default zone would shift every row by the deployment's offset — invisible in
     * dev, wrong in production.
     */
    @Test
    void timestampsAreInterpretedInTheGivenSourceZone() throws Exception {
        String local = "2026-09-03 12:00:00";

        long utc = Cols.optTimestampMillis(local, "ts", TS, ZoneId.of("UTC"));
        long berlin = Cols.optTimestampMillis(local, "ts", TS, ZoneId.of("Europe/Berlin"));

        assertEquals(Instant.parse("2026-09-03T12:00:00Z").toEpochMilli(), utc);
        assertEquals(2 * 3_600_000L, utc - berlin,
                "Berlin is UTC+2 in September, so the same wall clock is 2h earlier in UTC");
    }

    @Test
    void anUnparseableTimestampIsRejected() {
        assertEquals(RejectReason.VALUE_FORMAT,
                rejects(() -> Cols.optTimestampMillis("2026-09-03", "ts", TS,
                        ZoneId.of("UTC"))).code(), "a date-only value does not fit the pattern");
    }

    /** Avro's {@code date} logical type is days since the epoch, so 1970-01-01 must be 0. */
    @Test
    void datesBecomeEpochDays() throws Exception {
        DateTimeFormatter iso = DateTimeFormatter.ISO_DATE;

        assertEquals(0, Cols.optEpochDays("1970-01-01", "d", iso));
        assertEquals(1, Cols.optEpochDays("1970-01-02", "d", iso));
        assertEquals(-1, Cols.optEpochDays("1969-12-31", "d", iso),
                "dates before the epoch are negative, not truncated to zero");
        assertEquals(0, Cols.reqEpochDays("1970-01-01", "d", iso));
    }

    @Test
    void anUnparseableDateIsRejected() {
        assertEquals(RejectReason.VALUE_FORMAT,
                rejects(() -> Cols.optEpochDays("03/09/2026", "d",
                        DateTimeFormatter.ISO_DATE)).code());
    }

    // --- string helpers -------------------------------------------------------------------------

    @Test
    void stringHelpersDoWhatTheySay() {
        assertEquals("a", Cols.trim("  a  "));
        assertNull(Cols.emptyToNull(""));
        assertEquals(" ", Cols.emptyToNull(" "), "only the empty string is null, not whitespace");
        assertEquals("AB", Cols.upper("ab"));
        assertEquals("ab", Cols.lower("AB"));
    }

    /**
     * {@code upper}/{@code lower} pin {@code Locale.ROOT}. Under a Turkish default locale
     * {@code "i".toUpperCase()} is {@code "İ"}, so a normalized code would differ by deployment
     * locale — a difference that would never show up in a dev JVM.
     */
    @Test
    void caseFoldingIsLocaleIndependent() {
        Locale original = Locale.getDefault();
        try {
            Locale.setDefault(Locale.forLanguageTag("tr"));
            assertEquals("I", Cols.upper("i"));
            assertEquals("i", Cols.lower("I"));
        } finally {
            Locale.setDefault(original);
        }
    }

    /**
     * {@code reqString} is the one conversion that does <em>not</em> trim: it is a presence check
     * on a value the mapper may deliberately want verbatim. Trimming belongs at the call site,
     * via {@code Cols.trim}.
     */
    @Test
    void reqStringReturnsTheValueVerbatim() throws Exception {
        assertEquals("  padded  ", Cols.reqString("  padded  ", "id"));
    }
}
