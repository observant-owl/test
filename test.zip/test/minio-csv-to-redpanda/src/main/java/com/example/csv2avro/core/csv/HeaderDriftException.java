package com.example.csv2avro.core.csv;

/**
 * A header-shaped line arrived that does not match the pinned expected header: upstream has
 * cut over to a new CSV schema. Policy (user decision, 2026-09-01): halt this type loudly
 * until the updated {@code .avsc} + mapper + config are deployed. Thrown as an unchecked
 * exception so it fails the task and (with pipelined-region failover) restarts only this
 * type's region — pick a restart strategy the halt cannot exhaust job-wide
 * (e.g. {@code restart-strategy: exponential-delay}).
 */
public class HeaderDriftException extends RuntimeException {

    public HeaderDriftException(String message) {
        super(message);
    }
}
