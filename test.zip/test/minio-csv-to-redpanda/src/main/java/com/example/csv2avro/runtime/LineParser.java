package com.example.csv2avro.runtime;

import com.example.csv2avro.api.CsvRow;
import com.example.csv2avro.api.RejectReason;
import com.example.csv2avro.api.RowRejectedException;
import com.opencsv.CSVParserBuilder;
import com.opencsv.ICSVParser;
import java.io.IOException;
import java.io.Serializable;
import java.io.UncheckedIOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Pure (Flink-free) line-level parsing. One instance per stream, built from the pinned config
 * header.
 *
 * <p>Rests on two assumptions documented in CLAUDE.md: no CSV field contains an embedded
 * newline, and the header never changes. A same-count column <em>reorder</em> upstream is the
 * one shape that fails silently — values bind to the wrong Avro fields.
 */
public final class LineParser implements Serializable {

    private static final long serialVersionUID = 1L;

    /** Unicode escape on purpose — a literal BOM in the source is invisible and
     * unmaintainable. */
    private static final char BOM = '\uFEFF';

    private final String streamId;
    private final String expectedHeaderLine;
    private final List<String> columns;
    private final Map<String, Integer> columnIndex;
    private final Set<String> nullTokens;
    private final char delimiter;
    private final char quote;
    private final Character escape;

    /** Built lazily because {@link ICSVParser} is not serializable; {@code null} means "not
     * built yet", which is also the state after Java deserialization. Unlike its predecessor
     * this holds no cross-line state, so it never needs rebuilding. */
    private transient ICSVParser csvParser;

    public LineParser(
            String streamId,
            String expectedHeaderLine,
            char delimiter,
            char quote,
            Character escape,
            Set<String> nullTokens) {
        this.streamId = streamId;
        this.nullTokens = Set.copyOf(nullTokens);
        this.expectedHeaderLine = normalize(expectedHeaderLine);
        this.delimiter = delimiter;
        this.quote = quote;
        this.escape = escape;
        try {
            this.columns = List.copyOf(splitCsv(this.expectedHeaderLine));
        } catch (IOException e) {
            throw new IllegalArgumentException(
                    "expected-header for stream '" + streamId + "' is not parseable CSV: "
                            + expectedHeaderLine, e);
        }
        if (new HashSet<>(columns).size() != columns.size()) {
            throw new IllegalArgumentException(
                    "expected-header for stream '" + streamId
                            + "' has duplicate column names: " + columns);
        }
        Map<String, Integer> idx = new HashMap<>();
        for (int i = 0; i < columns.size(); i++) {
            idx.put(columns.get(i), i);
        }
        this.columnIndex = Map.copyOf(idx);
    }

    public List<String> columns() {
        return columns;
    }

    /** Classifies one source record. Stateless with respect to files, so it is safe to reuse
     * across them. */
    public Outcome parse(Line line) {
        switch (line.kind()) {
            case FILE_OPEN -> {
                return Outcome.of(Outcome.Kind.FILE_OPEN, line);
            }
            case CORRUPT -> {
                return Outcome.of(Outcome.Kind.CORRUPT, line);
            }
            default -> {
                return parseText(line);
            }
        }
    }

    private Outcome parseText(Line line) {
        String text = normalize(line.text());
        if (text.isEmpty()) {
            return Outcome.of(Outcome.Kind.BLANK, line);
        }

        if (text.equals(expectedHeaderLine)) {
            return Outcome.of(Outcome.Kind.HEADER, line);
        }

        List<String> fields;
        try {
            fields = splitCsv(text);
        } catch (IOException | UncheckedIOException | IllegalStateException e) {
            // opencsv signals the commonest malformation of all — an unbalanced quote — with a
            // plain IOException. The two unchecked types are caught as well because the whole
            // point of this branch is that one bad row becomes one DLQ entry: an unchecked
            // failure escaping here would kill the task and crash-loop the job on a single line.
            return Outcome.reject(RejectReason.MALFORMED_CSV, e.getMessage(), line);
        }

        if (fields.equals(columns)) {
            // Same header, different quoting/whitespace than the pinned verbatim line.
            return Outcome.of(Outcome.Kind.HEADER, line);
        }

        if (fields.size() != columns.size()) {
            return Outcome.reject(RejectReason.COLUMN_COUNT,
                    "expected " + columns.size() + " got " + fields.size(), line);
        }

        return Outcome.row(new MappedRow(fields), line);
    }

    /**
     * Splits one line via opencsv's single-line entry point, which is what it is for: it carries
     * no state between calls, so an unterminated quote throws and the next line parses cleanly
     * with nothing to reset.
     *
     * <p>{@code asList} wraps opencsv's returned array rather than copying it — the array is
     * freshly allocated per call, pinned by
     * {@code LineParserTest#rowValuesSurviveParsingTheNextLine}.
     */
    private List<String> splitCsv(String line) throws IOException {
        String[] fields = parser().parseLine(line);
        return fields == null ? List.of() : Arrays.asList(fields);
    }

    /**
     * <b>The escape character must be set explicitly.</b> opencsv defaults it to {@code \},
     * where this job's dialect defaults to none (RFC 4180 doubled quotes) — leave it and
     * {@code C:\path\file} silently becomes {@code C:pathfile}. See CLAUDE.md invariant 1.
     */
    private ICSVParser parser() {
        if (csvParser == null) {
            csvParser = new CSVParserBuilder()
                    .withSeparator(delimiter)
                    .withQuoteChar(quote)
                    .withEscapeChar(escape == null ? ICSVParser.NULL_CHARACTER : escape)
                    .withIgnoreLeadingWhiteSpace(false)
                    .withStrictQuotes(false)
                    .build();
        }
        return csvParser;
    }

    private static String normalize(String line) {
        String s = line;
        if (!s.isEmpty() && s.charAt(0) == BOM) {
            s = s.substring(1);
        }
        if (s.endsWith("\r")) {
            s = s.substring(0, s.length() - 1);
        }
        return s;
    }

    /**
     * Exactly one of: a data row, a header line, a blank line, a rejection, or one of the two
     * file signals. The file signals are never mapped or emitted downstream.
     *
     * <p>A record, unlike {@link Line} and {@link DlqRecord}: this never crosses Flink's
     * serializer. It is created in {@link LineParser#parse} and consumed in the same
     * operator, so nothing here is a POJO-contract concession.
     *
     * @param row {@code ROW} only
     * @param reason {@code REJECT} only
     * @param code {@code REJECT} only
     * @param line always present, carrying the object this came from
     */
    public record Outcome(Kind kind, CsvRow row, String reason, RejectReason code, Line line) {

        public enum Kind { ROW, HEADER, BLANK, REJECT, CORRUPT, FILE_OPEN }

        /** The raw input line, for DLQ payloads. Null for the two file signals. */
        public String rawLine() {
            return line.text();
        }

        /** The object this came from. Never null — that is the point of {@link Line}. */
        public String objectPath() {
            return line.path();
        }

        static Outcome of(Kind kind, Line line) {
            return new Outcome(kind, null, null, null, line);
        }

        static Outcome row(CsvRow row, Line line) {
            return new Outcome(Kind.ROW, row, null, null, line);
        }

        /**
         * @param code the bounded Prometheus label
         * @param reason free prose for the DLQ payload, <b>without</b> the label — prefixing it
         *     here by hand meant the two could disagree, so they are composed at the one DLQ site
         */
        static Outcome reject(RejectReason code, String reason, Line line) {
            return new Outcome(Kind.REJECT, null, reason, code, line);
        }
    }

    private final class MappedRow implements CsvRow {
        private final List<String> fields;

        MappedRow(List<String> fields) {
            this.fields = fields;
        }

        @Override
        public String get(String column) {
            Integer i = columnIndex.get(column);
            if (i == null) {
                throw new IllegalArgumentException(
                        "column '" + column + "' is not in the expected header of stream '"
                                + streamId + "' " + columns
                                + " — mapper and config disagree");
            }
            String v = fields.get(i);
            return nullTokens.contains(v) ? null : v;
        }

        @Override
        public String require(String column) throws RowRejectedException {
            String v = get(column);
            if (v == null) {
                throw new RowRejectedException(RejectReason.MISSING_REQUIRED,
                        "required column '" + column + "' is null");
            }
            return v;
        }
    }
}
