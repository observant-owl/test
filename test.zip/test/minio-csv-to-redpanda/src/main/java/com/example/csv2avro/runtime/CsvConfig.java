package com.example.csv2avro.runtime;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import org.apache.flink.configuration.ConfigOption;
import org.apache.flink.configuration.ConfigOptions;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.configuration.ConfigurationUtils;
import org.apache.flink.configuration.DelegatingConfiguration;
import org.apache.flink.configuration.ReadableConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Every configuration key the job has, and the loader that reads them.
 *
 * <p><b>One file per deployment, and it is final.</b> {@code spec.flinkConfiguration} carries
 * exactly one {@code csv2avro} key — {@link #CONFIG}, naming a resource under
 * {@code profiles/} — and everything else comes from that resource. Nothing is layered, nothing
 * is inherited, and no key defaults: what the file says is what runs, so knowing the effective
 * configuration never means reading a manifest and a file together.
 *
 * <p>The cost, accepted deliberately: a type's parsing keys are repeated in each of its
 * deployments' files, and a header change applied to some but not all of them binds values to
 * the wrong Avro fields silently. See CLAUDE.md.
 */
public final class CsvConfig {

    private static final Logger LOG = LoggerFactory.getLogger(CsvConfig.class);

    private static final String PRODUCER_PREFIX = "csv2avro.kafka.properties.";

    /** Set by the Kubernetes operator to the FlinkDeployment's {@code metadata.name}, which is
     * why the job name is not configured anywhere: the two cannot disagree. */
    private static final ConfigOption<String> CLUSTER_ID =
            ConfigOptions.key("kubernetes.cluster-id").stringType().noDefaultValue();

    /**
     * The one key a deployment sets. Names a {@code profiles/<value>.conf} resource in the jar;
     * read from {@code spec.flinkConfiguration}, never from a config file.
     */
    public static final ConfigOption<String> CONFIG =
            ConfigOptions.key("csv2avro.config").stringType().noDefaultValue()
                    .withDescription("names profiles/<value>.conf, the whole job configuration");

    // Everything below is read from that file. No option has a default: a missing key is a
    // startup failure naming it, which is also what turns a typo'd key into a loud error.

    public static final ConfigOption<String> STREAM =
            ConfigOptions.key("csv2avro.stream").stringType().noDefaultValue()
                    .withDescription("id of the CSV type to run; must match a Streams.ALL entry");

    public static final ConfigOption<String> SOURCE_PREFIX =
            ConfigOptions.key("csv2avro.prefix").stringType().noDefaultValue()
                    .withDescription("S3 prefix to ingest, e.g. s3://bucket/type-a/");

    public static final ConfigOption<String> TOPIC =
            ConfigOptions.key("csv2avro.topic").stringType().noDefaultValue()
                    .withDescription("target Kafka topic, e.g. type-a.v1");

    public static final ConfigOption<String> EXPECTED_HEADER =
            ConfigOptions.key("csv2avro.expected-header").stringType().noDefaultValue()
                    .withDescription("the verbatim header line; drives name-based binding");

    public static final ConfigOption<Duration> MONITOR_INTERVAL =
            ConfigOptions.key("csv2avro.monitor-interval").durationType().noDefaultValue()
                    .withDescription("how often to poll the prefix for new objects");

    public static final ConfigOption<String> DELIMITER =
            ConfigOptions.key("csv2avro.dialect.delimiter").stringType().noDefaultValue();

    public static final ConfigOption<String> QUOTE =
            ConfigOptions.key("csv2avro.dialect.quote").stringType().noDefaultValue();

    /** The only optional key: unset = RFC 4180 doubled quotes. */
    public static final ConfigOption<String> ESCAPE =
            ConfigOptions.key("csv2avro.dialect.escape").stringType().noDefaultValue();

    /** Don't assume UTF-8; latin-1 exports are common. */
    public static final ConfigOption<String> CHARSET =
            ConfigOptions.key("csv2avro.dialect.charset").stringType().noDefaultValue();

    /**
     * Values meaning null, matched exactly against the raw cell. Flink list syntax, so
     * {@code ''} is an empty cell, {@code 'a;b'} contains the separator. Write the empty list
     * for a type with no null tokens.
     */
    public static final ConfigOption<List<String>> NULL_TOKENS =
            ConfigOptions.key("csv2avro.dialect.null-tokens").stringType().asList()
                    .noDefaultValue();

    public static final ConfigOption<String> BOOTSTRAP_SERVERS =
            ConfigOptions.key("csv2avro.kafka.bootstrap-servers").stringType().noDefaultValue();

    public static final ConfigOption<String> SCHEMA_REGISTRY_URL =
            ConfigOptions.key("csv2avro.kafka.schema-registry-url").stringType().noDefaultValue();

    public static final ConfigOption<String> DLQ_TOPIC =
            ConfigOptions.key("csv2avro.dlq.topic").stringType().noDefaultValue();

    private CsvConfig() {
    }

    /**
     * Reads and validates the one configuration file named by {@link #CONFIG}.
     *
     * @param flinkConf the effective Flink configuration; only {@link #CONFIG} is read from it
     * @param knownStreams the registered {@code Streams.ALL} ids
     */
    public static Configuration load(ReadableConfig flinkConf, Set<String> knownStreams) {
        String name = flinkConf.getOptional(CONFIG).orElseThrow(() -> new IllegalStateException(
                CONFIG.key() + " is not set — it names the configuration this deployment runs, "
                        + "a resource under src/main/resources/profiles/. Set it in the "
                        + "FlinkDeployment's spec.flinkConfiguration."));

        Configuration conf = read(name);
        validate(conf, name, knownStreams);
        LOG.info("stream '{}' from profiles/{}.conf: prefix={}, topic={}, dlq={}, brokers={}, "
                        + "interval={}",
                conf.get(STREAM), name, conf.get(SOURCE_PREFIX), conf.get(TOPIC),
                conf.get(DLQ_TOPIC), conf.get(BOOTSTRAP_SERVERS), conf.get(MONITOR_INTERVAL));
        return conf;
    }

    /** The Flink job name, and with it the {@code job_name} label on every metric. Taken from
     * the operator's cluster id so it always equals the FlinkDeployment nobody could otherwise
     * find with kubectl; the fallback is for local runs, which have no operator. */
    public static String jobName(ReadableConfig flinkConf, String streamId) {
        return flinkConf.getOptional(CLUSTER_ID).orElse("csv2avro-" + streamId);
    }

    /**
     * Producer properties, from every {@code csv2avro.kafka.properties.<k>} key present.
     *
     * <p>A prefixed view rather than a {@code mapType()} option on purpose: flat keys are what
     * let a single producer property be set without restating the others.
     */
    public static Map<String, String> producerProperties(Configuration conf) {
        return new DelegatingConfiguration(conf, PRODUCER_PREFIX).toMap();
    }

    /**
     * Reads {@code profiles/<name>.conf} from the classpath. A name with no resource is a hard
     * failure: it is the one typo that would otherwise leave a deployment running a
     * configuration it was never pointed at.
     */
    private static Configuration read(String name) {
        String resource = "profiles/" + name + ".conf";
        try (InputStream in = CsvConfig.class.getClassLoader().getResourceAsStream(resource)) {
            if (in == null) {
                throw new IllegalStateException("no configuration '" + name + "' on the "
                        + "classpath (expected " + resource + "); check " + CONFIG.key());
            }
            Properties props = new Properties();
            // The Reader overload, because load(InputStream) decodes ISO-8859-1 — which would
            // silently mangle any non-ASCII value, a null token or delimiter most likely.
            props.load(new InputStreamReader(in, StandardCharsets.UTF_8));
            return ConfigurationUtils.createConfiguration(props);
        } catch (IOException e) {
            throw new UncheckedIOException("cannot read configuration " + resource, e);
        }
    }

    /** Collects every problem at once: one restart per deployment, not one per mistake. */
    private static void validate(Configuration conf, String name, Set<String> knownStreams) {
        List<String> errors = new ArrayList<>();

        require(conf, errors, STREAM, "the CSV type this deployment runs");
        require(conf, errors, SOURCE_PREFIX, "the S3 prefix to ingest");
        require(conf, errors, TOPIC, "the target Kafka topic");
        require(conf, errors, EXPECTED_HEADER,
                "the verbatim header line, required for name-based column binding");
        require(conf, errors, BOOTSTRAP_SERVERS, "the Redpanda bootstrap servers");
        require(conf, errors, SCHEMA_REGISTRY_URL, "the Schema Registry endpoint");
        require(conf, errors, DLQ_TOPIC, "the shared DLQ topic");
        require(conf, errors, CHARSET, "the charset of the files");

        String stream = conf.get(STREAM);
        if (stream != null && !stream.isBlank() && !knownStreams.contains(stream)) {
            errors.add(STREAM.key() + " is '" + stream + "', which is not a registered stream "
                    + "(typo in the id?). Registered: " + new TreeSet<>(knownStreams));
        }
        requireSingleChar(conf, errors, DELIMITER, "the field separator");
        requireSingleChar(conf, errors, QUOTE, "the quote character");
        if (conf.getOptional(ESCAPE).isPresent()) {
            requireSingleChar(conf, errors, ESCAPE, "the escape character");
        }
        if (read(conf, errors, NULL_TOKENS).isEmpty()) {
            errors.add(missing(NULL_TOKENS, "the tokens meaning null; write an empty value for "
                    + "a type that has none"));
        }
        try {
            Charset.forName(conf.get(CHARSET));
        } catch (Exception e) {
            errors.add("unknown " + CHARSET.key() + " '" + conf.get(CHARSET) + "'");
        }
        Optional<Duration> interval = read(conf, errors, MONITOR_INTERVAL);
        if (interval.isEmpty()) {
            errors.add(missing(MONITOR_INTERVAL, "how often to poll the prefix"));
        } else if (interval.get().isZero() || interval.get().isNegative()) {
            errors.add(MONITOR_INTERVAL.key() + " must be > 0 — a zero or negative poll interval "
                    + "is a busy loop against S3, not 'as fast as possible'");
        }

        if (!errors.isEmpty()) {
            throw new IllegalStateException("invalid configuration profiles/" + name + ".conf:\n"
                    + "  - " + String.join("\n  - ", errors));
        }
    }

    /**
     * A typed read that reports an unparseable value as one collected error rather than
     * throwing — otherwise the first bad duration hides every other mistake in the file.
     */
    private static <T> Optional<T> read(
            Configuration conf, List<String> errors, ConfigOption<T> option) {
        try {
            return conf.getOptional(option);
        } catch (RuntimeException e) {
            errors.add(option.key() + " is not a valid value: " + e.getMessage());
            return Optional.empty();
        }
    }

    private static void require(
            Configuration conf, List<String> errors, ConfigOption<String> option, String what) {
        String value = conf.get(option);
        if (value == null || value.isBlank()) {
            errors.add(missing(option, what));
        }
    }

    private static void requireSingleChar(
            Configuration conf, List<String> errors, ConfigOption<String> option, String what) {
        if (conf.get(option) == null) {
            errors.add(missing(option, what));
            return;
        }
        try {
            singleChar(conf, option);
        } catch (IllegalStateException e) {
            errors.add(e.getMessage());
        }
    }

    /**
     * The single-character rule, in one place. {@code ParserSettings} calls this to convert;
     * {@link #requireSingleChar} calls it to collect the message — so the rule cannot be stated
     * one way at startup and another where it is enforced.
     */
    public static char singleChar(ReadableConfig conf, ConfigOption<String> option) {
        String value = conf.get(option);
        if (value == null || value.length() != 1) {
            throw new IllegalStateException(
                    option.key() + " must be exactly one character, got '" + value + "'");
        }
        return value.charAt(0);
    }

    private static String missing(ConfigOption<?> option, String what) {
        return option.key() + " is not set — " + what + ". Every key is explicit: set it in "
                + "src/main/resources/profiles/<config>.conf.";
    }
}
