package com.example.csv2avro.core.spi;

import java.io.Serializable;
import org.apache.avro.specific.SpecificRecordBase;

/**
 * One CSV type, end to end. Discovered via {@link java.util.ServiceLoader}: adding a type means
 * one implementation of this interface, one {@code .avsc}, one line in
 * {@code META-INF/services}, one config block, one fixture directory — nothing else changes.
 *
 * <p>Everything per-type that is <em>data</em> (S3 prefix, topic, dialect, expected header)
 * lives in the YAML config, keyed by {@link #id()}. Only the row mapper and the Avro schema
 * are code.
 */
public interface CsvStreamDefinition<T extends SpecificRecordBase> extends Serializable {

    /** Stable identity. Drives config keys, operator uids, metric names, fixture paths. */
    String id();

    /** The generated Avro class, from {@code src/main/avro/<id>.avsc}. */
    Class<T> avroClass();

    /** The normalize / remove / change / add logic for one row. */
    RowMapper<T> mapper();

    /** Kafka message key. Default null = round-robin partitioning (fine: no per-key ordering
     * requirement exists — same business key always means same content upstream). */
    default KeyExtractor<T> keyExtractor() {
        return record -> null;
    }
}
