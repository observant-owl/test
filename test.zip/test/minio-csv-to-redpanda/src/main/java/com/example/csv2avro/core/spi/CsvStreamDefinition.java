package com.example.csv2avro.core.spi;

import java.io.Serializable;
import org.apache.avro.specific.SpecificRecordBase;

/**
 * One CSV type, end to end. Everything per-type that is <em>data</em> (S3 prefix, topic,
 * dialect, expected header) lives in the YAML config, keyed by {@link #id()}; only the mapper
 * and the Avro schema are code.
 *
 * @param id stable identity — drives config keys, operator uids, metric labels, fixture paths
 * @param avroClass the generated Avro class, from {@code src/main/avro/<id>.avsc}
 * @param mapper the normalize / remove / change / add logic for one row
 * @param keyExtractor Kafka message key. A lambda yielding {@code null} per record means
 *     round-robin — <b>never a null extractor</b>, which NPEs in the sink at record time.
 */
public record CsvStreamDefinition<T extends SpecificRecordBase>(
        String id,
        Class<T> avroClass,
        RowMapper<T> mapper,
        KeyExtractor<T> keyExtractor)
        implements Serializable {

    /** Round-robin partitioning: no per-key ordering requirement exists, because the same
     * business key always means the same content upstream. */
    public CsvStreamDefinition(String id, Class<T> avroClass, RowMapper<T> mapper) {
        this(id, avroClass, mapper, record -> null);
    }
}
