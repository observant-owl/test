package com.example.csv2avro.api;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;

/**
 * Column helpers for mappers. Null-safe throughout — null in, null out, except the {@code req*}
 * variants, which reject the row.
 *
 * <p><b>Every non-string conversion in a mapper must go through here</b>, or a parse failure
 * kills the task instead of producing a counted DLQ entry naming the column and value.
 *
 * <p>Both variants of each conversion exist so the choice is explicit at the call site. There
 * is no "default to zero" variant on purpose — a silently defaulted number is indistinguishable
 * from a real one downstream. Timestamps take an explicit source timezone, never the JVM
 * default.
 */
public final class Cols {

    private Cols() {
    }

    public static String trim(String v) {
        return v == null ? null : v.trim();
    }

    public static String emptyToNull(String v) {
        return v == null || v.isEmpty() ? null : v;
    }

    public static String upper(String v) {
        return v == null ? null : v.toUpperCase(Locale.ROOT);
    }

    public static String lower(String v) {
        return v == null ? null : v.toLowerCase(Locale.ROOT);
    }

    /** The one throw site for {@link RejectReason#MISSING_REQUIRED}. */
    private static <T> T required(T v, String column, String what) throws RowRejectedException {
        if (v == null) {
            throw new RowRejectedException(RejectReason.MISSING_REQUIRED,
                    "column '" + column + "': required " + what + " is null");
        }
        return v;
    }

    /** One conversion attempt on an already-trimmed, non-null value. */
    @FunctionalInterface
    private interface Conversion<T> {
        T apply(String trimmed);
    }

    /**
     * The one throw site for {@link RejectReason#VALUE_FORMAT}. {@code describe} is the whole
     * phrase ("not a long", "unparseable timestamp"), so each conversion keeps its wording
     * without restating the message format seven times.
     */
    private static <T> T optional(
            String v, String column, String describe, Conversion<T> conversion)
            throws RowRejectedException {
        if (v == null) {
            return null;
        }
        try {
            return conversion.apply(v.trim());
        } catch (NumberFormatException | ArithmeticException | DateTimeParseException e) {
            // NumberFormatException = unparseable; ArithmeticException = too many digits for
            // a decimal's scale; DateTimeParseException = bad date/time. All the same story to
            // whoever reads the DLQ.
            throw new RowRejectedException(RejectReason.VALUE_FORMAT,
                    "column '" + column + "': " + describe + ": '" + v + "'");
        }
    }

    /** A string column that must be present. Use for non-nullable Avro string fields: Avro
     * would otherwise fail on write with a schema error that names no column. */
    public static String reqString(String v, String column) throws RowRejectedException {
        return required(v, column, "string");
    }

    /**
     * The finiteness check matters: {@code Double.valueOf} accepts {@code "NaN"} and
     * {@code "Infinity"}, which are almost always an undeclared null sentinel that would poison
     * every downstream aggregate silently. A source that legitimately writes {@code NaN} for
     * "no value" declares it in {@code dialect.null-tokens}.
     */
    public static Double optDouble(String v, String column) throws RowRejectedException {
        Double d = optional(v, column, "not a double", Double::valueOf);
        if (d != null && !Double.isFinite(d)) {
            throw new RowRejectedException(RejectReason.VALUE_FORMAT,
                    "column '" + column + "': not a finite double: '" + v + "'");
        }
        return d;
    }

    public static double reqDouble(String v, String column) throws RowRejectedException {
        return required(optDouble(v, column), column, "double");
    }

    public static Long optLong(String v, String column) throws RowRejectedException {
        return optional(v, column, "not a long", Long::valueOf);
    }

    public static long reqLong(String v, String column) throws RowRejectedException {
        return required(optLong(v, column), column, "long");
    }

    public static Integer optInt(String v, String column) throws RowRejectedException {
        return optional(v, column, "not an int", Integer::valueOf);
    }

    public static int reqInt(String v, String column) throws RowRejectedException {
        return required(optInt(v, column), column, "int");
    }

    public static Boolean optBool(String v, String column) throws RowRejectedException {
        if (v == null) {
            return null;
        }
        return switch (v.trim().toLowerCase(Locale.ROOT)) {
            case "true", "1", "yes", "y" -> Boolean.TRUE;
            case "false", "0", "no", "n" -> Boolean.FALSE;
            default -> throw new RowRejectedException(RejectReason.VALUE_FORMAT,
                    "column '" + column + "': not a boolean: '" + v + "'");
        };
    }

    public static boolean reqBool(String v, String column) throws RowRejectedException {
        return required(optBool(v, column), column, "boolean");
    }

    /**
     * Fixed-scale decimal for Avro's {@code decimal} logical type. {@link
     * RoundingMode#UNNECESSARY} on purpose: a value with more fractional digits than the schema
     * allows is a rejected row, never a silently rounded number in a financial column. Parsed
     * via {@code BigDecimal}, never {@code double}.
     */
    public static BigDecimal optDecimal(String v, String column, int scale)
            throws RowRejectedException {
        return optional(v, column, "not a decimal(scale=" + scale + ")",
                s -> new BigDecimal(s).setScale(scale, RoundingMode.UNNECESSARY));
    }

    public static BigDecimal reqDecimal(String v, String column, int scale)
            throws RowRejectedException {
        return required(optDecimal(v, column, scale), column, "decimal");
    }

    /** Local date-time in the given source zone → epoch millis (timestamp-millis). */
    public static Long optTimestampMillis(
            String v, String column, DateTimeFormatter format, ZoneId sourceZone)
            throws RowRejectedException {
        return optional(v, column, "unparseable timestamp",
                s -> LocalDateTime.parse(s, format).atZone(sourceZone).toInstant()
                        .toEpochMilli());
    }

    public static long reqTimestampMillis(
            String v, String column, DateTimeFormatter format, ZoneId sourceZone)
            throws RowRejectedException {
        return required(optTimestampMillis(v, column, format, sourceZone), column, "timestamp");
    }

    /** Date-only column → epoch days (Avro {@code date} logical type). */
    public static Integer optEpochDays(String v, String column, DateTimeFormatter format)
            throws RowRejectedException {
        return optional(v, column, "unparseable date",
                s -> (int) LocalDate.parse(s, format).toEpochDay());
    }

    public static int reqEpochDays(String v, String column, DateTimeFormatter format)
            throws RowRejectedException {
        return required(optEpochDays(v, column, format), column, "date");
    }
}
