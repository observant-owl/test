package com.example.csv2avro.api;

import java.io.Serializable;
import org.apache.avro.specific.SpecificRecordBase;

/** Derives the Kafka message key from a record. Null means no key (round-robin). */
@FunctionalInterface
public interface KeyExtractor<T extends SpecificRecordBase> extends Serializable {

    String key(T record);
}
