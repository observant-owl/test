package com.example.csv2avro.runtime;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.UnaryOperator;
import org.apache.flink.configuration.ConfigOption;
import org.apache.flink.configuration.ConfigOptions;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.configuration.ConfigurationUtils;
import org.apache.flink.configuration.DelegatingConfiguration;
import org.apache.flink.configuration.ReadableConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Every configuration key the job has, and the loader that reads them.
 *
 * <p><b>One file per deployment, and it is final.</b> The job's two arguments — {@code <env>} and
 * {@code <type>} — name a {@code profiles/<env>-<type>.conf} resource in the jar, and everything
 * else comes from that resource. Nothing is layered, nothing is inherited, and no key defaults:
 * what the file says is what runs, so knowing the effective configuration never means reading a
 * manifest and a file together.
 *
 * <p><b>The keys are unprefixed on purpose.</b> They used to carry a {@code csv2avro.} namespace
 * because the selector key had to coexist with Flink's own flat keyspace inside
 * {@code spec.flinkConfiguration}. The selector is an argument now, so this {@link Configuration}
 * is standalone — it is never merged into Flink's — and the prefix was noise on every line. Do
 * not merge the two configurations, and the bare names stay safe.
 *
 * <p>The cost, accepted deliberately: a type's parsing keys are repeated in each of its
 * deployments' files, and a header change applied to some but not all of them binds values to
 * the wrong Avro fields silently. See CLAUDE.md.
 */
public final class Profile {

    private static final Logger LOG = LoggerFactory.getLogger(Profile.class);

    private static final String PRODUCER_PREFIX = "kafka.properties.";
    private static final String REGISTRY_PREFIX = "kafka.schema-registry.properties.";

    /**
     * The one environment whose credentials may come from the environment instead of the file,
     * because a laptop has no Vault to resolve them. Every other environment requires them
     * present, so a missing credential in a real deployment is still a startup failure.
     */
    public static final String LOCAL_ENV = "dev-local";

    static final String ACCESS_KEY_ENV = "CSV_SOURCE_S3_ACCESS_KEY";
    static final String SECRET_KEY_ENV = "CSV_SOURCE_S3_SECRET_KEY";
    static final String SASL_JAAS_ENV = "CSV_KAFKA_SASL_JAAS_CONFIG";
    static final String REGISTRY_USER_INFO_ENV = "CSV_SCHEMA_REGISTRY_USER_INFO";

    // The two credential-bearing keys inside the open namespaces below. They get constants only
    // because the dev-local fallback has to name them; every other key under those prefixes is
    // reached by prefix alone and never appears in Java.
    static final ConfigOption<String> SASL_JAAS_CONFIG =
            ConfigOptions.key(PRODUCER_PREFIX + "sasl.jaas.config").stringType().noDefaultValue();

    static final ConfigOption<String> REGISTRY_USER_INFO =
            ConfigOptions.key(REGISTRY_PREFIX + "basic.auth.user.info").stringType()
                    .noDefaultValue();

    // Everything below is read from the profile. No option has a default, so a missing key reads
    // as null and fails wherever it is first used — during graph assembly, on the JobManager,
    // before any record moves. Nothing pre-checks the file; see load().
    //
    // There is deliberately no `stream` key. The type is argv[1], so a key here would be a second
    // source of truth for the same fact — and profiles/dev-type-a.conf saying `stream = type-b`
    // is a drift nothing could catch.

    public static final ConfigOption<String> SOURCE_PREFIX =
            ConfigOptions.key("prefix").stringType().noDefaultValue()
                    .withDescription("object prefix to ingest, e.g. type-a/; resolved against "
                            + "source.s3.bucket unless it already carries a scheme");

    public static final ConfigOption<String> TOPIC =
            ConfigOptions.key("topic").stringType().noDefaultValue()
                    .withDescription("target Kafka topic, e.g. type-a.v1");

    public static final ConfigOption<String> EXPECTED_HEADER =
            ConfigOptions.key("expected-header").stringType().noDefaultValue()
                    .withDescription("the verbatim header line; drives name-based binding");

    public static final ConfigOption<Duration> MONITOR_INTERVAL =
            ConfigOptions.key("monitor-interval").durationType().noDefaultValue()
                    .withDescription("how often to poll the prefix for new objects");

    // --- the data MinIO -------------------------------------------------------------------
    //
    // Optional AS A GROUP: all four of endpoint/region/access-key/secret-key present means the
    // source gets its own S3 client (OwnFileSource.withFileSystem), which is what lets the CSV
    // objects live on a different MinIO from checkpoints and HA. All four absent means the source
    // uses Flink's s3.* filesystem plugin, the older single-MinIO arrangement. A PARTIAL block
    // does not silently become either one — S3Settings refuses to hold a null field.

    public static final ConfigOption<String> SOURCE_S3_ENDPOINT =
            ConfigOptions.key("source.s3.endpoint").stringType().noDefaultValue()
                    .withDescription("data MinIO endpoint; absent = use Flink's s3.* plugin");

    public static final ConfigOption<String> SOURCE_S3_REGION =
            ConfigOptions.key("source.s3.region").stringType().noDefaultValue();

    public static final ConfigOption<String> SOURCE_S3_ACCESS_KEY =
            ConfigOptions.key("source.s3.access-key").stringType().noDefaultValue();

    public static final ConfigOption<String> SOURCE_S3_SECRET_KEY =
            ConfigOptions.key("source.s3.secret-key").stringType().noDefaultValue();

    /** Required in both modes: it is how a schemeless {@link #SOURCE_PREFIX} resolves. */
    public static final ConfigOption<String> SOURCE_S3_BUCKET =
            ConfigOptions.key("source.s3.bucket").stringType().noDefaultValue()
                    .withDescription("bucket holding the CSV objects");

    // --- dialect --------------------------------------------------------------------------

    public static final ConfigOption<String> DELIMITER =
            ConfigOptions.key("dialect.delimiter").stringType().noDefaultValue();

    public static final ConfigOption<String> QUOTE =
            ConfigOptions.key("dialect.quote").stringType().noDefaultValue();

    /** Unset = RFC 4180 doubled quotes. One of only two keys that may be absent. */
    public static final ConfigOption<String> ESCAPE =
            ConfigOptions.key("dialect.escape").stringType().noDefaultValue();

    /** Don't assume UTF-8; latin-1 exports are common. */
    public static final ConfigOption<String> CHARSET =
            ConfigOptions.key("dialect.charset").stringType().noDefaultValue();

    /**
     * Values meaning null, matched exactly against the raw cell. Flink list syntax, so
     * {@code ''} is an empty cell, {@code 'a;b'} contains the separator. Write the empty list
     * for a type with no null tokens.
     */
    public static final ConfigOption<List<String>> NULL_TOKENS =
            ConfigOptions.key("dialect.null-tokens").stringType().asList().noDefaultValue();

    // --- Kafka ----------------------------------------------------------------------------

    public static final ConfigOption<String> BOOTSTRAP_SERVERS =
            ConfigOptions.key("kafka.bootstrap-servers").stringType().noDefaultValue();

    public static final ConfigOption<String> SCHEMA_REGISTRY_URL =
            ConfigOptions.key("kafka.schema-registry-url").stringType().noDefaultValue();

    public static final ConfigOption<String> DLQ_TOPIC =
            ConfigOptions.key("dlq.topic").stringType().noDefaultValue();

    private Profile() {
    }

    /**
     * Reads {@code profiles/<env>-<type>.conf}.
     *
     * <p><b>Nothing here validates the file.</b> The profiles are committed, reviewed and shipped
     * inside the jar, so they cannot change between build and run — a validator would be checking
     * an input that is already fixed. What is still checked is what does <em>not</em> come from
     * the file: the two arguments, which come from kustomize overlays nothing compiles.
     *
     * @param env the deployment environment, {@code argv[0]} — {@code dev}, {@code prod},
     *     {@code missing-files}, {@code dev-local}
     * @param type the CSV type, {@code argv[1]}; must be a registered {@code Streams.ALL} id
     * @param knownStreams the registered ids
     */
    public static Configuration load(String env, String type, Set<String> knownStreams) {
        return load(env, type, knownStreams, System::getenv);
    }

    /**
     * The environment lookup is a parameter so {@code ProfileTest} can exercise the
     * {@code dev-local} credential fallback — {@code System.getenv} cannot be set from Java, and
     * configuring it in surefire would turn the fallback on for every test at once.
     */
    static Configuration load(String env, String type, Set<String> knownStreams,
            UnaryOperator<String> environment) {
        // Checked before the resource is read: "type-x is not a registered stream" is a far
        // better error than "no profiles/dev-type-x.conf", and a typo produces both.
        if (!knownStreams.contains(type)) {
            throw new IllegalStateException("'" + type + "' is not a registered stream (typo in "
                    + "the second argument?). Registered: " + new TreeSet<>(knownStreams));
        }

        Configuration conf = read(env, type);
        if (LOCAL_ENV.equals(env)) {
            copyEnv(conf, SOURCE_S3_ACCESS_KEY, ACCESS_KEY_ENV, environment);
            copyEnv(conf, SOURCE_S3_SECRET_KEY, SECRET_KEY_ENV, environment);
            copyEnv(conf, SASL_JAAS_CONFIG, SASL_JAAS_ENV, environment);
            copyEnv(conf, REGISTRY_USER_INFO, REGISTRY_USER_INFO_ENV, environment);
        }

        S3Settings s3 = sourceS3(conf);
        LOG.info("stream '{}' from profiles/{}-{}.conf: prefix={}, topic={}, dlq={}, brokers={}, "
                        + "interval={}, source filesystem={}",
                type, env, type, objectPrefix(conf), conf.get(TOPIC), conf.get(DLQ_TOPIC),
                conf.get(BOOTSTRAP_SERVERS), conf.get(MONITOR_INTERVAL),
                s3 == null ? "Flink s3.* plugin" : s3);
        return conf;
    }

    /**
     * The data MinIO, or {@code null} when the source should use Flink's {@code s3.*} plugin.
     *
     * <p>The endpoint alone decides the mode, because it is the key that has no meaning in plugin
     * mode. A block that sets it and then omits one of the other four does not fall through to
     * the plugin quietly — {@link S3Settings} refuses to hold a null, so it fails at startup
     * naming the key.
     */
    public static S3Settings sourceS3(Configuration conf) {
        if (isBlank(conf.get(SOURCE_S3_ENDPOINT))) {
            return null;
        }
        return new S3Settings(
                conf.get(SOURCE_S3_ENDPOINT), conf.get(SOURCE_S3_ACCESS_KEY),
                conf.get(SOURCE_S3_SECRET_KEY), conf.get(SOURCE_S3_REGION),
                conf.get(SOURCE_S3_BUCKET));
    }

    /**
     * The prefix as a complete URI. One rule, no special cases: a {@link #SOURCE_PREFIX} carrying
     * a scheme is used verbatim, and a schemeless one resolves against {@code s3://<bucket>/}.
     *
     * <p>Shipped profiles all use the schemeless form, which keeps the bucket named in exactly one
     * place. The verbatim branch is what lets {@code SourceContractTest} point the job at a local
     * {@code file:} temp directory without the source needing a test-only mode.
     */
    public static String objectPrefix(Configuration conf) {
        String prefix = conf.get(SOURCE_PREFIX);
        if (prefix.contains("://")) {
            return prefix;
        }
        return "s3://" + conf.get(SOURCE_S3_BUCKET) + "/" + prefix.replaceFirst("^/+", "");
    }

    /**
     * Producer properties, from every {@code kafka.properties.<k>} key present.
     *
     * <p>A prefixed view rather than a {@code mapType()} option on purpose: flat keys are what
     * let a single producer property be set without restating the others.
     */
    public static Map<String, String> producerProperties(Configuration conf) {
        return new DelegatingConfiguration(conf, PRODUCER_PREFIX).toMap();
    }

    /**
     * Schema Registry client properties, from every {@code kafka.schema-registry.properties.<k>}
     * key present — {@code basic.auth.credentials.source} and {@code basic.auth.user.info} today.
     *
     * <p>Open for the same reason the producer namespace is: the registry's auth scheme is the
     * registry's business, so switching from basic to bearer is a profile edit rather than a Java
     * one. Note these do <em>not</em> reach the producer — a Kafka client and a registry client
     * are configured separately, and {@code kafka.properties.*} never gets here.
     */
    public static Map<String, String> registryProperties(Configuration conf) {
        return new DelegatingConfiguration(conf, REGISTRY_PREFIX).toMap();
    }

    /**
     * Reads {@code profiles/<env>-<type>.conf} from the classpath. A name with no resource is a
     * hard failure: it is the one typo that would otherwise leave a deployment running a
     * configuration it was never pointed at.
     */
    private static Configuration read(String env, String type) {
        String resource = "profiles/" + env + "-" + type + ".conf";
        try (InputStream in = Profile.class.getClassLoader().getResourceAsStream(resource)) {
            if (in == null) {
                throw new IllegalStateException("no configuration for environment '" + env
                        + "' and type '" + type + "' on the classpath (expected " + resource
                        + "); check the job's two arguments");
            }
            Properties props = new Properties();
            // The Reader overload, because load(InputStream) decodes ISO-8859-1 — which would
            // silently mangle any non-ASCII value, a null token or delimiter most likely.
            props.load(new InputStreamReader(in, StandardCharsets.UTF_8));
            return ConfigurationUtils.createConfiguration(props);
        } catch (IOException e) {
            throw new UncheckedIOException("cannot read configuration " + resource, e);
        }
    }

    /**
     * Local runs only. A laptop has no Vault, so {@code dev-local}'s profile omits its four
     * credential keys and they arrive as environment variables instead — see run-local.sh, which
     * sources .env before launching. The fallback is per-key and each key is named explicitly:
     * nothing interpolates inside a config value, so the Vault path strings the other profiles
     * carry are never rewritten, and a committed profile never has to hold a credential.
     */
    private static void copyEnv(Configuration conf, ConfigOption<String> option, String var,
            UnaryOperator<String> environment) {
        String value = environment.apply(var);
        if (isBlank(conf.get(option)) && !isBlank(value)) {
            conf.set(option, value);
        }
    }

    /**
     * A conversion, not a check — {@code ParserSettings} needs a {@code char} and the profile
     * holds a {@code String}. It throws on anything that is not exactly one character because
     * there is no {@code char} to return, and it names the key because that costs nothing.
     */
    public static char singleChar(ReadableConfig conf, ConfigOption<String> option) {
        String value = conf.get(option);
        if (value == null || value.length() != 1) {
            throw new IllegalStateException(
                    option.key() + " must be exactly one character, got '" + value + "'");
        }
        return value.charAt(0);
    }

    private static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}
