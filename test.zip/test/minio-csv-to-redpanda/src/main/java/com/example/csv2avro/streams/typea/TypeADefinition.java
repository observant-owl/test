package com.example.csv2avro.streams.typea;

import com.example.csv2avro.core.spi.CsvStreamDefinition;
import com.example.csv2avro.core.spi.KeyExtractor;
import com.example.csv2avro.core.spi.RowMapper;
import com.example.csv2avro.generated.TypeA;

/**
 * TEMPLATE stream definition — the worked example the other four types are copied from.
 *
 * <p>Adding/finishing a type touches exactly:
 * <ol>
 *   <li>{@code src/main/avro/<id>.avsc} — the target schema</li>
 *   <li>this definition + a mapper class in {@code streams/<id>/}</li>
 *   <li>one line in {@code META-INF/services/com.example.csv2avro.core.spi.CsvStreamDefinition}</li>
 *   <li>one {@code streams.<id>} block in each config profile (prefix, topic, expectedHeader,
 *       dialect)</li>
 *   <li>one fixture directory {@code src/test/resources/fixtures/<id>/} (input.csv +
 *       expected.json) — the conformance harness fails loudly if it's missing</li>
 * </ol>
 */
public class TypeADefinition implements CsvStreamDefinition<TypeA> {

    private static final long serialVersionUID = 1L;

    @Override
    public String id() {
        return "type-a"; // must match the config key, the .avsc name, and the fixture dir
    }

    @Override
    public Class<TypeA> avroClass() {
        return TypeA.class;
    }

    @Override
    public RowMapper<TypeA> mapper() {
        return new TypeAMapper();
    }

    @Override
    public KeyExtractor<TypeA> keyExtractor() {
        // TODO(user): return the content-derived business key if you want key-partitioned
        // topics; null (the default) means round-robin. ClickHouse dedup does not need this —
        // its ORDER BY key comes from row content either way.
        return record -> null;
    }
}
