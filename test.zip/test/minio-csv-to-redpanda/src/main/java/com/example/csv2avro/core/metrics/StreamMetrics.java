package com.example.csv2avro.core.metrics;

import com.example.csv2avro.core.spi.RejectReason;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import org.apache.flink.metrics.Counter;
import org.apache.flink.metrics.Gauge;
import org.apache.flink.metrics.MetricGroup;

/**
 * Every metric name and label this job exports, in one reviewable place.
 *
 * <p>Scope is {@code csv2avro} + a keyed {@code stream} group. The keyed form matters:
 * {@code addGroup(String)} extends the metric <em>name</em> only, while
 * {@code addGroup(key, value)} keeps the key in the name <em>and</em> emits the value as a
 * Prometheus label. So the exported series are
 * {@code ..._csv2avro_stream_recordsOut{stream="type-a"}} and
 * {@code ..._csv2avro_stream_reason_rowsRejected{stream="type-a",reason="column-count"}}.
 * Before this class the CSV type was only visible through Flink's incidental
 * {@code operator_name} variable, which made every query depend on an operator naming
 * convention.
 *
 * <p>Two rules that are easy to break and expensive to debug:
 *
 * <ul>
 *   <li><b>Pre-create every {@code reason} counter.</b> A series that first appears on error has
 *       no {@code rate()} baseline, and an absent series is indistinguishable from a zero one —
 *       so an alert on it silently never fires. Six zero-valued series per stream is free.
 *   <li><b>Never call {@code dec()}.</b> Flink's Prometheus reporter exports counters as
 *       {@code TYPE gauge} (Flink counters <em>can</em> decrement), but {@code rate()} and
 *       {@code increase()} detect resets by value decrease regardless of the declared type, so
 *       strictly monotonic counters behave correctly and survive task restarts. One
 *       {@code dec()} breaks that.
 * </ul>
 *
 * <p>Takes a {@link MetricGroup} rather than a runtime context so it can be unit-tested against
 * a recording double — see {@code StreamMetricsTest}.
 */
public final class StreamMetrics {

    private final Counter recordsOut;
    private final Counter headerLinesDropped;
    private final Counter blankLinesDropped;
    private final Counter corruptFilesSkipped;
    private final Counter headerDriftHalts;
    private final Counter mapperFailures;
    private final Counter filesOpened;
    private final Counter filesCompleted;
    private final Counter objectBytesRead;
    private final Map<RejectReason, Counter> rowsRejected;

    /**
     * Newest file modification time seen by this subtask, epoch millis; 0 until the first file.
     * Volatile because the reporter thread reads it while the operator thread writes.
     *
     * <p>Exported as an absolute timestamp, not a pre-computed age. That is the idiomatic
     * Prometheus form and wins three ways: no JVM-vs-Prometheus clock skew baked into a stored
     * number, cross-subtask aggregation is a clean {@code max} (a {@code min} over ages would be
     * dominated by subtasks that were assigned no splits), and "nothing seen yet" is an honest
     * {@code 0} you filter with {@code > 0} rather than a sentinel. Age is then
     * {@code time() - (max by (stream) (..._newestFileModifiedMillis > 0) / 1000)}.
     */
    private volatile long newestFileModifiedMillis;

    public StreamMetrics(MetricGroup root, String streamId) {
        MetricGroup g = root.addGroup("csv2avro").addGroup("stream", streamId);

        recordsOut = g.counter("recordsOut");
        headerLinesDropped = g.counter("headerLinesDropped");
        blankLinesDropped = g.counter("blankLinesDropped");
        corruptFilesSkipped = g.counter("corruptFilesSkipped");
        headerDriftHalts = g.counter("headerDriftHalts");
        mapperFailures = g.counter("mapperFailures");
        filesOpened = g.counter("filesOpened");
        filesCompleted = g.counter("filesCompleted");
        objectBytesRead = g.counter("objectBytesRead");

        Map<RejectReason, Counter> byReason = new EnumMap<>(RejectReason.class);
        for (RejectReason r : RejectReason.values()) {
            byReason.put(r, g.addGroup("reason", r.label()).counter("rowsRejected"));
        }
        rowsRejected = Collections.unmodifiableMap(byReason);

        g.gauge("newestFileModifiedMillis", (Gauge<Long>) () -> newestFileModifiedMillis);
    }

    /** One Avro record emitted downstream. The throughput SLI — not the same as Flink's
     * {@code numRecordsOut}, which also counts DLQ side-output records. */
    public void recordOut() {
        recordsOut.inc();
    }

    /** One row sent to the DLQ, bucketed by cause. */
    public void rowRejected(RejectReason code) {
        rowsRejected.get(code == null ? RejectReason.MAPPER_OTHER : code).inc();
    }

    public void headerLineDropped() {
        headerLinesDropped.inc();
    }

    public void blankLineDropped() {
        blankLinesDropped.inc();
    }

    /** A file was skipped unread or part-read: silent data loss at file granularity. Any
     * increase is actionable. */
    public void corruptFileSkipped() {
        corruptFilesSkipped.inc();
    }

    public void headerDriftHalt() {
        headerDriftHalts.inc();
    }

    /** A mapper threw something other than {@code RowRejectedException}. Without this the task
     * dies incrementing nothing — an entirely invisible failure mode. */
    public void mapperFailure() {
        mapperFailures.inc();
    }

    /** Entering a file. Separates "upstream is idle" from "we are stuck": files opening while
     * {@code recordsOut} stays flat is the stuck signature. */
    public void fileOpened(long modifiedMillis, long sizeBytes) {
        filesOpened.inc();
        observeModified(modifiedMillis);
    }

    /**
     * A file was read to the end. {@code filesOpened − filesCompleted − corruptFilesSkipped}
     * growing without bound means files are being started and abandoned.
     *
     * <p>Bytes are counted here, not at open, so the counter reflects bytes actually read
     * rather than bytes promised. Both counters are at-least-once like everything else: a
     * checkpoint taken between the marker and end-of-split replays the file and recounts it.
     */
    public void fileCompleted(long modifiedMillis, long sizeBytes) {
        filesCompleted.inc();
        if (sizeBytes > 0) {
            objectBytesRead.inc(sizeBytes);
        }
        observeModified(modifiedMillis);
    }

    private void observeModified(long modifiedMillis) {
        if (modifiedMillis > newestFileModifiedMillis) {
            newestFileModifiedMillis = modifiedMillis;
        }
    }

    /** Visible for tests. */
    public long newestFileModifiedMillis() {
        return newestFileModifiedMillis;
    }
}
