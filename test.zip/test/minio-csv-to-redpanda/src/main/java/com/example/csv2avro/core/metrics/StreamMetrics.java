package com.example.csv2avro.core.metrics;

import com.example.csv2avro.core.spi.RejectReason;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import org.apache.flink.metrics.Counter;
import org.apache.flink.metrics.Gauge;
import org.apache.flink.metrics.MetricGroup;

/**
 * Every metric name and label this job exports, in one place. See CLAUDE.md for the exported
 * series and their known limits.
 *
 * <p>{@code addGroup(key, value)} rather than {@code addGroup(String)}: the two-argument form
 * emits the value as a Prometheus <em>label</em>, not just a longer metric name.
 *
 * <p>Two rules that are easy to break and expensive to debug:
 * <ul>
 *   <li><b>Pre-create every {@code reason} counter.</b> An absent series is indistinguishable
 *       from a zero one, so an alert on it silently never fires.
 *   <li><b>Never call {@code dec()}.</b> {@code rate()} treats any decrease as a counter reset.
 * </ul>
 */
public final class StreamMetrics {

    private final Counter recordsOut;
    private final Counter rowsDropped;
    private final Counter headerLinesDropped;
    private final Counter blankLinesDropped;
    private final Counter corruptFilesSkipped;
    private final Counter mapperFailures;
    private final Counter filesOpened;
    private final Counter objectBytesRead;
    private final Map<RejectReason, Counter> rowsRejected;

    /**
     * Newest file mtime seen by this subtask, epoch millis; 0 until the first file. Volatile:
     * the reporter thread reads it while the operator thread writes.
     *
     * <p>An absolute timestamp rather than a pre-computed age, so there is no clock skew baked
     * in and cross-subtask aggregation is a clean {@code max}.
     */
    private volatile long newestFileModifiedMillis;

    public StreamMetrics(MetricGroup root, String streamId) {
        MetricGroup g = root.addGroup("csv2avro").addGroup("stream", streamId);

        recordsOut = g.counter("recordsOut");
        rowsDropped = g.counter("rowsDropped");
        headerLinesDropped = g.counter("headerLinesDropped");
        blankLinesDropped = g.counter("blankLinesDropped");
        corruptFilesSkipped = g.counter("corruptFilesSkipped");
        mapperFailures = g.counter("mapperFailures");
        filesOpened = g.counter("filesOpened");
        objectBytesRead = g.counter("objectBytesRead");

        Map<RejectReason, Counter> byReason = new EnumMap<>(RejectReason.class);
        for (RejectReason r : RejectReason.values()) {
            byReason.put(r, g.addGroup("reason", r.label()).counter("rowsRejected"));
        }
        rowsRejected = Collections.unmodifiableMap(byReason);

        g.gauge("newestFileModifiedMillis", (Gauge<Long>) () -> newestFileModifiedMillis);
    }

    /** One Avro record emitted downstream. The throughput SLI — not the same as Flink's
     * {@code numRecordsOut}, which also counts DLQ side-output records. */
    public void recordOut() {
        recordsOut.inc();
    }

    /**
     * A row the mapper deliberately filtered out — a business rule, not an error. Kept separate
     * from {@code rowsRejected} so the DLQ-rate alert stays meaningful, and counted rather than
     * ignored because the {@code null} convention's one hazard is a fall-through quietly eating
     * rows. Watch {@code rowsDropped / (rowsDropped + recordsOut)}.
     */
    public void rowDropped() {
        rowsDropped.inc();
    }

    /** One row sent to the DLQ, bucketed by cause. */
    public void rowRejected(RejectReason code) {
        rowsRejected.get(code).inc();
    }

    public void headerLineDropped() {
        headerLinesDropped.inc();
    }

    public void blankLineDropped() {
        blankLinesDropped.inc();
    }

    /** A file was skipped unread or part-read: silent data loss at file granularity. Any
     * increase is actionable. */
    public void corruptFileSkipped() {
        corruptFilesSkipped.inc();
    }

    /** A mapper threw something other than {@code RowRejectedException}. Usually never scraped
     * — the task dies first; the log line and DLQ entry are the reliable signals. */
    public void mapperFailure() {
        mapperFailures.inc();
    }

    /**
     * Entering a file. Files opening while {@code recordsOut} stays flat is the "stuck"
     * signature, as opposed to "upstream is idle".
     *
     * <p>Bytes are counted here, not at end-of-file, so {@code objectBytesRead} is bytes
     * <em>attempted</em>: an abandoned file still contributes its full size.
     */
    public void fileOpened(long modifiedMillis, long sizeBytes) {
        filesOpened.inc();
        if (sizeBytes > 0) {
            objectBytesRead.inc(sizeBytes);
        }
        observeModified(modifiedMillis);
    }

    private void observeModified(long modifiedMillis) {
        if (modifiedMillis > newestFileModifiedMillis) {
            newestFileModifiedMillis = modifiedMillis;
        }
    }

    /** Visible for tests. */
    public long newestFileModifiedMillis() {
        return newestFileModifiedMillis;
    }
}
