package com.example.csv2avro.core.kafka;

import com.example.csv2avro.core.spi.KeyExtractor;
import java.nio.charset.StandardCharsets;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.flink.api.common.serialization.SerializationSchema;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema;
import org.apache.kafka.clients.producer.ProducerRecord;

/**
 * Kafka record serializer: Confluent-wire-format Avro value (from
 * {@code ConfluentRegistryAvroSerializationSchema}) plus an optional UTF-8 string key from the
 * type's {@link KeyExtractor}. Null key = round-robin partitioning.
 */
public class KeyedAvroRecordSerializer<T extends SpecificRecordBase>
        implements KafkaRecordSerializationSchema<T> {

    private static final long serialVersionUID = 1L;

    private final String topic;
    private final SerializationSchema<T> valueSerializer;
    private final KeyExtractor<T> keyExtractor;

    public KeyedAvroRecordSerializer(
            String topic, SerializationSchema<T> valueSerializer, KeyExtractor<T> keyExtractor) {
        this.topic = topic;
        this.valueSerializer = valueSerializer;
        this.keyExtractor = keyExtractor;
    }

    @Override
    public void open(
            SerializationSchema.InitializationContext context, KafkaSinkContext sinkContext)
            throws Exception {
        valueSerializer.open(context);
    }

    @Override
    public ProducerRecord<byte[], byte[]> serialize(
            T element, KafkaSinkContext context, Long timestamp) {
        String key = keyExtractor.key(element);
        byte[] keyBytes = key == null ? null : key.getBytes(StandardCharsets.UTF_8);
        return new ProducerRecord<>(topic, null, keyBytes, valueSerializer.serialize(element));
    }
}
