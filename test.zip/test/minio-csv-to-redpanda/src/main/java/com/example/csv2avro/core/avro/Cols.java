package com.example.csv2avro.core.avro;

import com.example.csv2avro.core.spi.RejectReason;
import com.example.csv2avro.core.spi.RowRejectedException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;

/**
 * Shared column helpers for mappers: the normalize / change toolbox. Null-safe throughout —
 * a null in means a null out (except the {@code req*} variants, which reject the row).
 *
 * <p>Timestamps: the source timezone must be explicit, never the JVM default. Target Avro
 * logical type is {@code timestamp-millis} (a long).
 */
public final class Cols {

    private Cols() {
    }

    public static String trim(String v) {
        return v == null ? null : v.trim();
    }

    public static String emptyToNull(String v) {
        return v == null || v.isEmpty() ? null : v;
    }

    public static String upper(String v) {
        return v == null ? null : v.toUpperCase(Locale.ROOT);
    }

    public static String lower(String v) {
        return v == null ? null : v.toLowerCase(Locale.ROOT);
    }

    public static Double optDouble(String v, String column) throws RowRejectedException {
        if (v == null) {
            return null;
        }
        try {
            return Double.valueOf(v.trim());
        } catch (NumberFormatException e) {
            throw new RowRejectedException(RejectReason.VALUE_FORMAT,
                    "column '" + column + "': not a double: '" + v + "'");
        }
    }

    public static double reqDouble(String v, String column) throws RowRejectedException {
        Double d = optDouble(v, column);
        if (d == null) {
            throw new RowRejectedException(RejectReason.MISSING_REQUIRED,
                    "column '" + column + "': required double is null");
        }
        return d;
    }

    public static Long optLong(String v, String column) throws RowRejectedException {
        if (v == null) {
            return null;
        }
        try {
            return Long.valueOf(v.trim());
        } catch (NumberFormatException e) {
            throw new RowRejectedException(RejectReason.VALUE_FORMAT,
                    "column '" + column + "': not a long: '" + v + "'");
        }
    }

    public static Integer optInt(String v, String column) throws RowRejectedException {
        if (v == null) {
            return null;
        }
        try {
            return Integer.valueOf(v.trim());
        } catch (NumberFormatException e) {
            throw new RowRejectedException(RejectReason.VALUE_FORMAT,
                    "column '" + column + "': not an int: '" + v + "'");
        }
    }

    public static Boolean optBool(String v, String column) throws RowRejectedException {
        if (v == null) {
            return null;
        }
        return switch (v.trim().toLowerCase(Locale.ROOT)) {
            case "true", "1", "yes", "y" -> Boolean.TRUE;
            case "false", "0", "no", "n" -> Boolean.FALSE;
            default -> throw new RowRejectedException(RejectReason.VALUE_FORMAT,
                    "column '" + column + "': not a boolean: '" + v + "'");
        };
    }

    /** Local date-time in the given source zone → epoch millis (timestamp-millis). */
    public static Long optTimestampMillis(
            String v, String column, DateTimeFormatter format, ZoneId sourceZone)
            throws RowRejectedException {
        if (v == null) {
            return null;
        }
        try {
            return LocalDateTime.parse(v.trim(), format).atZone(sourceZone).toInstant()
                    .toEpochMilli();
        } catch (DateTimeParseException e) {
            throw new RowRejectedException(RejectReason.VALUE_FORMAT,
                    "column '" + column + "': unparseable timestamp: '" + v + "'");
        }
    }

    /** Date-only column → epoch days (Avro {@code date} logical type). */
    public static Integer optEpochDays(String v, String column, DateTimeFormatter format)
            throws RowRejectedException {
        if (v == null) {
            return null;
        }
        try {
            return (int) LocalDate.parse(v.trim(), format).toEpochDay();
        } catch (DateTimeParseException e) {
            throw new RowRejectedException(RejectReason.VALUE_FORMAT,
                    "column '" + column + "': unparseable date: '" + v + "'");
        }
    }
}
