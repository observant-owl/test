package com.example.csv2avro.runtime;

import java.io.Serializable;
import java.util.Objects;

/**
 * The data MinIO, as the source's own S3 client sees it — <b>not</b> Flink's filesystem.
 *
 * <p>Flink's {@code s3.*} plugin keys are global to the JVM, so they can describe exactly one S3;
 * they stay pointed at the <em>state</em> MinIO that holds checkpoints, savepoints and HA. When
 * this record is present, {@code Sources} hands it to {@code OwnFileSource.withFileSystem(...)},
 * which gives the source a client of its own and lets the two MinIOs differ. When it is absent the
 * source falls back to Flink's plugin, which is the older single-MinIO arrangement and still a
 * supported one.
 *
 * @param bucket also used to resolve a schemeless {@code prefix}, so it is required in both modes
 */
public record S3Settings(
        String endpoint,
        String accessKey,
        String secretKey,
        String region,
        String bucket)
        implements Serializable {

    /**
     * Every field is required. This is not a check on the profile — nothing here reads or
     * inspects a {@code .conf}; it is what the record means. An S3 client with a null credential
     * in it is not a thing that can exist, and the absence of the whole block is expressed by a
     * null {@code S3Settings}, never by a null field inside one.
     *
     * <p>Which makes the one dangerous shape loud without validating anything: a profile that
     * sets {@code source.s3.endpoint} but typos {@code source.s3.secret-key} fails at startup
     * naming the key, instead of building a client that silently reads the state MinIO.
     */
    public S3Settings {
        Objects.requireNonNull(endpoint, "source.s3.endpoint");
        Objects.requireNonNull(accessKey, "source.s3.access-key");
        Objects.requireNonNull(secretKey, "source.s3.secret-key");
        Objects.requireNonNull(region, "source.s3.region");
        Objects.requireNonNull(bucket, "source.s3.bucket");
    }

    /**
     * Masked, because this is reachable from a log line. {@code Profile.load} logs the effective
     * configuration at startup and Flink's {@code Configuration.toString()} masks nothing, so an
     * unmasked record here is the easy way to put a MinIO secret in a JobManager log that someone
     * else can read.
     */
    @Override
    public String toString() {
        return "S3Settings[endpoint=" + endpoint + ", region=" + region + ", bucket=" + bucket
                + ", accessKey=***, secretKey=***]";
    }
}
