package com.example.csv2avro.core.csv;

import com.example.csv2avro.core.format.Line;
import com.example.csv2avro.core.spi.RejectReason;
import com.example.csv2avro.core.spi.RowRejectedException;
import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.UncheckedIOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

/**
 * Pure (Flink-free) line-level parsing. One instance per stream, built from the pinned config
 * header.
 *
 * <p>Rests on two assumptions documented in CLAUDE.md: no CSV field contains an embedded
 * newline, and the header never changes. A same-count column <em>reorder</em> upstream is the
 * one shape that fails silently — values bind to the wrong Avro fields.
 */
public final class LineParser implements Serializable {

    private static final long serialVersionUID = 1L;

    /** Unicode escape on purpose — a literal BOM in the source is invisible and
     * unmaintainable. */
    private static final char BOM = '\uFEFF';

    private final String streamId;
    private final String expectedHeaderLine;
    private final List<String> columns;
    private final Map<String, Integer> columnIndex;
    private final Set<String> nullTokens;
    private final CSVFormat csvFormat;

    /**
     * One CSVParser, kept alive across lines and fed one line at a time — see
     * {@link #splitCsv}. Transient because neither is serializable; {@code null} means "not
     * built yet", which is also the state after Java deserialization.
     */
    private transient LineReader feeder;
    private transient Iterator<CSVRecord> records;

    public LineParser(
            String streamId,
            String expectedHeaderLine,
            char delimiter,
            char quote,
            Character escape,
            Set<String> nullTokens) {
        this.streamId = streamId;
        this.nullTokens = Set.copyOf(nullTokens);
        this.expectedHeaderLine = normalize(expectedHeaderLine);
        CSVFormat.Builder b = CSVFormat.Builder.create()
                .setDelimiter(delimiter)
                .setQuote(quote);
        if (escape != null) {
            b.setEscape(escape);
        }
        this.csvFormat = b.get();
        try {
            this.columns = List.copyOf(splitCsv(this.expectedHeaderLine));
        } catch (IOException e) {
            throw new IllegalArgumentException(
                    "expectedHeader for stream '" + streamId + "' is not parseable CSV: "
                            + expectedHeaderLine, e);
        }
        if (new HashSet<>(columns).size() != columns.size()) {
            throw new IllegalArgumentException(
                    "expectedHeader for stream '" + streamId + "' has duplicate column names: "
                            + columns);
        }
        Map<String, Integer> idx = new HashMap<>();
        for (int i = 0; i < columns.size(); i++) {
            idx.put(columns.get(i), i);
        }
        this.columnIndex = Map.copyOf(idx);
    }

    public List<String> columns() {
        return columns;
    }

    /** Classifies one source record. Stateless with respect to files, so it is safe to reuse
     * across them. */
    public Outcome parse(Line line) {
        switch (line.kind) {
            case FILE_OPEN -> {
                return Outcome.of(Outcome.Kind.FILE_OPEN, line);
            }
            case CORRUPT -> {
                return Outcome.of(Outcome.Kind.CORRUPT, line);
            }
            default -> {
                return parseText(line);
            }
        }
    }

    private Outcome parseText(Line line) {
        String text = normalize(line.text);
        if (text.isEmpty()) {
            return Outcome.of(Outcome.Kind.BLANK, line);
        }

        if (text.equals(expectedHeaderLine)) {
            return Outcome.of(Outcome.Kind.HEADER, line);
        }

        List<String> fields;
        try {
            fields = splitCsv(text);
        } catch (IOException | UncheckedIOException | IllegalStateException e) {
            // UncheckedIOException matters: commons-csv routes record access through
            // Uncheck.get, so the commonest malformation of all — an unbalanced quote —
            // arrives wrapped and would otherwise escape this catch and kill the task
            // instead of landing in the DLQ.
            return Outcome.reject(
                    RejectReason.MALFORMED_CSV, "malformed-csv: " + e.getMessage(), line);
        }

        if (fields.equals(columns)) {
            // Same header, different quoting/whitespace than the pinned verbatim line.
            return Outcome.of(Outcome.Kind.HEADER, line);
        }

        if (fields.size() != columns.size()) {
            return Outcome.reject(
                    RejectReason.COLUMN_COUNT,
                    "column-count: expected " + columns.size() + " got " + fields.size(),
                    line);
        }

        return Outcome.row(new MappedRow(line.text, fields), line);
    }

    /**
     * Splits one line, reusing a single {@link CSVParser} rather than building one per row.
     *
     * <p><b>The rebuild on failure is load-bearing, not defensive.</b> A line that fails to
     * parse leaves the lexer mid-token; the next line is then swallowed and the one after it
     * loses its first character — undetectable corruption written straight to Kafka. Pinned by
     * {@code LineParserTest#malformedLineDoesNotCorruptTheFollowingLines}.
     */
    private List<String> splitCsv(String line) throws IOException {
        if (records == null) {
            newCsvParser();
        }
        try {
            feeder.feed(line);
            if (!records.hasNext()) {
                newCsvParser();
                return List.of();
            }
            return records.next().toList();
        } catch (RuntimeException e) {
            newCsvParser();
            throw e;
        }
    }

    private void newCsvParser() throws IOException {
        feeder = new LineReader();
        records = CSVParser.parse(feeder, csvFormat).iterator();
    }

    private static String normalize(String line) {
        String s = line;
        if (!s.isEmpty() && s.charAt(0) == BOM) {
            s = s.substring(1);
        }
        if (s.endsWith("\r")) {
            s = s.substring(0, s.length() - 1);
        }
        return s;
    }

    /**
     * A {@link Reader} holding one line, refilled per call. Reporting EOF once the line is
     * consumed is what makes the lexer emit that line's record and stop. The trailing newline
     * is synthesized rather than concatenated, so feeding costs no allocation.
     */
    private static final class LineReader extends Reader {

        private String buf = "";
        private int pos;
        private boolean newlinePending;

        void feed(String line) {
            this.buf = line;
            this.pos = 0;
            this.newlinePending = true;
        }

        @Override
        public int read(char[] cbuf, int off, int len) {
            if (len == 0) {
                return 0;
            }
            if (pos < buf.length()) {
                int n = Math.min(len, buf.length() - pos);
                buf.getChars(pos, pos + n, cbuf, off);
                pos += n;
                return n;
            }
            if (newlinePending) {
                newlinePending = false;
                cbuf[off] = '\n';
                return 1;
            }
            return -1;
        }

        @Override
        public void close() {
            // nothing to release
        }
    }

    /**
     * Exactly one of: a data row, a header line, a blank line, a rejection, or one of the two
     * file signals. The file signals are never mapped or emitted downstream.
     */
    public static final class Outcome {
        public enum Kind { ROW, HEADER, BLANK, REJECT, CORRUPT, FILE_OPEN }

        public final Kind kind;
        public final CsvRow row;                 // ROW only
        /** Free prose for the DLQ payload. REJECT only. */
        public final String reason;
        /** The bounded Prometheus label for {@link #reason}. REJECT only. */
        public final RejectReason code;
        /** The source record, always present — carries the object this came from. */
        public final Line line;

        private Outcome(Kind kind, CsvRow row, String reason, RejectReason code, Line line) {
            this.kind = kind;
            this.row = row;
            this.reason = reason;
            this.code = code;
            this.line = line;
        }

        /** The raw input line, for DLQ payloads. Null for the two file signals. */
        public String rawLine() {
            return line.text;
        }

        /** The object this came from. Never null — that is the point of {@link Line}. */
        public String objectPath() {
            return line.path;
        }

        static Outcome of(Kind kind, Line line) {
            return new Outcome(kind, null, null, null, line);
        }

        static Outcome row(CsvRow row, Line line) {
            return new Outcome(Kind.ROW, row, null, null, line);
        }

        static Outcome reject(RejectReason code, String reason, Line line) {
            return new Outcome(Kind.REJECT, null, reason, code, line);
        }
    }

    private final class MappedRow implements CsvRow {
        private final String rawLine;
        private final List<String> fields;

        MappedRow(String rawLine, List<String> fields) {
            this.rawLine = rawLine;
            this.fields = fields;
        }

        @Override
        public String get(String column) {
            Integer i = columnIndex.get(column);
            if (i == null) {
                throw new IllegalArgumentException(
                        "column '" + column + "' is not in the expected header of stream '"
                                + streamId + "' " + columns
                                + " — mapper and config disagree");
            }
            String v = fields.get(i);
            return nullTokens.contains(v) ? null : v;
        }

        @Override
        public String require(String column) throws RowRejectedException {
            String v = get(column);
            if (v == null) {
                throw new RowRejectedException(RejectReason.MISSING_REQUIRED,
                        "required column '" + column + "' is null");
            }
            return v;
        }

        @Override
        public String rawLine() {
            return rawLine;
        }
    }
}
