package com.example.csv2avro.core.csv;

import com.example.csv2avro.core.format.FileMarker;
import com.example.csv2avro.core.spi.RejectReason;
import com.example.csv2avro.core.spi.RowRejectedException;
import java.io.IOException;
import java.io.Serializable;
import java.io.UncheckedIOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

/**
 * Pure (Flink-free) line-level parsing logic, so it can be unit-tested and reused by the
 * conformance harness. One instance per stream, built from the pinned config header.
 *
 * <p>Line-oriented reading rests on a documented assumption: <b>no CSV field ever contains an
 * embedded newline</b> (user decision 2026-09-01, "assume no for now"). A field that does have
 * one shows up here as two malformed lines and lands in the DLQ — watch the reject rate when a
 * new type goes live.
 */
public final class LineParser implements Serializable {

    /** Prefix of the corrupt-file marker CorruptTolerantBulkFormat emits in place of an
     * unreadable file's content. Build markers with {@link FileMarker#encode}, not by
     * concatenating onto this — it exists so log lines and tests can recognise one. */
    public static final String CORRUPT_SENTINEL_PREFIX =
            FileMarker.prefixFor(FileMarker.Kind.CORRUPT);

    private static final char BOM = '\uFEFF';

    private final String streamId;
    private final char delimiter;
    private final char quote;
    private final Character escape;
    private final boolean haltOnHeaderDrift;
    private final String expectedHeaderLine;
    private final List<String> columns;
    private final Set<String> columnSet;
    private final Map<String, Integer> columnIndex;
    private final Set<String> nullTokens;

    public LineParser(
            String streamId,
            String expectedHeaderLine,
            char delimiter,
            char quote,
            Character escape,
            Set<String> nullTokens,
            boolean haltOnHeaderDrift) {
        this.streamId = streamId;
        this.delimiter = delimiter;
        this.quote = quote;
        this.escape = escape;
        this.nullTokens = Set.copyOf(nullTokens);
        this.haltOnHeaderDrift = haltOnHeaderDrift;
        this.expectedHeaderLine = normalize(expectedHeaderLine);
        try {
            this.columns = List.copyOf(splitCsv(this.expectedHeaderLine));
        } catch (IOException e) {
            throw new IllegalArgumentException(
                    "expectedHeader for stream '" + streamId + "' is not parseable CSV: "
                            + expectedHeaderLine, e);
        }
        this.columnSet = new HashSet<>(columns);
        if (columnSet.size() != columns.size()) {
            throw new IllegalArgumentException(
                    "expectedHeader for stream '" + streamId + "' has duplicate column names: "
                            + columns);
        }
        Map<String, Integer> idx = new HashMap<>();
        for (int i = 0; i < columns.size(); i++) {
            idx.put(columns.get(i), i);
        }
        this.columnIndex = Map.copyOf(idx);
    }

    public List<String> columns() {
        return columns;
    }

    /**
     * Classifies one raw line.
     *
     * @throws HeaderDriftException if the line is header-shaped but differs from the pinned
     *     header and {@code haltOnHeaderDrift} is set — a schema cutover; the type must halt.
     */
    public Outcome parse(String rawLine) {
        FileMarker marker = FileMarker.decode(rawLine);
        if (marker != null) {
            return Outcome.fileMarker(marker);
        }

        String line = normalize(rawLine);
        if (line.isEmpty()) {
            return Outcome.blank();
        }
        if (line.equals(expectedHeaderLine)) {
            return Outcome.header();
        }

        List<String> fields;
        try {
            fields = splitCsv(line);
        } catch (IOException | UncheckedIOException | IllegalStateException e) {
            // UncheckedIOException matters: commons-csv routes getRecords() through
            // Uncheck.get, so the commonest malformation of all — an unbalanced quote —
            // arrives wrapped and would otherwise escape this catch and kill the task
            // instead of landing in the DLQ.
            return Outcome.reject(
                    RejectReason.MALFORMED_CSV, "malformed-csv: " + e.getMessage(), rawLine);
        }

        if (fields.equals(columns)) {
            // Same header, different quoting/whitespace than the pinned verbatim line.
            return Outcome.header();
        }

        // Cutover heuristic: a line whose cells largely coincide with known column names is a
        // header from a *different* schema version. Threshold max(2, half) keeps a data row
        // that happens to contain one column-name-like value from tripping it.
        int nameHits = 0;
        for (String f : fields) {
            if (columnSet.contains(f)) {
                nameHits++;
            }
        }
        if (nameHits >= Math.max(2, (columns.size() + 1) / 2)) {
            String msg = "header drift detected for stream '" + streamId + "': expected ["
                    + expectedHeaderLine + "] but saw [" + line
                    + "]. Upstream schema cutover? Update .avsc + mapper + expectedHeader, "
                    + "then redeploy.";
            if (haltOnHeaderDrift) {
                throw new HeaderDriftException(msg);
            }
            return Outcome.reject(
                    RejectReason.HEADER_DRIFT_SUSPECT, "header-drift-suspect: " + msg, rawLine);
        }

        if (fields.size() != columns.size()) {
            return Outcome.reject(
                    RejectReason.COLUMN_COUNT,
                    "column-count: expected " + columns.size() + " got " + fields.size(),
                    rawLine);
        }

        return Outcome.row(new MappedRow(rawLine, fields));
    }

    private List<String> splitCsv(String line) throws IOException {
        CSVFormat.Builder b = CSVFormat.Builder.create()
                .setDelimiter(delimiter)
                .setQuote(quote);
        if (escape != null) {
            b.setEscape(escape);
        }
        try (CSVParser parser = CSVParser.parse(line, b.get())) {
            List<CSVRecord> records = parser.getRecords();
            if (records.isEmpty()) {
                return List.of();
            }
            return records.get(0).toList();
        }
    }

    private static String normalize(String line) {
        String s = line;
        if (!s.isEmpty() && s.charAt(0) == BOM) {
            s = s.substring(1);
        }
        if (s.endsWith("\r")) {
            s = s.substring(0, s.length() - 1);
        }
        return s;
    }

    /**
     * Classification result. Exactly one of: a data row, a header line, a blank line, a
     * rejection, or one of the three file-boundary signals injected by
     * {@link com.example.csv2avro.core.format.CorruptTolerantBulkFormat}.
     *
     * <p>{@code FILE_OPEN} / {@code FILE_DONE} / {@code CORRUPT} are metrics-only: the parse
     * operator counts them and drops them. They are never mapped, never emitted, never DLQ'd.
     */
    public static final class Outcome {
        public enum Kind { ROW, HEADER, BLANK, REJECT, CORRUPT, FILE_OPEN, FILE_DONE }

        public final Kind kind;
        public final CsvRow row;                 // ROW only
        /** Free prose for the DLQ payload. REJECT only. */
        public final String reason;
        /** The bounded Prometheus label for {@link #reason}. REJECT only. */
        public final RejectReason code;
        public final String rawLine;             // REJECT only
        /** File path. CORRUPT / FILE_OPEN / FILE_DONE only. */
        public final String objectKey;
        /** Epoch millis, non-positive if the source supplied none. File kinds only. */
        public final long fileModifiedMillis;
        /** On-the-wire bytes, non-positive if unknown. File kinds only. */
        public final long fileSizeBytes;

        private Outcome(Kind kind, CsvRow row, String reason, RejectReason code, String rawLine,
                String objectKey, long fileModifiedMillis, long fileSizeBytes) {
            this.kind = kind;
            this.row = row;
            this.reason = reason;
            this.code = code;
            this.rawLine = rawLine;
            this.objectKey = objectKey;
            this.fileModifiedMillis = fileModifiedMillis;
            this.fileSizeBytes = fileSizeBytes;
        }

        static Outcome row(CsvRow row) {
            return new Outcome(Kind.ROW, row, null, null, null, null, 0, 0);
        }

        static Outcome header() {
            return new Outcome(Kind.HEADER, null, null, null, null, null, 0, 0);
        }

        static Outcome blank() {
            return new Outcome(Kind.BLANK, null, null, null, null, null, 0, 0);
        }

        static Outcome reject(RejectReason code, String reason, String rawLine) {
            return new Outcome(Kind.REJECT, null, reason, code, rawLine, null, 0, 0);
        }

        static Outcome fileMarker(FileMarker m) {
            Kind k = switch (m.kind()) {
                case OPEN -> Kind.FILE_OPEN;
                case DONE -> Kind.FILE_DONE;
                case CORRUPT -> Kind.CORRUPT;
            };
            return new Outcome(
                    k, null, null, null, null, m.path(), m.modifiedMillis(), m.sizeBytes());
        }
    }

    private final class MappedRow implements CsvRow {
        private final String rawLine;
        private final List<String> fields;

        MappedRow(String rawLine, List<String> fields) {
            this.rawLine = rawLine;
            this.fields = fields;
        }

        @Override
        public String get(String column) {
            Integer i = columnIndex.get(column);
            if (i == null) {
                throw new IllegalArgumentException(
                        "column '" + column + "' is not in the expected header of stream '"
                                + streamId + "' " + columns
                                + " — mapper and config disagree");
            }
            String v = fields.get(i);
            return nullTokens.contains(v) ? null : v;
        }

        @Override
        public String require(String column) throws RowRejectedException {
            String v = get(column);
            if (v == null) {
                throw new RowRejectedException(RejectReason.MISSING_REQUIRED,
                        "required column '" + column + "' is null");
            }
            return v;
        }

        @Override
        public String rawLine() {
            return rawLine;
        }
    }
}
