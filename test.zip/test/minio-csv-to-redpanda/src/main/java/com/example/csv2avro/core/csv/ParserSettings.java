package com.example.csv2avro.core.csv;

import com.example.csv2avro.core.config.DialectConfig;
import com.example.csv2avro.core.config.StreamConfig;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * The one place a stream's config is unpacked into {@link LineParser} constructor arguments.
 *
 * <p>Two jobs in one value object: {@link CsvToAvroFunction} ships it to the task instead of
 * the whole {@code JobConfig} (only these few scalars need to travel), and the conformance
 * test builds its parser through {@link #of} too — before this existed the test restated the
 * unpack by hand and had already drifted from production on one of the arguments.
 */
public record ParserSettings(
        String streamId, String expectedHeader, char delimiter, char quote,
        Character escape, Set<String> nullTokens)
        implements Serializable {

    public static ParserSettings of(StreamConfig sc, String streamId) {
        DialectConfig d = sc.dialect;
        return new ParserSettings(
                streamId, sc.expectedHeader, d.delimiterChar(), d.quoteChar(), d.escapeChar(),
                new HashSet<>(d.nullTokens));
    }

    public LineParser newParser() {
        return new LineParser(streamId, expectedHeader, delimiter, quote, escape, nullTokens);
    }
}
