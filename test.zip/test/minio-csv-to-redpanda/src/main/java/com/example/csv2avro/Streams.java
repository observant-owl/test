package com.example.csv2avro;

import com.example.csv2avro.api.CsvStreamDefinition;
import com.example.csv2avro.generated.TypeA;
import com.example.csv2avro.streams.typea.TypeAMapper;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Every CSV type this jar can run, in one compiler-checked list. Which one a deployment runs is
 * decided entirely by the job's second argument, validated against this list — <b>there is no
 * config key for it</b>, deliberately, because a profile naming a different type than the one
 * it was deployed for is drift nothing could catch. See CLAUDE.md for how to add a type; the
 * {@code id} must match the {@code .avdl} name, the fixture directory, and the {@code <type>}
 * half of every {@code profiles/<env>-<id>.conf}.
 *
 * <p>The registry answers "which ids exist" and "which definition is this id" itself, so no
 * caller rebuilds either from {@link #ALL} — three of them used to, and the test's copy was a
 * hardcoded literal that would not have noticed a new type.
 */
public final class Streams {

    public static final List<CsvStreamDefinition<?>> ALL = List.of(
            // TODO(user): TypeA is still the template — replace its .avdl, mapper and config
            // files with the real type, then copy this line per further type.
            //
            // The 3-argument form means round-robin, and that is a decision, not an omission.
            // Downstream is a ClickHouse Kafka engine table feeding a MV that inserts into a
            // Distributed table, and the Distributed table re-routes every row by its OWN
            // sharding_key — so the partition a row arrived in is discarded. Reproducing
            // ClickHouse's hash in a partitioner here would be work redone downstream.
            //
            // Not keying also keeps partition count a variable that can still be RAISED; keying
            // makes it a one-way door, because murmur2(key) % partitions moves every existing
            // key. Size partitions by consumer count — (nodes running the Kafka engine table) x
            // kafka_num_consumers — not by data volume.
            //
            // Revisit only if the MV is changed to write the LOCAL MergeTree instead of the
            // Distributed table: Kafka partitioning then becomes the sharding mechanism and this
            // answer flips. See CLAUDE.md.
            //
            // For a key-partitioned topic, add a fourth argument:
            //   new CsvStreamDefinition<>("type-b", TypeB.class, new TypeBMapper(),
            //           record -> record.getCustomerId().toString())
            new CsvStreamDefinition<>("type-a", TypeA.class, new TypeAMapper()));

    private static final Map<String, CsvStreamDefinition<?>> BY_ID = index();

    private Streams() {
    }

    /** The registered ids. */
    public static Set<String> ids() {
        return BY_ID.keySet();
    }

    /** @throws IllegalArgumentException if no definition has this id — callers get that check
     *     from {@code Profile} first, so reaching it here means the two disagree. */
    public static CsvStreamDefinition<?> byId(String id) {
        CsvStreamDefinition<?> def = BY_ID.get(id);
        if (def == null) {
            throw new IllegalArgumentException("no stream definition '" + id + "'; registered: "
                    + ids());
        }
        return def;
    }

    /** Duplicate ids are a registry mistake, and they belong to the registry to catch: two
     * entries sharing one id would otherwise silently shadow each other. */
    private static Map<String, CsvStreamDefinition<?>> index() {
        Map<String, CsvStreamDefinition<?>> byId = new LinkedHashMap<>();
        for (CsvStreamDefinition<?> def : ALL) {
            if (byId.put(def.id(), def) != null) {
                throw new IllegalStateException(
                        "Streams.ALL has two definitions with id '" + def.id() + "'");
            }
        }
        return Map.copyOf(byId);
    }
}
