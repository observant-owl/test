package com.example.csv2avro;

import com.example.csv2avro.api.CsvStreamDefinition;
import com.example.csv2avro.generated.TypeA;
import com.example.csv2avro.streams.typea.TypeAMapper;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Every CSV type this jar can run, in one compiler-checked list. Which one a deployment runs is
 * decided entirely by {@code csv2avro.stream} in its configuration file. See CLAUDE.md for how
 * to add a type; the {@code id} must match the {@code .avdl} name, the fixture directory, and
 * the {@code csv2avro.stream} of every {@code profiles/*-<id>.conf}.
 *
 * <p>The registry answers "which ids exist" and "which definition is this id" itself, so no
 * caller rebuilds either from {@link #ALL} — three of them used to, and the test's copy was a
 * hardcoded literal that would not have noticed a new type.
 */
public final class Streams {

    public static final List<CsvStreamDefinition<?>> ALL = List.of(
            // TODO(user): TypeA is still the template — replace its .avdl, mapper and config
            // files with the real type, then copy this line per further type.
            //
            // For a key-partitioned topic add a fourth argument, e.g.
            //   new CsvStreamDefinition<>("type-b", TypeB.class, new TypeBMapper(),
            //           record -> record.getCustomerId().toString())
            // The 3-argument form means round-robin. ClickHouse dedup does not need a key:
            // its ORDER BY comes from row content either way.
            new CsvStreamDefinition<>("type-a", TypeA.class, new TypeAMapper()));

    private static final Map<String, CsvStreamDefinition<?>> BY_ID = index();

    private Streams() {
    }

    /** The registered ids. */
    public static Set<String> ids() {
        return BY_ID.keySet();
    }

    /** @throws IllegalArgumentException if no definition has this id — callers get that check
     *     from {@code CsvConfig} first, so reaching it here means the two disagree. */
    public static CsvStreamDefinition<?> byId(String id) {
        CsvStreamDefinition<?> def = BY_ID.get(id);
        if (def == null) {
            throw new IllegalArgumentException("no stream definition '" + id + "'; registered: "
                    + ids());
        }
        return def;
    }

    /** Duplicate ids are a registry mistake, and they belong to the registry to catch: two
     * entries sharing one id would otherwise silently shadow each other. */
    private static Map<String, CsvStreamDefinition<?>> index() {
        Map<String, CsvStreamDefinition<?>> byId = new LinkedHashMap<>();
        for (CsvStreamDefinition<?> def : ALL) {
            if (byId.put(def.id(), def) != null) {
                throw new IllegalStateException(
                        "Streams.ALL has two definitions with id '" + def.id() + "'");
            }
        }
        return Map.copyOf(byId);
    }
}
