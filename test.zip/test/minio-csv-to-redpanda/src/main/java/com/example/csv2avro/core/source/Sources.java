package com.example.csv2avro.core.source;

import com.example.csv2avro.core.config.JobConfig;
import com.example.csv2avro.core.config.StreamConfig;
import com.example.csv2avro.core.format.CorruptTolerantBulkFormat;
import com.example.csv2avro.core.format.Line;
import org.apache.flink.api.connector.source.Source;
import org.apache.flink.connector.file.src.reader.TextLineInputFormat;

/**
 * Builds the per-stream source: own prefix, own enumerator, own parallelism.
 *
 * <p><b>Not wired yet — nothing can run until {@link #forStream} is completed.</b> See CLAUDE.md
 * for the resolved {@code OwnFileSource} contract.
 */
public final class Sources {

    private Sources() {
    }

    /** Stock text lines + transparent decompression + corrupt-file tolerance, producing
     * {@link Line}s that each carry the identity of the object they came from. */
    public static CorruptTolerantBulkFormat lineFormat(StreamConfig sc) {
        return new CorruptTolerantBulkFormat(new TextLineInputFormat(sc.dialect.charset));
    }

    public static Source<Line, ?, ?> forStream(JobConfig cfg, StreamConfig sc) {
        // TODO(user): add the OwnFileSource dependency to pom.xml and wire it here.
        // Expected shape (adjust to its actual builder API):
        //
        //   return OwnFileSource
        //           .forBulkFileFormat(lineFormat(sc), new Path(sc.prefix))
        //           .monitorInterval(Duration.ofSeconds(cfg.monitorIntervalSeconds(sc)))
        //           .build();
        //
        // Its splits must carry a real fileModificationTime() and fileSize() and be whole files,
        // or the per-file metrics and DLQ object keys are wrong. Honour
        // cfg.monitorIntervalSeconds(sc), never cfg.source.monitorIntervalSeconds.
        throw new IllegalStateException(
                "the source is not wired yet: add the OwnFileSource dependency to pom.xml and "
                        + "complete Sources.forStream(). Nothing can run until this is done.");
    }
}
