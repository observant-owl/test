package com.example.csv2avro.core.source;

import com.example.csv2avro.core.config.JobConfig;
import com.example.csv2avro.core.config.StreamConfig;
import com.example.csv2avro.core.format.CorruptTolerantBulkFormat;
import java.time.Duration;
import org.apache.flink.api.connector.source.Source;
import org.apache.flink.connector.file.src.FileSource;
import org.apache.flink.connector.file.src.reader.TextLineInputFormat;
import org.apache.flink.core.fs.Path;

/**
 * Builds the per-stream source. Each stream gets its own independent source instance
 * (own prefix, own enumerator, own parallelism).
 *
 * <ul>
 *   <li><b>STOCK + CONTINUOUS</b> — Flink's {@code FileSource} with
 *       {@code monitorContinuously}: dev profile, runs anywhere. Caveat (why OwnFileSource
 *       exists): the built-in enumerator remembers all processed paths, state that grows
 *       unboundedly on a long-running job.</li>
 *   <li><b>STOCK + BOUNDED</b> — static file set: the missing-files profile. Point
 *       {@code prefix} at the repair prefix (or list objects in {@code paths}), run, job
 *       finishes.</li>
 *   <li><b>OWN</b> — the user's {@code OwnFileSource} (mod-time monitoring, no growing path
 *       state): prod profile. Wiring stub below until its dependency is added.</li>
 * </ul>
 *
 * <p>MinIO endpoint / credentials / path-style access are supplied by the Flink S3 filesystem
 * plugin ({@code flink-s3-fs-hadoop} in {@code plugins/}, configured via flink-conf), never
 * here.
 */
public final class Sources {

    private Sources() {
    }

    public static Source<String, ?, ?> forStream(JobConfig cfg, StreamConfig sc) {
        return switch (cfg.source.kind) {
            case STOCK -> stock(cfg, sc);
            case OWN -> own(cfg, sc);
        };
    }

    /** The decorated line format both source kinds consume: stock text lines + transparent
     * decompression + corrupt-file tolerance + in-band file-boundary markers (the only way the
     * flat record stream can carry per-file metrics; see {@code FileMarker}). */
    public static CorruptTolerantBulkFormat lineFormat(JobConfig cfg, StreamConfig sc) {
        return new CorruptTolerantBulkFormat(
                new TextLineInputFormat(sc.dialect.charset), cfg.defaults.emitFileMarkers);
    }

    private static Source<String, ?, ?> stock(JobConfig cfg, StreamConfig sc) {
        FileSource.FileSourceBuilder<String> builder =
                FileSource.forBulkFileFormat(lineFormat(cfg, sc), inputPaths(sc));
        if (cfg.source.mode == JobConfig.SourceSection.Mode.CONTINUOUS) {
            builder.monitorContinuously(Duration.ofSeconds(cfg.source.monitorIntervalSeconds));
        }
        return builder.build();
    }

    private static Source<String, ?, ?> own(JobConfig cfg, StreamConfig sc) {
        // TODO(user): wire your OwnFileSource here once its artifact is a dependency.
        // Expected shape (adjust to its actual builder API):
        //
        //   return OwnFileSource
        //           .forBulkFileFormat(lineFormat(cfg, sc), inputPaths(sc))  // decompression
        //           .build();                                        // + corrupt tolerance
        //
        // Notes from the source contract (OPEN-QUESTIONS §1):
        //  - continuous only; it has no bounded mode (missing-files uses STOCK + BOUNDED)
        //  - strict mtime > cursor; missed/backdated objects are repaired via missing-files
        //  - passing the CorruptTolerantBulkFormat preserves the skip+count+log behaviour and
        //    the file-boundary markers behind the per-file metrics; for those to be right its
        //    splits must carry a real fileModificationTime() and fileSize()
        throw new IllegalStateException(
                "source.kind=OWN is not wired yet: add the OwnFileSource dependency to pom.xml "
                        + "and complete Sources.own(). Until then use source.kind=STOCK.");
    }

    private static Path[] inputPaths(StreamConfig sc) {
        if (sc.paths != null && !sc.paths.isEmpty()) {
            return sc.paths.stream().map(Path::new).toArray(Path[]::new);
        }
        return new Path[] {new Path(sc.prefix)};
    }
}
