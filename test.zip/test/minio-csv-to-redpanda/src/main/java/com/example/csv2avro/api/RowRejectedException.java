package com.example.csv2avro.api;

/**
 * Thrown by a {@link RowMapper} (or {@code CsvRow.require}) to route a row to the DLQ.
 *
 * <p>Carries two things that serve different audiences: the message is free prose for the DLQ
 * payload (name the column, quote the value), and {@link #code()} is the bounded
 * {@link RejectReason} that becomes a Prometheus label. Use
 * {@link RejectReason#MAPPER_OTHER} when no more specific code fits.
 *
 * <p><b>No stack trace on the no-cause path.</b> This is control flow for bad input, not a bug
 * report: the message and the code are the whole payload, and nothing ever reads the trace.
 * Filling one in costs a full stack walk per rejected row — free on a healthy stream, but the
 * dominant cost during exactly the reject storm (a bad file, an unannounced header change) when
 * the job is already struggling. The {@code cause} overload keeps its trace, because there the
 * trace is the point.
 */
public class RowRejectedException extends Exception {

    private static final long serialVersionUID = 1L;

    private final RejectReason code;

    public RowRejectedException(RejectReason code, String reason) {
        super(reason, null, false, false);
        this.code = code;
    }

    public RowRejectedException(RejectReason code, String reason, Throwable cause) {
        super(reason, cause);
        this.code = code;
    }

    /** Never null. */
    public RejectReason code() {
        return code;
    }
}
