package com.example.csv2avro.core.spi;

/**
 * The bounded set of reasons a row can be rejected to the DLQ — deliberately an enum, because
 * these labels become a Prometheus dimension and free text there is a cardinality explosion.
 *
 * <p>The prose reason (with column names, offending values, expected/actual counts) still
 * travels to the DLQ payload; this is only the coarse bucket you graph and alert on. Adding a
 * value is cheap; adding one per bad column is not.
 *
 * <p>Lives in {@code spi} rather than {@code csv} because {@link RowRejectedException} carries
 * it, and mapper authors are the ones who choose a code.
 */
public enum RejectReason {

    /** The line is not parseable CSV at all (unbalanced quotes, bad escape). */
    MALFORMED_CSV("malformed-csv"),

    /** Parseable, but a different number of fields than the pinned header. */
    COLUMN_COUNT("column-count"),

    /** Header-shaped but not the pinned header, with halting disabled. */
    HEADER_DRIFT_SUSPECT("header-drift-suspect"),

    /** A column the mapper requires was null or matched a null token. */
    MISSING_REQUIRED("missing-required"),

    /** A value did not convert: not a number, not a boolean, unparseable timestamp. */
    VALUE_FORMAT("value-format"),

    /** Anything a mapper rejects without picking a more specific code. */
    MAPPER_OTHER("mapper-other");

    private final String label;

    RejectReason(String label) {
        this.label = label;
    }

    /** The stable, lowercase Prometheus label value. Never change one of these casually — it
     * silently breaks every dashboard and alert that filters on it. */
    public String label() {
        return label;
    }
}
