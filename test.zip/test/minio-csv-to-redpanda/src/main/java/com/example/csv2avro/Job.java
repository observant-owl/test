package com.example.csv2avro;

import com.example.csv2avro.api.CsvStreamDefinition;
import com.example.csv2avro.runtime.CsvToAvroFunction;
import com.example.csv2avro.runtime.DlqRecord;
import com.example.csv2avro.runtime.Line;
import com.example.csv2avro.runtime.Profile;
import com.example.csv2avro.runtime.Sinks;
import com.example.csv2avro.runtime.Sources;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Assembles the subgraph for the one CSV type this deployment runs: source → parse/map → Kafka,
 * with rejects leaving the same operator's side output to the shared DLQ topic.
 *
 * <p>Every operator uid derives from the stream id, never from graph position — adding a type
 * must not reshuffle any other type's state.
 *
 * <p>Takes <b>exactly two arguments</b>, {@code <env> <type>}, which name the one configuration
 * file in the jar that says everything else: {@code dev type-a} is
 * {@code profiles/dev-type-a.conf}. They are separate arguments because the kustomize layers are
 * separate — the env overlay sets the first and the type overlay appends the second, so neither
 * can drift from the other the way one combined string could.
 *
 * <p>Two things are deliberately <b>not</b> set here. The <b>job name</b>: {@code execute()} takes
 * no argument, so Flink falls back to {@code pipeline.name} from {@code spec.flinkConfiguration},
 * and nothing in Java reads or derives it. And <b>parallelism</b>: the operator turns
 * {@code spec.job.parallelism} into {@code parallelism.default}, which source, parse/map and sink
 * all inherit — equal by construction, so Flink still chains them.
 */
public final class Job {

    private static final Logger LOG = LoggerFactory.getLogger(Job.class);

    public static void main(String[] argv) throws Exception {
        if (argv.length != 2) {
            // Loud on both a missing argument and a leftover extra one: silently ignoring either
            // is how a deployment ends up running a configuration nobody chose.
            throw new IllegalArgumentException("expected exactly two arguments, <env> <type>, "
                    + "naming profiles/<env>-<type>.conf in the jar — e.g. `dev type-a`. Got "
                    + (argv.length == 0 ? "none" : argv.length + ": " + String.join(" ", argv)));
        }
        String env0 = argv[0];
        String type = argv[1];
        Configuration conf = Profile.load(env0, type, Streams.ids());

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        CsvStreamDefinition<?> def = Streams.byId(type);
        assemble(env, conf, def);

        LOG.info("starting stream '{}'", def.id());
        // No argument: execute(String) would OVERRIDE pipeline.name, and the job name is set in
        // the FlinkDeployment (see k8s/overlays/<env>/<type>). Passing null here is what lets
        // StreamGraphGenerator.deriveJobName fall through to it.
        env.execute();
    }

    /** Package-private rather than private so {@code JobGraphTest} can build the whole graph:
     * that is the only check that the source's produced type, the operator and both sinks fit
     * together, and javac only ever sees the declarations. */
    static <T extends SpecificRecordBase> void assemble(
            StreamExecutionEnvironment env, Configuration conf, CsvStreamDefinition<T> def) {
        String id = def.id();
        OutputTag<DlqRecord> dlqTag =
                new OutputTag<>(id + "-dlq", TypeInformation.of(DlqRecord.class));

        DataStream<Line> lines = env
                .fromSource(Sources.forStream(conf), WatermarkStrategy.noWatermarks(),
                        id + "-source")
                .uid(id + "-source");

        SingleOutputStreamOperator<T> records = lines
                .process(new CsvToAvroFunction<>(conf, def, dlqTag),
                        TypeInformation.of(def.avroClass()))
                .uid(id + "-parse-map")
                .name(id + "-parse-map");

        records.sinkTo(Sinks.forStream(conf, def))
                .uid(id + "-sink")
                .name(id + "-kafka");

        // Explicit parallelism 1 — the one place it is still set by hand: the DLQ topic has 1–3
        // partitions and (in a healthy job) near-zero traffic. More subtasks would only add idle
        // producers and their transaction/connection overhead.
        records.getSideOutput(dlqTag)
                .sinkTo(Sinks.forDlq(conf))
                .uid(id + "-dlq-sink")
                .name(id + "-dlq-kafka")
                .setParallelism(1);
    }

    private Job() {
    }
}
