package com.example.csv2avro;

import com.example.csv2avro.core.config.JobConfig;
import com.example.csv2avro.core.config.StreamConfig;
import com.example.csv2avro.core.csv.CsvToAvroFunction;
import com.example.csv2avro.core.dlq.DlqRecord;
import com.example.csv2avro.core.kafka.Sinks;
import com.example.csv2avro.core.source.Sources;
import com.example.csv2avro.core.spi.CsvStreamDefinition;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ServiceLoader;
import java.util.Set;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.PrintSink;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Assembles one disconnected subgraph per enabled CSV type (ServiceLoader-discovered), plus a
 * shared DLQ sink. Regions are independent on purpose: with pipelined-region failover a
 * halted/poisoned type does not stall the others, and disabling a type just removes its
 * region (restore then needs {@code --allowNonRestoredState}).
 *
 * <p>Every operator uid derives from the stream id, never from graph position — enabling one
 * type must not reshuffle any other type's state.
 *
 * <p>Checkpointing interval, restart strategy (use exponential-delay: a header-drift halt
 * must not exhaust a job-wide restart budget), and S3/MinIO access all come from the Flink
 * configuration delivered by the Kubernetes operator, not from code.
 */
public final class Job {

    private static final Logger LOG = LoggerFactory.getLogger(Job.class);

    public static void main(String[] args) throws Exception {
        JobConfig cfg = JobConfig.load(configPath(args));
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        List<CsvStreamDefinition<?>> definitions = discoverDefinitions();
        cfg.validateAgainst(ids(definitions));

        List<DataStream<DlqRecord>> dlqs = new ArrayList<>();
        int built = 0;
        for (CsvStreamDefinition<?> def : definitions) {
            StreamConfig sc = cfg.requireStream(def.id());
            if (!sc.enabled) {
                LOG.info("stream '{}' disabled by config", def.id());
                continue;
            }
            dlqs.add(assemble(env, cfg, sc, def));
            built++;
        }
        if (built == 0) {
            throw new IllegalStateException("no streams enabled — refusing to run a no-op job");
        }

        DataStream<DlqRecord> dlq = dlqs.stream().reduce(DataStream::union).orElseThrow();
        if (cfg.job.dryRun) {
            dlq.sinkTo(new PrintSink<>("dlq")).uid("dlq-sink").name("dlq-print");
        } else {
            dlq.sinkTo(Sinks.forDlq(cfg)).uid("dlq-sink").name("dlq-kafka");
        }

        LOG.info("starting '{}' with {} enabled stream(s), dryRun={}",
                cfg.job.name, built, cfg.job.dryRun);
        env.execute(cfg.job.name);
    }

    private static <T extends SpecificRecordBase> DataStream<DlqRecord> assemble(
            StreamExecutionEnvironment env, JobConfig cfg, StreamConfig sc,
            CsvStreamDefinition<T> def) {
        String id = def.id();
        OutputTag<DlqRecord> dlqTag =
                new OutputTag<>(id + "-dlq", TypeInformation.of(DlqRecord.class));

        DataStream<String> lines = env
                .fromSource(Sources.forStream(cfg, sc), WatermarkStrategy.noWatermarks(),
                        id + "-source")
                .uid(id + "-source")
                .setParallelism(cfg.sourceParallelism(sc));

        SingleOutputStreamOperator<T> records = lines
                .process(new CsvToAvroFunction<>(cfg, sc, def, dlqTag),
                        TypeInformation.of(def.avroClass()))
                .uid(id + "-parse-map")
                .name(id + "-parse-map")
                .setParallelism(cfg.sourceParallelism(sc));

        if (cfg.job.dryRun) {
            records.sinkTo(new PrintSink<>(id))
                    .uid(id + "-sink")
                    .name(id + "-print")
                    .setParallelism(cfg.sinkParallelism(sc));
        } else {
            records.sinkTo(Sinks.forStream(cfg, sc, def))
                    .uid(id + "-sink")
                    .name(id + "-kafka")
                    .setParallelism(cfg.sinkParallelism(sc));
        }
        return records.getSideOutput(dlqTag);
    }

    /** The one place raw ServiceLoader types are allowed. */
    private static List<CsvStreamDefinition<?>> discoverDefinitions() {
        List<CsvStreamDefinition<?>> defs = new ArrayList<>();
        for (CsvStreamDefinition<?> def : ServiceLoader.load(CsvStreamDefinition.class)) {
            defs.add(def);
        }
        return defs;
    }

    private static Set<String> ids(List<CsvStreamDefinition<?>> defs) {
        Set<String> ids = new LinkedHashSet<>();
        for (CsvStreamDefinition<?> def : defs) {
            if (!ids.add(def.id())) {
                throw new IllegalStateException("duplicate stream id '" + def.id() + "'");
            }
        }
        return ids;
    }

    private static Path configPath(String[] args) {
        for (int i = 0; i < args.length - 1; i++) {
            if ("--config".equals(args[i])) {
                return Path.of(args[i + 1]);
            }
        }
        throw new IllegalArgumentException(
                "usage: --config <path to dev.yaml|prod.yaml|missing-files.yaml>");
    }

    private Job() {
    }
}
