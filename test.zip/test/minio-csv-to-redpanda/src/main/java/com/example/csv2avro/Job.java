package com.example.csv2avro;

import com.example.csv2avro.core.config.JobConfig;
import com.example.csv2avro.core.config.StreamConfig;
import com.example.csv2avro.core.csv.CsvToAvroFunction;
import com.example.csv2avro.core.dlq.DlqRecord;
import com.example.csv2avro.core.format.Line;
import com.example.csv2avro.core.kafka.Sinks;
import com.example.csv2avro.core.source.Sources;
import com.example.csv2avro.core.spi.CsvStreamDefinition;
import com.example.csv2avro.streams.Streams;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Assembles one self-contained subgraph per configured CSV type: source → parse/map → Kafka,
 * with rejects leaving the same operator's side output to the shared DLQ topic.
 *
 * <p>Nothing is shared between subgraphs, so each is an independent failover region and a
 * poisoned type does not restart its neighbours. Every operator uid derives from the stream id,
 * never from graph position — adding a type must not reshuffle any other type's state.
 *
 * <p>There is deliberately no {@code --stream} selector: which type a deployment runs has one
 * source of truth, the {@code streams/<type>.yaml} in its {@code --config} list.
 */
public final class Job {

    private static final Logger LOG = LoggerFactory.getLogger(Job.class);

    public static void main(String[] argv) throws Exception {
        Args args = Args.parse(argv);
        JobConfig cfg = JobConfig.load(args.configPaths());
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        cfg.validateAgainst(Streams.ALL.stream()
                .map(CsvStreamDefinition::id).collect(Collectors.toSet()));

        List<String> running = new ArrayList<>();
        for (CsvStreamDefinition<?> def : Streams.ALL) {
            StreamConfig sc = cfg.streams.get(def.id());
            if (sc == null) {
                continue; // a type this deployment does not run
            }
            assemble(env, cfg, sc, def);
            running.add(def.id());
        }

        String jobName = jobName(cfg, running);
        LOG.info("starting '{}' from config {} with stream(s) {}",
                jobName, args.configPaths(), running);
        env.execute(jobName);
    }

    /** {@code job.name} plus the stream id when exactly one stream runs — the normal shape.
     * Multi-stream runs keep the plain name; there is no single id to add. */
    private static String jobName(JobConfig cfg, List<String> running) {
        return running.size() == 1 ? cfg.job.name + "-" + running.get(0) : cfg.job.name;
    }

    private static <T extends SpecificRecordBase> void assemble(
            StreamExecutionEnvironment env, JobConfig cfg, StreamConfig sc,
            CsvStreamDefinition<T> def) {
        String id = def.id();
        int parallelism = cfg.parallelism(sc);
        OutputTag<DlqRecord> dlqTag =
                new OutputTag<>(id + "-dlq", TypeInformation.of(DlqRecord.class));

        DataStream<Line> lines = env
                .fromSource(Sources.forStream(cfg, sc), WatermarkStrategy.noWatermarks(),
                        id + "-source")
                .uid(id + "-source")
                .setParallelism(parallelism);

        SingleOutputStreamOperator<T> records = lines
                .process(new CsvToAvroFunction<>(sc, def, dlqTag),
                        TypeInformation.of(def.avroClass()))
                .uid(id + "-parse-map")
                .name(id + "-parse-map")
                .setParallelism(parallelism);

        records.sinkTo(Sinks.forStream(cfg, sc, def))
                .uid(id + "-sink")
                .name(id + "-kafka")
                .setParallelism(parallelism);

        // Explicit parallelism 1: the DLQ topic has 1–3 partitions and (in a healthy job)
        // near-zero traffic. More subtasks would only add idle producers and their
        // transaction/connection overhead.
        records.getSideOutput(dlqTag)
                .sinkTo(Sinks.forDlq(cfg))
                .uid(id + "-dlq-sink")
                .name(id + "-dlq-kafka")
                .setParallelism(1);
    }

    /**
     * The job's entire command line: an ordered list of config layers. Strict — the args live
     * in a manifest where nobody sees a warning, so a typo'd flag must be a startup failure
     * rather than a silently partial config stack.
     */
    record Args(List<Path> configPaths) {

        private static final String USAGE =
                "usage: --config <base.yaml> [--config <overlay.yaml> …]  "
                        + "(layers are deep-merged in the order given)";

        static Args parse(String[] argv) {
            List<Path> paths = new ArrayList<>();
            for (int i = 0; i < argv.length; i++) {
                if (!"--config".equals(argv[i])) {
                    throw new IllegalArgumentException(
                            "unrecognized argument '" + argv[i] + "'\n" + USAGE);
                }
                if (i + 1 >= argv.length) {
                    throw new IllegalArgumentException("--config needs a value\n" + USAGE);
                }
                paths.add(Path.of(argv[++i]));
            }
            if (paths.isEmpty()) {
                throw new IllegalArgumentException("no --config given\n" + USAGE);
            }
            return new Args(List.copyOf(paths));
        }
    }

    private Job() {
    }
}
