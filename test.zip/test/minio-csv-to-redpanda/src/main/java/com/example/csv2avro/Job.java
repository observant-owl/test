package com.example.csv2avro;

import com.example.csv2avro.api.CsvStreamDefinition;
import com.example.csv2avro.runtime.CsvConfig;
import com.example.csv2avro.runtime.CsvToAvroFunction;
import com.example.csv2avro.runtime.DlqRecord;
import com.example.csv2avro.runtime.Line;
import com.example.csv2avro.runtime.Sinks;
import com.example.csv2avro.runtime.Sources;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.configuration.GlobalConfiguration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Assembles the subgraph for the one CSV type this deployment runs: source → parse/map → Kafka,
 * with rejects leaving the same operator's side output to the shared DLQ topic.
 *
 * <p>Every operator uid derives from the stream id, never from graph position — adding a type
 * must not reshuffle any other type's state.
 *
 * <p>Takes <b>no arguments</b>. A single key in the FlinkDeployment's
 * {@code spec.flinkConfiguration} — {@code csv2avro.config} — names the one configuration file
 * in the jar that says everything else, including which CSV type runs. Parallelism is not set
 * here either: the operator turns {@code spec.job.parallelism} into {@code parallelism.default},
 * which source, parse/map and sink all inherit — equal by construction, so Flink still chains
 * them.
 */
public final class Job {

    private static final Logger LOG = LoggerFactory.getLogger(Job.class);

    public static void main(String[] argv) throws Exception {
        if (argv.length > 0) {
            // Not merely unused: an argument here is someone's leftover --config, and ignoring
            // it silently is how a deployment ends up running a configuration nobody chose.
            throw new IllegalArgumentException("this job takes no arguments, got "
                    + String.join(" ", argv) + " — configure it through spec.flinkConfiguration "
                    + "(" + CsvConfig.CONFIG.key() + ")");
        }
        // GlobalConfiguration reads FLINK_CONF_DIR, which is where the operator mounts its
        // rendering of spec.flinkConfiguration. Only csv2avro.config is taken from it; the
        // configuration itself is the classpath resource that key names.
        Configuration flinkConf = GlobalConfiguration.loadConfiguration();
        Configuration conf = CsvConfig.load(flinkConf, Streams.ids());
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        CsvStreamDefinition<?> def = Streams.byId(conf.get(CsvConfig.STREAM));
        String jobName = CsvConfig.jobName(flinkConf, def.id());
        assemble(env, conf, def);

        LOG.info("starting '{}' for stream '{}'", jobName, def.id());
        env.execute(jobName);
    }

    /** Package-private rather than private so {@code JobGraphTest} can build the whole graph:
     * that is the only check that the source's produced type, the operator and both sinks fit
     * together, and javac only ever sees the declarations. */
    static <T extends SpecificRecordBase> void assemble(
            StreamExecutionEnvironment env, Configuration conf, CsvStreamDefinition<T> def) {
        String id = def.id();
        OutputTag<DlqRecord> dlqTag =
                new OutputTag<>(id + "-dlq", TypeInformation.of(DlqRecord.class));

        DataStream<Line> lines = env
                .fromSource(Sources.forStream(conf), WatermarkStrategy.noWatermarks(),
                        id + "-source")
                .uid(id + "-source");

        SingleOutputStreamOperator<T> records = lines
                .process(new CsvToAvroFunction<>(conf, def, dlqTag),
                        TypeInformation.of(def.avroClass()))
                .uid(id + "-parse-map")
                .name(id + "-parse-map");

        records.sinkTo(Sinks.forStream(conf, def))
                .uid(id + "-sink")
                .name(id + "-kafka");

        // Explicit parallelism 1 — the one place it is still set by hand: the DLQ topic has 1–3
        // partitions and (in a healthy job) near-zero traffic. More subtasks would only add idle
        // producers and their transaction/connection overhead.
        records.getSideOutput(dlqTag)
                .sinkTo(Sinks.forDlq(conf))
                .uid(id + "-dlq-sink")
                .name(id + "-dlq-kafka")
                .setParallelism(1);
    }

    private Job() {
    }
}
