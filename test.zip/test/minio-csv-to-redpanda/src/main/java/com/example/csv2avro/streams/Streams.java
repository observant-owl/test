package com.example.csv2avro.streams;

import com.example.csv2avro.core.spi.CsvStreamDefinition;
import com.example.csv2avro.generated.TypeA;
import com.example.csv2avro.streams.typea.TypeAMapper;
import java.util.List;

/**
 * Every CSV type this jar can run, in one compiler-checked list. Which of them a deployment
 * runs is decided entirely by its {@code --config} list. See CLAUDE.md for how to add a type;
 * the {@code id} must match the config key, the {@code .avsc} name and the fixture directory.
 */
public final class Streams {

    public static final List<CsvStreamDefinition<?>> ALL = List.of(
            // TODO(user): TypeA is still the template — replace its .avsc, mapper and config
            // block with the real type, then copy this line per further type.
            //
            // For a key-partitioned topic add a fourth argument, e.g.
            //   new CsvStreamDefinition<>("type-b", TypeB.class, new TypeBMapper(),
            //           record -> record.getCustomerId().toString())
            // The 3-argument form means round-robin. ClickHouse dedup does not need a key:
            // its ORDER BY comes from row content either way.
            new CsvStreamDefinition<>("type-a", TypeA.class, new TypeAMapper()));

    private Streams() {
    }
}
