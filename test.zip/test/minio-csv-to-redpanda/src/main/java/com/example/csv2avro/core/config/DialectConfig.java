package com.example.csv2avro.core.config;

import java.io.Serializable;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * CSV dialect of one stream, from YAML. Single-character fields are strings in YAML for
 * readability and validated here.
 *
 * <p>No {@code skipLines}: preamble lines cannot be skipped per file because file boundaries
 * do not survive the source. Preamble junk (if a type has any) will land in the DLQ as
 * malformed rows — if that turns out to be real, that type needs a file-scoped reader.
 */
public class DialectConfig implements Serializable {

    public String delimiter = ",";
    public String quote = "\"";
    /** Null = RFC 4180 doubled quotes. */
    public String escape;
    /** Charset of the files; don't assume UTF-8, latin-1 exports are common. */
    public String charset = "UTF-8";
    /** Values meaning null, matched exactly against the raw cell. */
    public List<String> nullTokens = new ArrayList<>(List.of(""));

    public char delimiterChar() {
        return singleChar(delimiter, "delimiter");
    }

    public char quoteChar() {
        return singleChar(quote, "quote");
    }

    public Character escapeChar() {
        return escape == null ? null : singleChar(escape, "escape");
    }

    List<String> validate(String streamId) {
        List<String> errors = new ArrayList<>();
        for (String[] f : new String[][] {{delimiter, "delimiter"}, {quote, "quote"}}) {
            if (f[0] == null || f[0].length() != 1) {
                errors.add("stream '" + streamId + "': dialect." + f[1]
                        + " must be exactly one character, got '" + f[0] + "'");
            }
        }
        if (escape != null && escape.length() != 1) {
            errors.add("stream '" + streamId + "': dialect.escape must be one character or "
                    + "absent, got '" + escape + "'");
        }
        try {
            Charset.forName(charset);
        } catch (Exception e) {
            errors.add("stream '" + streamId + "': unknown dialect.charset '" + charset + "'");
        }
        if (nullTokens == null) {
            errors.add("stream '" + streamId + "': dialect.nullTokens must not be null "
                    + "(use [] for none)");
        }
        return errors;
    }

    private static char singleChar(String s, String what) {
        if (s == null || s.length() != 1) {
            throw new IllegalStateException(
                    "dialect." + what + " must be exactly one character, got '" + s + "'");
        }
        return s.charAt(0);
    }
}
