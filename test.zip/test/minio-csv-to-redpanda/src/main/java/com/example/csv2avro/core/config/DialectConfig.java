package com.example.csv2avro.core.config;

import java.io.Serializable;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * CSV dialect of one stream, from YAML. Single-character fields are strings in YAML for
 * readability and validated here.
 *
 * <p>No {@code skipLines} — not built, because no type has a preamble. Preamble junk would land
 * in the DLQ as malformed or column-count rejects. A type that has one needs {@code skipLines}
 * added here and honoured by {@code LineParser}.
 */
public class DialectConfig implements Serializable {

    public String delimiter = ",";
    public String quote = "\"";
    /** Null = RFC 4180 doubled quotes. */
    public String escape;
    /** Charset of the files; don't assume UTF-8, latin-1 exports are common. */
    public String charset = "UTF-8";
    /** Values meaning null, matched exactly against the raw cell. */
    public List<String> nullTokens = new ArrayList<>(List.of(""));

    public char delimiterChar() {
        return singleChar(delimiter, "delimiter");
    }

    public char quoteChar() {
        return singleChar(quote, "quote");
    }

    public Character escapeChar() {
        return escape == null ? null : singleChar(escape, "escape");
    }

    /**
     * Collects every problem at once, so one restart names them all. The single-character rule
     * is expressed only in {@link #singleCharError}: this method reports it and
     * {@link #singleChar} enforces it, but neither states it a second time.
     */
    List<String> validate(String streamId) {
        List<String> errors = new ArrayList<>();
        add(errors, streamId, singleCharError(delimiter, "delimiter"));
        add(errors, streamId, singleCharError(quote, "quote"));
        if (escape != null) {
            add(errors, streamId, singleCharError(escape, "escape"));
        }
        try {
            Charset.forName(charset);
        } catch (Exception e) {
            add(errors, streamId, "unknown dialect.charset '" + charset + "'");
        }
        if (nullTokens == null) {
            add(errors, streamId, "dialect.nullTokens must not be null (use [] for none)");
        }
        return errors;
    }

    private static void add(List<String> errors, String streamId, String error) {
        if (error != null) {
            errors.add("stream '" + streamId + "': " + error);
        }
    }

    /** Null when {@code s} is one character, otherwise the message describing why not. */
    private static String singleCharError(String s, String what) {
        return s != null && s.length() == 1
                ? null
                : "dialect." + what + " must be exactly one character, got '" + s + "'";
    }

    private static char singleChar(String s, String what) {
        String error = singleCharError(s, what);
        if (error != null) {
            throw new IllegalStateException(error);
        }
        return s.charAt(0);
    }
}
