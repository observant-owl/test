package com.example.csv2avro.core.spi;

import com.example.csv2avro.core.csv.CsvRow;
import java.io.Serializable;
import org.apache.avro.specific.SpecificRecordBase;

/**
 * Maps one parsed CSV row to the type's Avro record, or rejects it to the DLQ.
 *
 * <p>This is where all column manipulation happens, as plain Java (deliberately no config
 * DSL). The CSV's shape is pinned by {@code expectedHeader} in config; what to do with the
 * columns is decided here, per row, statelessly:
 *
 * <ul>
 *   <li><b>Remove</b> a column — simply never read it (it must still be in
 *       {@code expectedHeader}, but needs no Avro field).
 *   <li><b>Rename</b> — read one name, set another: {@code .setCustomerId(row.require("cust_no"))}.
 *   <li><b>Modify/normalize</b> — transform before setting, e.g. via the {@code Cols} helpers
 *       (trim, empty→null, numeric/boolean/timestamp parsing with explicit timezone).
 *   <li><b>Add</b> — set an Avro field from a constant or derived from other columns. New
 *       schema fields need defaults (or be nullable) to stay BACKWARD-compatible.
 * </ul>
 *
 * <p>Access is name-based: {@code row.get("col")} returns {@code null} for null-token values,
 * {@code row.require("col")} rejects the row instead. Contract: exactly one record per row —
 * throwing {@link RowRejectedException} (also done by failed {@code Cols} conversions) sends
 * the raw line to the DLQ with the reason while the file keeps processing. Lock in the
 * behavior via the type's conformance fixture ({@code fixtures/<id>/}).
 */
@FunctionalInterface
public interface RowMapper<T extends SpecificRecordBase> extends Serializable {

    T map(CsvRow row) throws RowRejectedException;
}
