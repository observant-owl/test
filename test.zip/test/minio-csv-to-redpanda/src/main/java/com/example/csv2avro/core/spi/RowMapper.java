package com.example.csv2avro.core.spi;

import com.example.csv2avro.core.csv.CsvRow;
import java.io.Serializable;
import org.apache.avro.specific.SpecificRecordBase;

/**
 * Maps one parsed CSV row to the type's Avro record. All column manipulation happens here, as
 * plain Java — deliberately no config-driven mapping DSL.
 *
 * <p>Three outcomes: return a record (normal), return {@code null} (deliberately drop an
 * uninteresting row), or throw {@link RowRejectedException} (bad input → DLQ). Drop and reject
 * are separate so the DLQ-rate alert stays meaningful; see CLAUDE.md.
 *
 * <p>Every non-string conversion must go through {@code Cols}, or a parse failure kills the
 * task instead of producing a counted DLQ entry naming the column and value.
 */
@FunctionalInterface
public interface RowMapper<T extends SpecificRecordBase> extends Serializable {

    /** @return the mapped record, or {@code null} to deliberately drop the row. */
    T map(CsvRow row) throws RowRejectedException;
}
