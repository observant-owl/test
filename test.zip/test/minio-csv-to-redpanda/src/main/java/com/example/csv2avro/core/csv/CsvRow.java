package com.example.csv2avro.core.csv;

import com.example.csv2avro.core.spi.RowRejectedException;

/**
 * The only thing a mapper sees. Name-addressed, never positional — columns resolve against the
 * pinned expected header, so an upstream column insertion cannot silently shift values.
 */
public interface CsvRow {

    /**
     * Column value, or null if it matched a configured null token.
     *
     * @throws IllegalArgumentException if {@code column} is not in the expected header — that
     *     is a mapper/config mismatch (a bug), not bad data, and must fail loudly.
     */
    String get(String column);

    /** Same, but rejects the row to the DLQ if the value is null. */
    String require(String column) throws RowRejectedException;

    /** The raw input line, for DLQ payloads. */
    String rawLine();
}
