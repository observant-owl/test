package com.example.csv2avro.core.csv;

import com.example.csv2avro.core.spi.RowRejectedException;

/**
 * The only thing a mapper sees. Name-addressed, never positional — columns are resolved
 * against the pinned expected header from config, so an upstream column insertion can never
 * silently shift values.
 *
 * <p>No provenance accessors (object key, row number, mtime): the source emits a flat record
 * stream without file boundaries, and dedup happens downstream in ClickHouse on a
 * content-derived business key, so provenance was deliberately dropped (see OPEN-QUESTIONS §4).
 */
public interface CsvRow {

    /**
     * Column value, or null if it matched a configured null token.
     *
     * @throws IllegalArgumentException if {@code column} is not in the expected header — that
     *     is a mapper/config mismatch (a bug), not bad data, and must fail loudly.
     */
    String get(String column);

    /** Same, but rejects the row to the DLQ if the value is null. */
    String require(String column) throws RowRejectedException;

    /** The raw input line, for DLQ payloads. */
    String rawLine();
}
