package com.example.csv2avro.core.config;

import java.io.Serializable;

/**
 * Per-stream (per CSV type) configuration. No {@code enabled} flag: the presence of this block
 * is the enable.
 */
public class StreamConfig implements Serializable {

    /** S3 prefix to ingest, e.g. {@code s3://bucket/type-a/}. Env-invariant: dev and prod read
     * the same objects. */
    public String prefix;

    /** Target Kafka topic, e.g. {@code type-a.v1}. */
    public String topic;

    /** The verbatim header line as it appears in the files. Drives name-based column binding;
     * lines equal to it are dropped. Assumed stable — see {@code LineParser}. */
    public String expectedHeader;

    public DialectConfig dialect = new DialectConfig();

    /**
     * Optional overrides of the shared sections. Boxed by design: {@code null} means "inherit",
     * which is not "set it to the default". Resolve via {@code JobConfig.parallelism(sc)} /
     * {@code monitorIntervalSeconds(sc)} — reading these directly skips the fallback.
     */
    public Integer parallelism;

    public Long monitorIntervalSeconds;
}
