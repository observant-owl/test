package com.example.csv2avro.core.config;

import java.io.Serializable;
import java.util.List;

/**
 * Per-stream (per CSV type) configuration. Everything type-specific that is data lives here,
 * so filling in a type later means editing YAML, not code — only the row mapper and the
 * {@code .avsc} are code.
 */
public class StreamConfig implements Serializable {

    public boolean enabled = true;

    /** S3 prefix to ingest, e.g. {@code s3://bucket/type-a/}. */
    public String prefix;

    /** Optional explicit object list; takes precedence over {@code prefix}. Meant for the
     * missing-files profile when replaying a handful of known objects. */
    public List<String> paths;

    /** Target Kafka topic, e.g. {@code type-a.v1}. */
    public String topic;

    /** The verbatim header line as it appears in the files. Drives name-based column binding;
     * lines equal to it are dropped, header-shaped lines differing from it halt the type. */
    public String expectedHeader;

    public DialectConfig dialect = new DialectConfig();

    /** Optional overrides of the defaults section. */
    public Integer sourceParallelism;
    public Integer sinkParallelism;
}
