package com.example.csv2avro.core.dlq;

import java.io.Serializable;

/**
 * One rejected input, as JSON on the shared DLQ topic. Deliberately not Avro — the whole
 * point of a DLQ is holding things that didn't fit a schema. Public fields + no-arg
 * constructor so Flink's POJO serializer and Jackson both handle it natively.
 */
public class DlqRecord implements Serializable {

    public String streamId;
    public String reason;
    /** The raw input line; null for file-level entries (corrupt file). */
    public String rawLine;
    /** Source object path. Set on every entry, row-level ones included: each record carries
     * its file identity from the source (see {@code Line}). */
    public String objectKey;
    /** Wall-clock time the rejection happened, epoch millis. */
    public long timestamp;

    public DlqRecord() {
        // Flink POJO / Jackson
    }

    public static DlqRecord of(String streamId, String reason, String rawLine, String objectKey) {
        DlqRecord r = new DlqRecord();
        r.streamId = streamId;
        r.reason = reason;
        r.rawLine = rawLine;
        r.objectKey = objectKey;
        r.timestamp = System.currentTimeMillis();
        return r;
    }

    @Override
    public String toString() {
        return "DlqRecord{streamId='" + streamId + "', reason='" + reason + "', rawLine='"
                + rawLine + "', objectKey='" + objectKey + "', timestamp=" + timestamp + "}";
    }
}
