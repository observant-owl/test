package com.example.csv2avro.api;

/**
 * The bounded set of reasons a row can be rejected — an enum because these become a Prometheus
 * label, where free text is a cardinality explosion. The prose reason still travels to the DLQ
 * payload; this is only the coarse bucket you graph and alert on.
 */
public enum RejectReason {

    /** The line is not parseable CSV at all (unbalanced quotes, bad escape). */
    MALFORMED_CSV("malformed-csv"),

    /** Parseable, but a different number of fields than the pinned header. */
    COLUMN_COUNT("column-count"),

    /** A column the mapper requires was null or matched a null token. */
    MISSING_REQUIRED("missing-required"),

    /** A value did not convert: not a number, not a boolean, unparseable timestamp. */
    VALUE_FORMAT("value-format"),

    /** Anything a mapper rejects without picking a more specific code. */
    MAPPER_OTHER("mapper-other");

    private final String label;

    RejectReason(String label) {
        this.label = label;
    }

    /** The stable, lowercase Prometheus label value. Never change one of these casually — it
     * silently breaks every dashboard and alert that filters on it. */
    public String label() {
        return label;
    }
}
