package com.example.csv2avro.core.kafka;

import com.example.csv2avro.core.config.JobConfig;
import com.example.csv2avro.core.config.StreamConfig;
import com.example.csv2avro.core.dlq.DlqJsonSerializationSchema;
import com.example.csv2avro.core.dlq.DlqRecord;
import com.example.csv2avro.core.spi.CsvStreamDefinition;
import java.util.Properties;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.flink.connector.base.DeliveryGuarantee;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.formats.avro.registry.confluent.ConfluentRegistryAvroSerializationSchema;

/**
 * Kafka sink builders. Subject naming is TopicNameStrategy ({@code <topic>-value}).
 *
 * <p>TODO(schema-registry): production policy is "explicit registration, BACKWARD
 * compatibility, no auto-register" — register subjects in a CI step before deploying. Flink's
 * Confluent serializer will register a schema it doesn't find; treat CI registration as the
 * gate, and consider locking the registry down so only CI may register.
 */
public final class Sinks {

    private Sinks() {
    }

    public static <T extends SpecificRecordBase> KafkaSink<T> forStream(
            JobConfig cfg, StreamConfig sc, CsvStreamDefinition<T> def) {
        var valueSerializer = ConfluentRegistryAvroSerializationSchema.forSpecific(
                def.avroClass(), sc.topic + "-value", cfg.kafka.schemaRegistryUrl);
        return KafkaSink.<T>builder()
                .setBootstrapServers(cfg.kafka.bootstrapServers)
                .setKafkaProducerConfig(producerProperties(cfg))
                .setDeliveryGuarantee(DeliveryGuarantee.AT_LEAST_ONCE)
                .setRecordSerializer(
                        new KeyedAvroRecordSerializer<>(sc.topic, valueSerializer,
                                def.keyExtractor()))
                .build();
    }

    public static KafkaSink<DlqRecord> forDlq(JobConfig cfg) {
        return KafkaSink.<DlqRecord>builder()
                .setBootstrapServers(cfg.kafka.bootstrapServers)
                .setKafkaProducerConfig(producerProperties(cfg))
                .setDeliveryGuarantee(DeliveryGuarantee.AT_LEAST_ONCE)
                .setRecordSerializer(KafkaRecordSerializationSchema.<DlqRecord>builder()
                        .setTopic(cfg.dlq.topic)
                        .setValueSerializationSchema(new DlqJsonSerializationSchema())
                        .build())
                .build();
    }

    private static Properties producerProperties(JobConfig cfg) {
        Properties props = new Properties();
        cfg.kafka.properties.forEach(props::setProperty);
        return props;
    }
}
