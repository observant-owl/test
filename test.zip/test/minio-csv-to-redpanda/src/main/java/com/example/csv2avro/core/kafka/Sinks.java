package com.example.csv2avro.core.kafka;

import com.example.csv2avro.core.config.JobConfig;
import com.example.csv2avro.core.config.StreamConfig;
import com.example.csv2avro.core.dlq.DlqJsonSerializationSchema;
import com.example.csv2avro.core.dlq.DlqRecord;
import com.example.csv2avro.core.spi.CsvStreamDefinition;
import com.example.csv2avro.core.spi.KeyExtractor;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Properties;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.flink.api.common.serialization.SerializationSchema;
import org.apache.flink.connector.base.DeliveryGuarantee;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.connector.kafka.sink.KafkaSinkBuilder;
import org.apache.flink.formats.avro.registry.confluent.ConfluentRegistryAvroSerializationSchema;

/**
 * Kafka sink builders. Subject naming is TopicNameStrategy ({@code <topic>-value}).
 *
 * <p>TODO(schema-registry): production policy is "explicit registration, BACKWARD
 * compatibility, no auto-register" — register subjects in a CI step before deploying. Flink's
 * Confluent serializer will register a schema it doesn't find; treat CI registration as the
 * gate, and consider locking the registry down so only CI may register. Note that a repair run
 * overrides the topic in config, which derives a <em>new</em> subject the serializer would
 * auto-register — register it from the same {@code .avsc} in CI too.
 */
public final class Sinks {

    private Sinks() {
    }

    public static <T extends SpecificRecordBase> KafkaSink<T> forStream(
            JobConfig cfg, StreamConfig sc, CsvStreamDefinition<T> def) {
        SerializationSchema<T> valueSerializer =
                ConfluentRegistryAvroSerializationSchema.forSpecific(
                        def.avroClass(), sc.topic + "-value", cfg.kafka.schemaRegistryUrl);
        KeyExtractor<T> keyExtractor = def.keyExtractor();
        return Sinks.<T>base(cfg)
                .setRecordSerializer(KafkaRecordSerializationSchema.<T>builder()
                        .setTopic(sc.topic)
                        .setValueSerializationSchema(valueSerializer)
                        // A null key means round-robin partitioning; the builder's wrapper
                        // handles that and opens both schemas for us.
                        .setKeySerializationSchema((SerializationSchema<T>) record -> {
                            String key = keyExtractor.key(record);
                            return key == null ? null : key.getBytes(StandardCharsets.UTF_8);
                        })
                        .build())
                .build();
    }

    /** The one DLQ sink, shared by every stream in the job. */
    public static KafkaSink<DlqRecord> forDlq(JobConfig cfg) {
        return Sinks.<DlqRecord>base(cfg)
                .setRecordSerializer(KafkaRecordSerializationSchema.<DlqRecord>builder()
                        .setTopic(cfg.dlq.topic)
                        .setValueSerializationSchema(new DlqJsonSerializationSchema())
                        .build())
                .build();
    }

    /** Everything both sinks share, so the delivery guarantee has one definition. */
    private static <T> KafkaSinkBuilder<T> base(JobConfig cfg) {
        return KafkaSink.<T>builder()
                .setBootstrapServers(cfg.kafka.bootstrapServers)
                .setKafkaProducerConfig(producerProperties(cfg.kafka.properties))
                .setDeliveryGuarantee(DeliveryGuarantee.AT_LEAST_ONCE);
    }

    private static Properties producerProperties(Map<String, String> from) {
        Properties props = new Properties();
        from.forEach(props::setProperty);
        return props;
    }
}
