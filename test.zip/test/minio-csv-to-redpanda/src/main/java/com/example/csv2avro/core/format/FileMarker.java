package com.example.csv2avro.core.format;

/**
 * An in-band file-boundary marker: a synthetic "line" that {@link CorruptTolerantBulkFormat}
 * injects into the record stream so the parse operator can count files, bytes and freshness.
 * Pure (Flink-free) so it can be unit-tested and shared by the parser.
 *
 * <p>Why in-band rather than a source wrapper: a {@code SourceReader} decorator sees splits
 * <em>assigned</em> but never splits <em>finished</em> (completion is handled inside
 * {@code SourceReaderBase} and never surfaces), so it could not produce a "file completed"
 * signal — the one that separates "stuck mid-file" from "idle". The BulkFormat is also the
 * component already shared by the stock {@code FileSource} and {@code OwnFileSource}.
 *
 * <p>Wire format, NUL-separated, path last:
 *
 * <pre>
 *   NUL CSV2AVRO NUL &lt;KIND&gt; NUL &lt;modifiedMillis&gt; NUL &lt;sizeBytes&gt; NUL &lt;path&gt;
 * </pre>
 *
 * <p>NUL is the separator precisely because it cannot occur in a text CSV line, which makes a
 * marker unforgeable by real data. <b>Write every NUL as a Unicode escape in Java source, never
 * as a literal byte</b> — literal NULs have been pasted into string literals in this project
 * before and had to be repaired afterwards.
 *
 * <p>The path goes last so decoding is a limited split into a fixed field count with no
 * escaping, whatever the path contains (commas, spaces, {@code =}, unicode). Paths cannot
 * contain NUL, so the split is unambiguous.
 *
 * <p>Markers never leave the parse operator: {@code CsvToAvroFunction} turns them into metrics
 * and drops them, so nothing synthetic can reach Kafka or the DLQ.
 */
public final class FileMarker {

    /** Field separator. Unicode escape on purpose — see the class note. */
    private static final String SEP = "\u0000";

    /** Leading magic; already begins with the separator, so a marker always starts with NUL. */
    private static final String MAGIC = "\u0000CSV2AVRO";

    private static final int FIELDS = 6;

    /** OPEN on entering a file, DONE on reading it to the end, CORRUPT when it is skipped.
     * A failed file emits CORRUPT and <em>not</em> DONE. */
    public enum Kind { OPEN, DONE, CORRUPT }

    private final Kind kind;
    private final String path;
    private final long modifiedMillis;
    private final long sizeBytes;

    private FileMarker(Kind kind, String path, long modifiedMillis, long sizeBytes) {
        this.kind = kind;
        this.path = path;
        this.modifiedMillis = modifiedMillis;
        this.sizeBytes = sizeBytes;
    }

    public Kind kind() {
        return kind;
    }

    public String path() {
        return path;
    }

    /** File modification time in epoch millis, or a non-positive value if the source did not
     * supply one. Feeds the freshness gauge, which filters non-positive values out. */
    public long modifiedMillis() {
        return modifiedMillis;
    }

    /** On-the-wire (compressed) object size in bytes, or a non-positive value if unknown. */
    public long sizeBytes() {
        return sizeBytes;
    }

    public static String encode(Kind kind, String path, long modifiedMillis, long sizeBytes) {
        return MAGIC + SEP + kind.name() + SEP + modifiedMillis + SEP + sizeBytes + SEP + path;
    }

    /** The constant prefix every marker of this kind starts with — useful for assertions and
     * for {@code LineParser.CORRUPT_SENTINEL_PREFIX}. */
    public static String prefixFor(Kind kind) {
        return MAGIC + SEP + kind.name() + SEP;
    }

    /**
     * Decodes a marker, or returns {@code null} if the line is ordinary input. Anything that
     * looks marker-shaped but does not decode cleanly is also {@code null}, so a malformed
     * marker degrades into a normal (and almost certainly rejected) line rather than a crash.
     */
    public static FileMarker decode(String line) {
        // Cheap reject first: this runs on every input line.
        if (line == null || line.isEmpty() || line.charAt(0) != '\u0000'
                || !line.startsWith(MAGIC + SEP)) {
            return null;
        }
        String[] p = line.split(SEP, FIELDS);
        if (p.length != FIELDS) {
            return null;
        }
        Kind kind;
        try {
            kind = Kind.valueOf(p[2]);
        } catch (IllegalArgumentException e) {
            return null;
        }
        long modifiedMillis;
        long sizeBytes;
        try {
            modifiedMillis = Long.parseLong(p[3]);
            sizeBytes = Long.parseLong(p[4]);
        } catch (NumberFormatException e) {
            return null;
        }
        return new FileMarker(kind, p[5], modifiedMillis, sizeBytes);
    }

    @Override
    public String toString() {
        return "FileMarker[" + kind + " " + path + " mtime=" + modifiedMillis
                + " size=" + sizeBytes + "]";
    }
}
