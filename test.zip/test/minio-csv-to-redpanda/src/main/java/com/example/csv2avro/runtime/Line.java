package com.example.csv2avro.runtime;

import java.io.Serializable;

/**
 * One record from the file source: either a line of text, or a signal about the object itself.
 *
 * <p><b>Every instance carries the identity of the file it came from</b> — that is the whole
 * point of this type, and it is what lets a rejected row name its object in the DLQ.
 *
 * <p>Public fields and a no-arg constructor so Flink's POJO serializer handles it natively.
 * {@link #path} is a shared reference to one string per file, not a copy per row.
 */
public class Line implements Serializable {

    private static final long serialVersionUID = 1L;

    /** What this record is. {@link #text} is non-null only for {@link #DATA}. */
    public enum Kind {

        /** A line of text read from the object. */
        DATA,

        /** Entering an object. Telemetry only. Emitted before any data line of its file,
         * including after a restore. */
        FILE_OPEN,

        /** The object is unreadable and is being skipped, wholly or from here on. */
        CORRUPT
    }

    public Kind kind;

    /** The raw line, for {@link Kind#DATA}; null for the two file signals. */
    public String text;

    /** Object path, e.g. {@code s3://bucket/type-a/x.csv.gz}. */
    public String path;

    /** Object modification time in epoch millis, or non-positive if the source supplied none.
     * Feeds the freshness gauge, which filters non-positive values out. */
    public long modifiedMillis;

    /** On-the-wire (compressed) object size in bytes, or non-positive if unknown. */
    public long sizeBytes;

    public Line() {
        // Flink POJO
    }

    private Line(Kind kind, String text, String path, long modifiedMillis, long sizeBytes) {
        this.kind = kind;
        this.text = text;
        this.path = path;
        this.modifiedMillis = modifiedMillis;
        this.sizeBytes = sizeBytes;
    }

    public static Line data(String text, String path, long modifiedMillis, long sizeBytes) {
        return new Line(Kind.DATA, text, path, modifiedMillis, sizeBytes);
    }

    public static Line fileOpen(String path, long modifiedMillis, long sizeBytes) {
        return new Line(Kind.FILE_OPEN, null, path, modifiedMillis, sizeBytes);
    }

    public static Line corrupt(String path, long modifiedMillis, long sizeBytes) {
        return new Line(Kind.CORRUPT, null, path, modifiedMillis, sizeBytes);
    }

    @Override
    public String toString() {
        return "Line[" + kind + " " + path + " mtime=" + modifiedMillis + " size=" + sizeBytes
                + (kind == Kind.DATA ? " text=" + text : "") + "]";
    }
}
