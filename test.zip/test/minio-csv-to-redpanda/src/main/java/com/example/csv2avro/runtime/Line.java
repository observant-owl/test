package com.example.csv2avro.runtime;

import java.io.Serializable;

/**
 * One record from the file source: either a line of text, or a signal about the object itself.
 *
 * <p><b>Every instance carries the identity of the file it came from</b> — that is the whole
 * point of this type, and it is what lets a rejected row name its object in the DLQ.
 *
 * <p>A record, and Flink serializes it as a POJO rather than by Kryo: {@code analyzePojo} skips
 * the public-field requirement for records, and {@code PojoSerializer} builds them through their
 * canonical constructor ({@code JavaRecordBuilderFactory}). Immutability is also what makes
 * {@code pipeline.object-reuse} safe here — see trap 9 in CLAUDE.md.
 *
 * @param text the raw line, for {@link Kind#DATA}; null for the two file signals
 * @param path object path, e.g. {@code s3://bucket/type-a/x.csv.gz}. One shared string per file,
 *     not a copy per row
 * @param modifiedMillis object modification time in epoch millis, or non-positive if the source
 *     supplied none. Feeds the freshness gauge, which filters non-positive values out
 * @param sizeBytes on-the-wire (compressed) object size in bytes, or non-positive if unknown
 */
public record Line(Kind kind, String text, String path, long modifiedMillis, long sizeBytes)
        implements Serializable {

    /** What this record is. {@link Line#text} is non-null only for {@link #DATA}. */
    public enum Kind {

        /** A line of text read from the object. */
        DATA,

        /** Entering an object. Telemetry only. Emitted before any data line of its file,
         * including after a restore. */
        FILE_OPEN,

        /** The object is unreadable and is being skipped, wholly or from here on. */
        CORRUPT
    }

    public static Line data(String text, String path, long modifiedMillis, long sizeBytes) {
        return new Line(Kind.DATA, text, path, modifiedMillis, sizeBytes);
    }

    public static Line fileOpen(String path, long modifiedMillis, long sizeBytes) {
        return new Line(Kind.FILE_OPEN, null, path, modifiedMillis, sizeBytes);
    }

    public static Line corrupt(String path, long modifiedMillis, long sizeBytes) {
        return new Line(Kind.CORRUPT, null, path, modifiedMillis, sizeBytes);
    }

    @Override
    public String toString() {
        return "Line[" + kind + " " + path + " mtime=" + modifiedMillis + " size=" + sizeBytes
                + (kind == Kind.DATA ? " text=" + text : "") + "]";
    }
}
