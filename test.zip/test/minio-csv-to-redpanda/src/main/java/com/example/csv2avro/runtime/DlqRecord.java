package com.example.csv2avro.runtime;

import java.io.Serializable;

/**
 * One rejected input, as JSON on the shared DLQ topic. Deliberately not Avro — the whole point of
 * a DLQ is holding things that didn't fit a schema.
 *
 * <p>A record: Flink serializes it as a POJO (see {@link Line}), and Jackson has bound records
 * through their canonical constructor since 2.12, so the JSON shape is unchanged.
 *
 * @param rawLine the raw input line; null for file-level entries (corrupt file)
 * @param objectKey source object path. Set on every entry, row-level ones included: each record
 *     carries its file identity from the source (see {@link Line})
 * @param timestamp wall-clock time the rejection happened, epoch millis
 */
public record DlqRecord(
        String streamId, String reason, String rawLine, String objectKey, long timestamp)
        implements Serializable {

    public static DlqRecord of(String streamId, String reason, String rawLine, String objectKey) {
        return new DlqRecord(streamId, reason, rawLine, objectKey, System.currentTimeMillis());
    }
}
