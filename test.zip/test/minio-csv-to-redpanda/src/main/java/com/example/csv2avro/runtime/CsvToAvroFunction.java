package com.example.csv2avro.runtime;

import com.example.csv2avro.api.CsvStreamDefinition;
import com.example.csv2avro.api.RowMapper;
import com.example.csv2avro.api.RowRejectedException;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.flink.api.common.functions.OpenContext;
import org.apache.flink.configuration.ReadableConfig;
import org.apache.flink.metrics.MetricGroup;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Parse + map in one chained operator, with rejected input on the DLQ side output. One operator
 * rather than two, so no intermediate CsvRow ever travels between operators.
 *
 * <p>Every line ends in exactly one place and increments exactly one counter, so "rows that
 * vanished" is not a reachable state. File signals are consumed here and <b>never forwarded</b>,
 * so nothing synthetic can reach Kafka. This is also the job's one metrics site.
 */
public class CsvToAvroFunction<T extends SpecificRecordBase> extends ProcessFunction<Line, T> {

    private static final long serialVersionUID = 1L;
    private static final Logger LOG = LoggerFactory.getLogger(CsvToAvroFunction.class);

    // ParserSettings instead of the Configuration: only the scalars the parser needs are
    // serialized into the job graph.
    private final ParserSettings settings;
    private final String streamId;
    private final RowMapper<T> mapper;
    private final OutputTag<DlqRecord> dlqTag;

    private transient LineParser parser;
    private transient StreamMetrics metrics;

    public CsvToAvroFunction(
            ReadableConfig conf, CsvStreamDefinition<T> def, OutputTag<DlqRecord> dlqTag) {
        this.settings = ParserSettings.of(conf, def.id());
        this.streamId = def.id();
        this.mapper = def.mapper();
        this.dlqTag = dlqTag;
    }

    @Override
    public void open(OpenContext openContext) {
        initialize(getRuntimeContext().getMetricGroup());
    }

    /** Test seam. Faking a {@code RuntimeContext} just to reach the metric group would mean
     * pulling in Flink's test-jars; this keeps that cost at one package-private method. */
    void initialize(MetricGroup metricGroup) {
        parser = settings.newParser();
        metrics = new StreamMetrics(metricGroup, streamId);
    }

    @Override
    public void processElement(Line line, Context ctx, Collector<T> out) {
        LineParser.Outcome o = parser.parse(line);
        switch (o.kind) {
            case ROW -> {
                T record;
                try {
                    record = mapper.map(o.row);
                } catch (RowRejectedException e) {
                    metrics.rowRejected(e.code());
                    ctx.output(dlqTag, DlqRecord.of(streamId, "row-rejected: " + e.getMessage(),
                            o.rawLine(), o.objectPath()));
                    return;
                } catch (RuntimeException e) {
                    // A mapper bug, not bad data: fail the job rather than mangle records. The
                    // DLQ entry and log line are written on the way out because the counter is
                    // incremented on a task that is about to die and rarely survives to be
                    // scraped. At-least-once: a repeating failure re-enters the DLQ per attempt.
                    metrics.mapperFailure();
                    LOG.error("stream '{}': mapper threw a non-rejection failure on line [{}] "
                            + "of object '{}'", streamId, o.rawLine(), o.objectPath(), e);
                    ctx.output(dlqTag, DlqRecord.of(streamId,
                            "mapper-failure: " + e, o.rawLine(), o.objectPath()));
                    throw e;
                }
                if (record == null) {
                    // Deliberate filter (RowMapper contract), not an error: count and move on.
                    metrics.rowDropped();
                    return;
                }
                out.collect(record);
                metrics.recordOut();
            }
            case HEADER -> metrics.headerLineDropped();
            case BLANK -> metrics.blankLineDropped();
            case REJECT -> {
                metrics.rowRejected(o.code);
                // The label and the prose have one composition site, so the DLQ payload cannot
                // disagree with the Prometheus label it is supposed to explain.
                ctx.output(dlqTag, DlqRecord.of(streamId,
                        o.code.label() + ": " + o.reason, o.rawLine(), o.objectPath()));
            }
            case CORRUPT -> {
                metrics.corruptFileSkipped();
                LOG.warn("stream '{}': skipped unreadable object '{}'",
                        streamId, o.objectPath());
                ctx.output(dlqTag, DlqRecord.of(
                        streamId, "corrupt-file-skipped", null, o.objectPath()));
            }
            // File starts are telemetry only: counted here, forwarded nowhere.
            case FILE_OPEN -> metrics.fileOpened(o.line.modifiedMillis, o.line.sizeBytes);
            // Not dead code and not defensive: a statement switch over an enum needs no default,
            // so a seventh Outcome.Kind would compile and silently drop every line of that kind
            // — "rows that vanished", which this operator's whole contract says cannot happen.
            // Failing the task instead turns that into a crash loop somebody notices.
            default -> throw new IllegalStateException("stream '" + streamId
                    + "': unhandled outcome kind " + o.kind + " — every line must be accounted "
                    + "for exactly once, so a new kind needs a branch here");
        }
    }
}
