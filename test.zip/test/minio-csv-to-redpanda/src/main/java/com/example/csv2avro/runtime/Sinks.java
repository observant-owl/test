package com.example.csv2avro.runtime;

import com.example.csv2avro.api.CsvStreamDefinition;
import com.example.csv2avro.api.KeyExtractor;
import java.nio.charset.StandardCharsets;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.flink.api.common.serialization.SerializationSchema;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.connector.base.DeliveryGuarantee;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.connector.kafka.sink.KafkaSinkBuilder;
import org.apache.flink.formats.avro.registry.confluent.ConfluentRegistryAvroSerializationSchema;

/**
 * Kafka sink builders. Subject naming is TopicNameStrategy ({@code <topic>-value}).
 *
 * <p>TODO(schema-registry): production policy is "explicit registration, BACKWARD
 * compatibility, no auto-register" — register subjects in a CI step before deploying. Flink's
 * Confluent serializer will register a schema it doesn't find; treat CI registration as the
 * gate, and consider locking the registry down so only CI may register. Note that a repair run
 * overrides the topic in config, which derives a <em>new</em> subject the serializer would
 * auto-register — register it from the same {@code .avdl} in CI too.
 */
public final class Sinks {

    private Sinks() {
    }

    public static <T extends SpecificRecordBase> KafkaSink<T> forStream(
            Configuration conf, CsvStreamDefinition<T> def) {
        String topic = conf.get(CsvConfig.TOPIC);
        SerializationSchema<T> valueSerializer =
                ConfluentRegistryAvroSerializationSchema.forSpecific(
                        def.avroClass(), topic + "-value",
                        conf.get(CsvConfig.SCHEMA_REGISTRY_URL));
        KeyExtractor<T> keyExtractor = def.keyExtractor();
        return Sinks.<T>base(conf)
                .setRecordSerializer(KafkaRecordSerializationSchema.<T>builder()
                        .setTopic(topic)
                        .setValueSerializationSchema(valueSerializer)
                        // A null key means round-robin partitioning; the builder's wrapper
                        // handles that and opens both schemas for us.
                        .setKeySerializationSchema((SerializationSchema<T>) record -> {
                            String key = keyExtractor.key(record);
                            return key == null ? null : key.getBytes(StandardCharsets.UTF_8);
                        })
                        .build())
                .build();
    }

    /** The one DLQ sink, shared by every stream in the job. */
    public static KafkaSink<DlqRecord> forDlq(Configuration conf) {
        return Sinks.<DlqRecord>base(conf)
                .setRecordSerializer(KafkaRecordSerializationSchema.<DlqRecord>builder()
                        .setTopic(conf.get(CsvConfig.DLQ_TOPIC))
                        .setValueSerializationSchema(new DlqJsonSerializationSchema())
                        .build())
                .build();
    }

    /** Everything both sinks share, so the delivery guarantee has one definition. */
    private static <T> KafkaSinkBuilder<T> base(Configuration conf) {
        KafkaSinkBuilder<T> builder = KafkaSink.<T>builder()
                .setBootstrapServers(conf.get(CsvConfig.BOOTSTRAP_SERVERS))
                .setDeliveryGuarantee(DeliveryGuarantee.AT_LEAST_ONCE);
        CsvConfig.producerProperties(conf).forEach(builder::setProperty);
        return builder;
    }
}
