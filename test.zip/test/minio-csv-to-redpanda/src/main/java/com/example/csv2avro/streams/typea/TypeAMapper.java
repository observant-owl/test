package com.example.csv2avro.streams.typea;

import com.example.csv2avro.core.avro.Cols;
import com.example.csv2avro.core.csv.CsvRow;
import com.example.csv2avro.core.spi.RowMapper;
import com.example.csv2avro.core.spi.RowRejectedException;
import com.example.csv2avro.generated.TypeA;

/**
 * TEMPLATE mapper — the per-type normalize / remove / change / add logic, as plain testable
 * Java (deliberately no config-driven mapping DSL).
 *
 * <p>Column access is name-based against the pinned {@code expectedHeader} from config:
 * {@code row.get("col")} → null if absent-by-null-token, {@code row.require("col")} → rejects
 * the row to the DLQ when null. Removing a column = simply not reading it. Adding a derived
 * field = computing it here.
 *
 * <p>TODO(user): replace the example logic below with the real column surgery for this type.
 * Pin per column: empty-vs-null, timestamp format + source timezone (never JVM default),
 * decimal-vs-double.
 */
public class TypeAMapper implements RowMapper<TypeA> {

    private static final long serialVersionUID = 1L;

    @Override
    public TypeA map(CsvRow row) throws RowRejectedException {
        return TypeA.newBuilder()
                .setId(row.require("id"))
                .setName(Cols.emptyToNull(Cols.trim(row.get("name"))))
                .setValue(Cols.optDouble(row.get("value"), "value"))
                .build();
        // Example for a timestamp column (target: timestamp-millis long):
        //   .setEventTime(Cols.optTimestampMillis(row.get("event_time"), "event_time",
        //           DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
        //           ZoneId.of("Europe/Berlin")))
    }
}
