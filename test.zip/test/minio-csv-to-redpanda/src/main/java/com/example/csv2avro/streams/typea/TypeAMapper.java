package com.example.csv2avro.streams.typea;

import com.example.csv2avro.api.Cols;
import com.example.csv2avro.api.CsvRow;
import com.example.csv2avro.api.RowMapper;
import com.example.csv2avro.api.RowRejectedException;
import com.example.csv2avro.generated.TypeA;

/**
 * TEMPLATE mapper — the per-type normalize / remove / change / add logic, as plain testable
 * Java (deliberately no config-driven mapping DSL).
 *
 * <p>Column access is name-based against the pinned {@code expected-header}:
 * {@code row.get("col")} → null if absent-by-null-token, {@code row.require("col")} → rejects
 * the row to the DLQ when null. Removing a column = simply not reading it. Adding a derived
 * field = computing it here.
 *
 * <p>TODO(user): replace the example logic below with the real column surgery for this type.
 * Pin per column: empty-vs-null, timestamp format + source timezone (never JVM default),
 * decimal-vs-double.
 */
public class TypeAMapper implements RowMapper<TypeA> {

    private static final long serialVersionUID = 1L;

    // Formatters and zones belong here, never inside map(). Building a DateTimeFormatter parses
    // its pattern from scratch, which costs more per row than the parse it feeds. Both types are
    // immutable and thread-safe, so a static field is correct as well as cheap.
    //
    // private static final DateTimeFormatter EVENT_TIME =
    //         DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    // private static final ZoneId SOURCE_ZONE = ZoneId.of("Europe/Berlin");

    @Override
    public TypeA map(CsvRow row) throws RowRejectedException {
        return TypeA.newBuilder()
                .setId(row.require("id"))
                .setName(Cols.emptyToNull(Cols.trim(row.get("name"))))
                .setValue(Cols.optDouble(row.get("value"), "value"))
                .build();
        // Example for a timestamp column (target: timestamp-millis long), using the fields
        // above rather than constructing a formatter per row:
        //   .setEventTime(Cols.optTimestampMillis(row.get("event_time"), "event_time",
        //           EVENT_TIME, SOURCE_ZONE))
        //
        // The builder is order-independent and applies schema defaults. For a wide type the
        // generated all-args constructor is cheaper (the builder copies a Field[] per row), at
        // the cost of being positional — measure before trading readability for it.
    }
}
