package com.example.csv2avro.core.csv;

import com.example.csv2avro.core.config.DialectConfig;
import com.example.csv2avro.core.config.JobConfig;
import com.example.csv2avro.core.config.StreamConfig;
import com.example.csv2avro.core.dlq.DlqRecord;
import com.example.csv2avro.core.metrics.StreamMetrics;
import com.example.csv2avro.core.spi.CsvStreamDefinition;
import com.example.csv2avro.core.spi.RowMapper;
import com.example.csv2avro.core.spi.RowRejectedException;
import java.util.HashSet;
import java.util.Set;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.flink.api.common.functions.OpenContext;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Parse + map in one chained operator: raw line → {@link LineParser} classification →
 * {@link RowMapper} → Avro record, with rejected input on the DLQ side output. Merged into one
 * operator (instead of the plan's separate parse and map stages) so no intermediate CsvRow
 * type ever travels between operators.
 *
 * <p>This is also the job's one metrics site — every counter and gauge is declared in
 * {@link StreamMetrics}, which owns the naming and labelling. File-boundary markers injected by
 * {@code CorruptTolerantBulkFormat} are consumed here and <b>never forwarded</b>: the
 * {@code FILE_OPEN} / {@code FILE_DONE} / {@code CORRUPT} branches touch counters only, so
 * nothing synthetic can reach Kafka or the DLQ.
 */
public class CsvToAvroFunction<T extends SpecificRecordBase> extends ProcessFunction<String, T> {

    private static final long serialVersionUID = 1L;
    private static final Logger LOG = LoggerFactory.getLogger(CsvToAvroFunction.class);

    private final String streamId;
    private final String expectedHeader;
    private final char delimiter;
    private final char quote;
    private final Character escape;
    private final Set<String> nullTokens;
    private final boolean haltOnHeaderDrift;
    private final RowMapper<T> mapper;
    private final OutputTag<DlqRecord> dlqTag;

    private transient LineParser parser;
    private transient StreamMetrics metrics;

    public CsvToAvroFunction(
            JobConfig cfg, StreamConfig sc, CsvStreamDefinition<T> def,
            OutputTag<DlqRecord> dlqTag) {
        DialectConfig d = sc.dialect;
        this.streamId = def.id();
        this.expectedHeader = sc.expectedHeader;
        this.delimiter = d.delimiterChar();
        this.quote = d.quoteChar();
        this.escape = d.escapeChar();
        this.nullTokens = new HashSet<>(d.nullTokens);
        this.haltOnHeaderDrift = cfg.defaults.haltOnHeaderDrift;
        this.mapper = def.mapper();
        this.dlqTag = dlqTag;
    }

    @Override
    public void open(OpenContext openContext) {
        parser = new LineParser(
                streamId, expectedHeader, delimiter, quote, escape, nullTokens,
                haltOnHeaderDrift);
        metrics = new StreamMetrics(getRuntimeContext().getMetricGroup(), streamId);
    }

    @Override
    public void processElement(String line, Context ctx, Collector<T> out) {
        LineParser.Outcome o;
        try {
            o = parser.parse(line);
        } catch (HeaderDriftException e) {
            metrics.headerDriftHalt();
            LOG.error("halting stream '{}' on header drift", streamId, e);
            throw e; // fails the task -> region restarts -> loud halt until redeploy
        }
        switch (o.kind) {
            case ROW -> {
                T record;
                try {
                    record = mapper.map(o.row);
                } catch (RowRejectedException e) {
                    metrics.rowRejected(e.code());
                    ctx.output(dlqTag, DlqRecord.of(
                            streamId, "row-rejected: " + e.getMessage(), o.row.rawLine(), null));
                    return;
                } catch (RuntimeException | Error e) {
                    // Without this the task dies incrementing nothing — an invisible failure.
                    metrics.mapperFailure();
                    LOG.error("stream '{}': mapper threw a non-rejection failure on line [{}]",
                            streamId, o.row.rawLine(), e);
                    throw e;
                }
                out.collect(record);
                metrics.recordOut();
            }
            case HEADER -> metrics.headerLineDropped();
            case BLANK -> metrics.blankLineDropped();
            case REJECT -> {
                metrics.rowRejected(o.code);
                ctx.output(dlqTag, DlqRecord.of(streamId, o.reason, o.rawLine, null));
            }
            case CORRUPT -> {
                metrics.corruptFileSkipped();
                LOG.warn("stream '{}': skipped unreadable object '{}'", streamId, o.objectKey);
                ctx.output(dlqTag, DlqRecord.of(
                        streamId, "corrupt-file-skipped", null, o.objectKey));
            }
            // File boundaries are telemetry only: counted here, forwarded nowhere.
            case FILE_OPEN -> metrics.fileOpened(o.fileModifiedMillis, o.fileSizeBytes);
            case FILE_DONE -> metrics.fileCompleted(o.fileModifiedMillis, o.fileSizeBytes);
        }
    }
}
