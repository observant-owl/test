package com.example.csv2avro.core.csv;

import com.example.csv2avro.core.config.StreamConfig;
import com.example.csv2avro.core.dlq.DlqRecord;
import com.example.csv2avro.core.format.Line;
import com.example.csv2avro.core.metrics.StreamMetrics;
import com.example.csv2avro.core.spi.CsvStreamDefinition;
import com.example.csv2avro.core.spi.RowMapper;
import com.example.csv2avro.core.spi.RowRejectedException;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.flink.api.common.functions.OpenContext;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Parse + map in one chained operator, with rejected input on the DLQ side output. One operator
 * rather than two, so no intermediate CsvRow ever travels between operators.
 *
 * <p>Every line ends in exactly one place and increments exactly one counter, so "rows that
 * vanished" is not a reachable state. File signals are consumed here and <b>never forwarded</b>,
 * so nothing synthetic can reach Kafka. This is also the job's one metrics site.
 */
public class CsvToAvroFunction<T extends SpecificRecordBase> extends ProcessFunction<Line, T> {

    private static final long serialVersionUID = 1L;
    private static final Logger LOG = LoggerFactory.getLogger(CsvToAvroFunction.class);

    // ParserSettings instead of the raw config objects: only the scalars the parser needs are
    // serialized into the job graph, never the whole JobConfig.
    private final ParserSettings settings;
    private final String streamId;
    private final RowMapper<T> mapper;
    private final OutputTag<DlqRecord> dlqTag;

    private transient LineParser parser;
    private transient StreamMetrics metrics;

    public CsvToAvroFunction(
            StreamConfig sc, CsvStreamDefinition<T> def, OutputTag<DlqRecord> dlqTag) {
        this.settings = ParserSettings.of(sc, def.id());
        this.streamId = def.id();
        this.mapper = def.mapper();
        this.dlqTag = dlqTag;
    }

    @Override
    public void open(OpenContext openContext) {
        parser = settings.newParser();
        metrics = new StreamMetrics(getRuntimeContext().getMetricGroup(), streamId);
    }

    @Override
    public void processElement(Line line, Context ctx, Collector<T> out) {
        LineParser.Outcome o = parser.parse(line);
        switch (o.kind) {
            case ROW -> {
                T record;
                try {
                    record = mapper.map(o.row);
                } catch (RowRejectedException e) {
                    metrics.rowRejected(e.code());
                    ctx.output(dlqTag, DlqRecord.of(streamId, "row-rejected: " + e.getMessage(),
                            o.rawLine(), o.objectPath()));
                    return;
                } catch (RuntimeException e) {
                    // A mapper bug, not bad data: fail the job rather than mangle records. The
                    // DLQ entry and log line are written on the way out because the counter is
                    // incremented on a task that is about to die and rarely survives to be
                    // scraped. At-least-once: a repeating failure re-enters the DLQ per attempt.
                    metrics.mapperFailure();
                    LOG.error("stream '{}': mapper threw a non-rejection failure on line [{}] "
                            + "of object '{}'", streamId, o.rawLine(), o.objectPath(), e);
                    ctx.output(dlqTag, DlqRecord.of(streamId,
                            "mapper-failure: " + e, o.rawLine(), o.objectPath()));
                    throw e;
                }
                if (record == null) {
                    // Deliberate filter (RowMapper contract), not an error: count and move on.
                    metrics.rowDropped();
                    return;
                }
                out.collect(record);
                metrics.recordOut();
            }
            case HEADER -> metrics.headerLineDropped();
            case BLANK -> metrics.blankLineDropped();
            case REJECT -> {
                metrics.rowRejected(o.code);
                ctx.output(dlqTag,
                        DlqRecord.of(streamId, o.reason, o.rawLine(), o.objectPath()));
            }
            case CORRUPT -> {
                metrics.corruptFileSkipped();
                LOG.warn("stream '{}': skipped unreadable object '{}'",
                        streamId, o.objectPath());
                ctx.output(dlqTag, DlqRecord.of(
                        streamId, "corrupt-file-skipped", null, o.objectPath()));
            }
            // File starts are telemetry only: counted here, forwarded nowhere.
            case FILE_OPEN -> metrics.fileOpened(o.line.modifiedMillis, o.line.sizeBytes);
        }
    }
}
