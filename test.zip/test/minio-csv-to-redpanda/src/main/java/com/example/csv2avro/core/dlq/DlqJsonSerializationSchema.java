package com.example.csv2avro.core.dlq;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.flink.api.common.serialization.SerializationSchema;

/** JSON encoding for the DLQ topic. */
public class DlqJsonSerializationSchema implements SerializationSchema<DlqRecord> {

    private static final long serialVersionUID = 1L;

    private transient ObjectMapper mapper;

    @Override
    public void open(InitializationContext context) {
        mapper = new ObjectMapper();
    }

    @Override
    public byte[] serialize(DlqRecord element) {
        try {
            return mapper.writeValueAsBytes(element);
        } catch (JsonProcessingException e) {
            // A DlqRecord is a flat POJO of strings and a long; this cannot happen for real
            // data, and if it does the DLQ itself is broken — fail loudly.
            throw new IllegalStateException("cannot serialize DLQ record: " + element, e);
        }
    }
}
