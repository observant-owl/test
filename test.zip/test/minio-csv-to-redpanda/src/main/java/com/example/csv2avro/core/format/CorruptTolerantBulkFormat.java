package com.example.csv2avro.core.format;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.connector.file.src.FileSourceSplit;
import org.apache.flink.connector.file.src.impl.StreamFormatAdapter;
import org.apache.flink.connector.file.src.reader.BulkFormat;
import org.apache.flink.connector.file.src.reader.StreamFormat;
import org.apache.flink.connector.file.src.util.RecordAndPosition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The "thin decorator" (user decision 2026-09-01, instead of a full custom BulkFormat): wraps
 * the stock line format and does two things the stock format cannot.
 *
 * <p><b>Corrupt-file tolerance.</b> A per-file {@code IOException} — corrupt gzip, truncated
 * object — becomes a single {@link FileMarker.Kind#CORRUPT} marker record followed by
 * end-of-split. The parse stage turns it into a Prometheus counter + log line + DLQ entry, and
 * the file is skipped; the job keeps running.
 *
 * <p><b>File boundaries.</b> When {@code defaults.emitFileMarkers} is on, an
 * {@link FileMarker.Kind#OPEN} marker precedes a file's records and a {@link FileMarker.Kind#DONE}
 * marker follows them, carrying the object's modification time and size. That is the only way
 * the flat record stream can support per-file counters and a freshness gauge — see
 * {@link FileMarker} for why this is done in-band rather than by wrapping the Source. A file
 * that fails mid-read emits CORRUPT and <em>not</em> DONE.
 *
 * <p>Wrapping at the {@link BulkFormat} level (around {@link StreamFormatAdapter}) rather than
 * at the {@link StreamFormat} level matters twice: the adapter's transparent decompression runs
 * <em>inside</em> the try, so even a corrupt gzip header is caught, and the split gives us the
 * object path, mtime and size — the file identity that otherwise does not survive.
 *
 * <p><b>Positions.</b> Synthetic records must never claim to advance the file position. With
 * {@link RecordAndPosition#NO_OFFSET} the skip count means "restart this file from the
 * beginning and skip N records", so a marker counted as a record would desynchronize the
 * position by one — an OPEN marker at skip count 1 would silently drop the first real line of
 * every file on any checkpoint restore. OPEN therefore carries skip count 0, and DONE/CORRUPT
 * carry the last <em>real</em> record's position (or 0 if none was read). This is asserted
 * directly in {@code CorruptTolerantBulkFormatTest}.
 *
 * <p>Known trade-off (accepted): a <em>transient</em> read error (network blip against MinIO)
 * is indistinguishable from corruption here and also skips the file. It shows up in the
 * corrupt-file counter and is repairable via the missing-files profile.
 *
 * <p>Not CSV-aware, not header-aware — deliberately. Works with any {@code StreamFormat<String>}
 * and can be handed to {@code OwnFileSource} (which accepts a BulkFormat) as well as to the
 * stock {@code FileSource}.
 */
public final class CorruptTolerantBulkFormat implements BulkFormat<String, FileSourceSplit> {

    private static final long serialVersionUID = 1L;
    private static final Logger LOG = LoggerFactory.getLogger(CorruptTolerantBulkFormat.class);

    private final StreamFormatAdapter<String> delegate;
    private final boolean emitFileMarkers;

    public CorruptTolerantBulkFormat(StreamFormat<String> lineFormat) {
        this(lineFormat, true);
    }

    public CorruptTolerantBulkFormat(StreamFormat<String> lineFormat, boolean emitFileMarkers) {
        this.delegate = new StreamFormatAdapter<>(lineFormat);
        this.emitFileMarkers = emitFileMarkers;
    }

    @Override
    public Reader<String> createReader(Configuration config, FileSourceSplit split)
            throws IOException {
        try {
            return new TolerantReader(delegate.createReader(config, split), split, openFor(split));
        } catch (IOException e) {
            LOG.warn("unreadable file '{}' (skipping, emitting corrupt-file marker): {}",
                    split.path(), e.toString());
            return new SentinelReader(split, openFor(split));
        }
    }

    @Override
    public Reader<String> restoreReader(Configuration config, FileSourceSplit split)
            throws IOException {
        try {
            return new TolerantReader(
                    delegate.restoreReader(config, split), split, openFor(split));
        } catch (IOException e) {
            LOG.warn("unreadable file '{}' on restore (skipping, emitting corrupt-file "
                    + "marker): {}", split.path(), e.toString());
            return new SentinelReader(split, openFor(split));
        }
    }

    @Override
    public boolean isSplittable() {
        return delegate.isSplittable();
    }

    @Override
    public TypeInformation<String> getProducedType() {
        return delegate.getProducedType();
    }

    /**
     * Whether this reader should announce a file opening.
     *
     * <p>{@code getReaderPosition().isEmpty()} suppresses a duplicate OPEN after a restore with
     * one expression covering both entry points. The whole-file test guards the splittable
     * case: gzip objects are never split, so it is always true in prod and repair, but dev
     * reads plain {@code .csv} through a splittable {@code TextLineInputFormat} and would
     * otherwise report one "file" per split.
     */
    private boolean openFor(FileSourceSplit split) {
        boolean wholeFile = split.offset() == 0 && split.length() == split.fileSize();
        return emitFileMarkers && wholeFile && split.getReaderPosition().isEmpty();
    }

    private static String markerFor(FileMarker.Kind kind, FileSourceSplit split) {
        return FileMarker.encode(kind, split.path().toString(),
                split.fileModificationTime(), split.fileSize());
    }

    /**
     * Delegates until the underlying reader throws, then emits the corrupt marker and ends.
     * Also brackets the file with OPEN/DONE when markers are enabled.
     */
    private final class TolerantReader implements Reader<String> {
        private final Reader<String> inner;
        private final FileSourceSplit split;
        private boolean openPending;
        private boolean failed;
        private boolean donePending;
        private boolean finished;

        /** Position of the last real record handed upward — what DONE and CORRUPT inherit, so
         * neither ever claims a record of its own. */
        private long lastOffset = RecordAndPosition.NO_OFFSET;
        private long lastSkipCount;

        TolerantReader(Reader<String> inner, FileSourceSplit split, boolean emitOpen) {
            this.inner = inner;
            this.split = split;
            this.openPending = emitOpen;
        }

        @Nullable
        @Override
        public RecordIterator<String> readBatch() throws IOException {
            if (finished) {
                return null;
            }
            if (openPending) {
                openPending = false;
                return SyntheticIterator.of(markerFor(FileMarker.Kind.OPEN, split),
                        RecordAndPosition.NO_OFFSET, 0);
            }
            if (donePending) {
                donePending = false;
                finished = true;
                return SyntheticIterator.of(
                        markerFor(FileMarker.Kind.DONE, split), lastOffset, lastSkipCount);
            }
            RecordIterator<String> batch;
            try {
                batch = inner.readBatch();
            } catch (IOException e) {
                failed = true;
                finished = true;
                LOG.warn("read failure in file '{}' (skipping rest of file, emitting "
                        + "corrupt-file marker): {}", split.path(), e.toString());
                closeQuietly();
                return SyntheticIterator.of(
                        markerFor(FileMarker.Kind.CORRUPT, split), lastOffset, lastSkipCount);
            }
            if (batch == null) {
                if (emitFileMarkers) {
                    donePending = true;
                    return readBatch();
                }
                finished = true;
                return null;
            }
            return emitFileMarkers ? new TrackingIterator(batch) : batch;
        }

        @Override
        public void close() throws IOException {
            if (!failed) {
                inner.close();
            }
        }

        private void closeQuietly() {
            try {
                inner.close();
            } catch (IOException | RuntimeException e) {
                LOG.debug("secondary failure closing reader of '{}'", split.path(), e);
            }
        }

        /** Remembers where the real records got to, so DONE/CORRUPT can inherit that position
         * instead of inventing one. */
        private final class TrackingIterator implements RecordIterator<String> {
            private final RecordIterator<String> inner;

            TrackingIterator(RecordIterator<String> inner) {
                this.inner = inner;
            }

            @Nullable
            @Override
            public RecordAndPosition<String> next() {
                RecordAndPosition<String> r = inner.next();
                if (r != null) {
                    // Copy the primitives: Flink reuses a mutable RecordAndPosition per batch.
                    lastOffset = r.getOffset();
                    lastSkipCount = r.getRecordSkipCount();
                }
                return r;
            }

            @Override
            public void releaseBatch() {
                inner.releaseBatch();
            }
        }
    }

    /**
     * Used when the file cannot even be opened: OPEN (so the file is still counted as attempted
     * and {@code filesOpened − filesCompleted − corruptFilesSkipped} stays meaningful), then
     * CORRUPT, then end-of-split.
     */
    private static final class SentinelReader implements Reader<String> {
        private final FileSourceSplit split;
        private final boolean emitOpen;
        private boolean emitted;

        SentinelReader(FileSourceSplit split, boolean emitOpen) {
            this.split = split;
            this.emitOpen = emitOpen;
        }

        @Nullable
        @Override
        public RecordIterator<String> readBatch() {
            if (emitted) {
                return null;
            }
            emitted = true;
            List<String> records = new ArrayList<>(2);
            if (emitOpen) {
                records.add(markerFor(FileMarker.Kind.OPEN, split));
            }
            records.add(markerFor(FileMarker.Kind.CORRUPT, split));
            return new SyntheticIterator(records, RecordAndPosition.NO_OFFSET, 0);
        }

        @Override
        public void close() {
            // nothing to close
        }
    }

    /**
     * Emits synthetic records that all share one position. Every record reports the <em>same</em>
     * (offset, skipCount) on purpose: a marker is not a record in the file, so it must not
     * advance the position it reports. See the class-level note on positions.
     */
    private static final class SyntheticIterator implements RecordIterator<String> {
        private final List<String> records;
        private final long offset;
        private final long skipCount;
        private int next;

        SyntheticIterator(List<String> records, long offset, long skipCount) {
            this.records = records;
            this.offset = offset;
            this.skipCount = skipCount;
        }

        static SyntheticIterator of(String record, long offset, long skipCount) {
            return new SyntheticIterator(List.of(record), offset, skipCount);
        }

        @Nullable
        @Override
        public RecordAndPosition<String> next() {
            if (next >= records.size()) {
                return null;
            }
            return new RecordAndPosition<>(records.get(next++), offset, skipCount);
        }

        @Override
        public void releaseBatch() {
            // nothing pooled
        }
    }
}
