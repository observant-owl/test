package com.example.csv2avro.core.format;

import java.io.EOFException;
import java.io.IOException;
import java.util.zip.ZipException;
import javax.annotation.Nullable;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.connector.file.src.FileSourceSplit;
import org.apache.flink.connector.file.src.impl.StreamFormatAdapter;
import org.apache.flink.connector.file.src.reader.BulkFormat;
import org.apache.flink.connector.file.src.reader.StreamFormat;
import org.apache.flink.connector.file.src.util.CheckpointedPosition;
import org.apache.flink.connector.file.src.util.RecordAndPosition;
import org.apache.flink.connector.file.src.util.SingletonResultIterator;
import org.apache.flink.util.ExceptionUtils;
import org.apache.flink.util.function.SupplierWithException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Wraps the stock line format to produce {@link Line}s carrying file identity, and to skip
 * structurally corrupt objects instead of failing the job.
 *
 * <p>Wrapping at {@link BulkFormat} level (around {@link StreamFormatAdapter}) is what makes
 * both possible: the split carries path/mtime/size, and the adapter's decompression runs inside
 * the try, so even a corrupt gzip header is caught. {@code StreamFormatAdapter} is
 * {@code @Internal}, so this class pins the usable {@code flink-connector-files} version.
 *
 * <p>Three invariants, all of which fail silently if broken — see CLAUDE.md:
 * <ul>
 *   <li>Only {@link ZipException} is structural. {@link EOFException} is transient (S3A raises
 *       it for connection resets), and skipping on it loses whole objects unrecoverably.
 *   <li>Synthetic records carry the split's resume position, never one of their own.
 *   <li>Hence {@link SingletonResultIterator} (writes the position verbatim) and <b>not</b>
 *       {@code ArrayResultIterator}, which increments the skip count.
 * </ul>
 */
public final class CorruptTolerantBulkFormat implements BulkFormat<Line, FileSourceSplit> {

    private static final long serialVersionUID = 1L;
    private static final Logger LOG = LoggerFactory.getLogger(CorruptTolerantBulkFormat.class);

    private final StreamFormatAdapter<String> delegate;

    public CorruptTolerantBulkFormat(StreamFormat<String> lineFormat) {
        this.delegate = new StreamFormatAdapter<>(lineFormat);
    }

    @Override
    public Reader<Line> createReader(Configuration config, FileSourceSplit split)
            throws IOException {
        return open(split, () -> delegate.createReader(config, split), "");
    }

    @Override
    public Reader<Line> restoreReader(Configuration config, FileSourceSplit split)
            throws IOException {
        return open(split, () -> delegate.restoreReader(config, split), " on restore");
    }

    /** The shared corrupt-tolerance policy for both entry points. */
    private static Reader<Line> open(
            FileSourceSplit split,
            SupplierWithException<Reader<String>, IOException> readerFactory,
            String when)
            throws IOException {
        try {
            return new TolerantReader(readerFactory.get(), split);
        } catch (IOException e) {
            if (!isStructuralCorruption(e)) {
                throw e; // transient: let the task fail and Flink retry the file
            }
            LOG.warn("unreadable file '{}'{} (skipping, emitting corrupt-file record): {}",
                    split.path(), when, e.toString());
            return new TolerantReader(null, split);
        }
    }

    /** Always false: gzip cannot be split, and one whole file per split is what keeps the file
     * and byte counts from multiplying. */
    @Override
    public boolean isSplittable() {
        return false;
    }

    @Override
    public TypeInformation<Line> getProducedType() {
        return TypeInformation.of(Line.class);
    }

    /** Skip the object, or rethrow and let Flink retry it? See the class note. */
    static boolean isStructuralCorruption(Throwable t) {
        return ExceptionUtils.findThrowable(t, ZipException.class).isPresent();
    }

    /** Emits FILE_OPEN, then delegates, until structural corruption ends the split with a
     * CORRUPT. A null {@code inner} means the file could not be opened at all. */
    private static final class TolerantReader implements Reader<Line> {

        private enum State { OPEN_PENDING, DELEGATING, CORRUPT_PENDING, DONE }

        @Nullable
        private final Reader<String> inner;
        private final FileSourceSplit split;
        private final long offset;
        private final long skipCount;
        private State state = State.OPEN_PENDING;
        private boolean innerClosed;

        TolerantReader(@Nullable Reader<String> inner, FileSourceSplit split) {
            this.inner = inner;
            this.split = split;
            CheckpointedPosition restored = split.getReaderPosition().orElse(null);
            this.offset = restored == null ? RecordAndPosition.NO_OFFSET : restored.getOffset();
            this.skipCount = restored == null ? 0 : restored.getRecordsAfterOffset();
        }

        @Nullable
        @Override
        public RecordIterator<Line> readBatch() throws IOException {
            switch (state) {
                case OPEN_PENDING -> {
                    // Announced even when unopenable, so the object still counts as attempted
                    // and its mtime still reaches the freshness gauge.
                    state = inner == null ? State.CORRUPT_PENDING : State.DELEGATING;
                    return synthetic(Line.fileOpen(path(), mtime(), size()));
                }
                case CORRUPT_PENDING -> {
                    state = State.DONE;
                    return synthetic(Line.corrupt(path(), mtime(), size()));
                }
                case DONE -> {
                    return null; // the rest of the file is abandoned
                }
                default -> {
                    return delegateBatch();
                }
            }
        }

        @Nullable
        private RecordIterator<Line> delegateBatch() throws IOException {
            try {
                RecordIterator<String> batch = inner.readBatch();
                return batch == null ? null : new DataIterator(batch, path(), mtime(), size());
            } catch (IOException e) {
                if (!isStructuralCorruption(e)) {
                    // Transient: propagate. The task fails, Flink restarts it, and the file is
                    // read again from the last checkpoint — no skip, no data loss.
                    throw e;
                }
                state = State.DONE;
                LOG.warn("read failure in file '{}' (skipping rest of file, emitting "
                        + "corrupt-file record): {}", split.path(), e.toString());
                closeQuietly();
                return synthetic(Line.corrupt(path(), mtime(), size()));
            }
        }

        private RecordIterator<Line> synthetic(Line line) {
            SingletonResultIterator<Line> it = new SingletonResultIterator<>();
            it.set(line, offset, skipCount);
            return it;
        }

        private String path() {
            return split.path().toString();
        }

        private long mtime() {
            return split.fileModificationTime();
        }

        private long size() {
            return split.fileSize();
        }

        @Override
        public void close() throws IOException {
            if (inner != null && !innerClosed) {
                innerClosed = true;
                inner.close();
            }
        }

        private void closeQuietly() {
            try {
                close();
            } catch (IOException | RuntimeException e) {
                LOG.debug("secondary failure closing reader of '{}'", split.path(), e);
            }
        }
    }

    /** Attaches file identity to every line, preserving each record's real position. */
    private static final class DataIterator implements RecordIterator<Line> {

        private final RecordIterator<String> inner;
        private final String path;
        private final long modifiedMillis;
        private final long sizeBytes;

        DataIterator(RecordIterator<String> inner, String path, long modifiedMillis,
                long sizeBytes) {
            this.inner = inner;
            this.path = path;
            this.modifiedMillis = modifiedMillis;
            this.sizeBytes = sizeBytes;
        }

        @Nullable
        @Override
        public RecordAndPosition<Line> next() {
            RecordAndPosition<String> r = inner.next();
            if (r == null) {
                return null;
            }
            return new RecordAndPosition<>(
                    Line.data(r.getRecord(), path, modifiedMillis, sizeBytes),
                    r.getOffset(), r.getRecordSkipCount());
        }

        @Override
        public void releaseBatch() {
            inner.releaseBatch();
        }
    }
}
