package com.example.csv2avro.runtime;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import org.apache.flink.configuration.ReadableConfig;

/**
 * The one place configuration is unpacked into {@link LineParser} constructor arguments.
 *
 * <p>Two jobs in one value object: {@link CsvToAvroFunction} ships it to the task instead of the
 * whole configuration (only these few scalars need to travel), and the conformance test builds
 * its parser through {@link #of} too — before this existed the test restated the unpack by hand
 * and had already drifted from production on one of the arguments.
 */
public record ParserSettings(
        String streamId, String expectedHeader, char delimiter, char quote,
        Character escape, Set<String> nullTokens)
        implements Serializable {

    public static ParserSettings of(ReadableConfig conf, String streamId) {
        Set<String> nullTokens = new HashSet<>(conf.get(CsvConfig.NULL_TOKENS));
        Character escape = conf.getOptional(CsvConfig.ESCAPE).isPresent()
                ? CsvConfig.singleChar(conf, CsvConfig.ESCAPE)
                : null;
        return new ParserSettings(
                streamId,
                conf.get(CsvConfig.EXPECTED_HEADER),
                CsvConfig.singleChar(conf, CsvConfig.DELIMITER),
                CsvConfig.singleChar(conf, CsvConfig.QUOTE),
                escape,
                nullTokens);
    }

    public LineParser newParser() {
        return new LineParser(streamId, expectedHeader, delimiter, quote, escape, nullTokens);
    }
}
