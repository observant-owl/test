package com.example.csv2avro.runtime;

import org.apache.flink.api.connector.source.Source;
import org.apache.flink.configuration.ReadableConfig;
import org.apache.flink.connector.file.src.reader.TextLineInputFormat;

/**
 * Builds the per-stream source: own prefix, own enumerator.
 *
 * <p><b>Not wired yet — nothing can run until {@link #forStream} is completed.</b> See CLAUDE.md
 * for the resolved {@code OwnFileSource} contract, and for why Flink's own {@code FileSource} is
 * not the answer here.
 */
public final class Sources {

    private Sources() {
    }

    /** Stock text lines + transparent decompression + corrupt-file tolerance, producing
     * {@link Line}s that each carry the identity of the object they came from. */
    public static CorruptTolerantBulkFormat lineFormat(ReadableConfig conf) {
        return new CorruptTolerantBulkFormat(
                new TextLineInputFormat(conf.get(CsvConfig.CHARSET)));
    }

    public static Source<Line, ?, ?> forStream(ReadableConfig conf) {
        // TODO(user): add the OwnFileSource dependency to pom.xml and wire it here.
        // Expected shape (adjust to its actual builder API):
        //
        //   return OwnFileSource
        //           .forBulkFileFormat(lineFormat(conf),
        //                   new Path(conf.get(CsvConfig.SOURCE_PREFIX)))
        //           .monitorInterval(conf.get(CsvConfig.MONITOR_INTERVAL))
        //           .build();
        //
        // Its splits must carry a real fileModificationTime() and fileSize() and be whole files,
        // or the per-file metrics and DLQ object keys are wrong.
        throw new IllegalStateException(
                "the source is not wired yet: add the OwnFileSource dependency to pom.xml and "
                        + "complete Sources.forStream(). Nothing can run until this is done.");
    }
}
