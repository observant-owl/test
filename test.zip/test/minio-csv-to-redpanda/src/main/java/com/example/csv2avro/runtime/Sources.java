package com.example.csv2avro.runtime;

import org.apache.flink.api.connector.source.Source;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.configuration.ReadableConfig;
import org.apache.flink.connector.file.src.reader.TextLineInputFormat;

/**
 * Builds the per-stream source: own prefix, own enumerator, and optionally its own S3 client.
 *
 * <p><b>Not wired yet — nothing can run until {@link #forStream} is completed.</b> See CLAUDE.md
 * for the resolved {@code OwnFileSource} contract, and for why Flink's own {@code FileSource} is
 * not the answer here.
 */
public final class Sources {

    private Sources() {
    }

    /** Stock text lines + transparent decompression + corrupt-file tolerance, producing
     * {@link Line}s that each carry the identity of the object they came from. */
    public static CorruptTolerantBulkFormat lineFormat(ReadableConfig conf) {
        return new CorruptTolerantBulkFormat(
                new TextLineInputFormat(conf.get(Profile.CHARSET)));
    }

    public static Source<Line, ?, ?> forStream(Configuration conf) {
        String prefix = Profile.objectPrefix(conf);
        // null when the profile sets no source.s3 block: the source then reads through Flink's
        // s3.* filesystem plugin, which is the single-MinIO arrangement and still supported.
        S3Settings s3 = Profile.sourceS3(conf);

        // TODO(user): add the OwnFileSource dependency to pom.xml and wire it here.
        // Expected shape (adjust to its actual builder API):
        //
        //   var builder = OwnFileSource
        //           .forBulkFileFormat(lineFormat(conf), new Path(prefix))
        //           .monitorInterval(conf.get(Profile.MONITOR_INTERVAL));
        //   if (s3 != null) {
        //       // Gives the source its own S3 client, so the CSV objects can live on a
        //       // different MinIO from checkpoints, savepoints and HA — those stay on Flink's
        //       // global s3.* keys, which can only ever describe one endpoint.
        //       builder.withFileSystem(new S3FileSystemSetting(s3.endpoint(), s3.accessKey(),
        //               s3.secretKey(), s3.region(), s3.bucket()));
        //   }
        //   return builder.build();
        //
        // Its splits must carry a real fileModificationTime() and fileSize() and be whole files,
        // or the per-file metrics and DLQ object keys are wrong.
        // The two resolved values are named in the message rather than dropped: it keeps them
        // used, and it means a prefix or credential mistake shows up here instead of waiting for
        // the dependency to land. The "not wired yet" substring is load-bearing — SourceContract-
        // Test and JobGraphTest skip on it, and start running by themselves once it is gone.
        throw new IllegalStateException(
                "the source is not wired yet: add the OwnFileSource dependency to pom.xml and "
                        + "complete Sources.forStream(). Nothing can run until this is done. "
                        + "Resolved prefix=" + prefix + ", filesystem="
                        + (s3 == null ? "Flink s3.* plugin" : s3));
    }
}
