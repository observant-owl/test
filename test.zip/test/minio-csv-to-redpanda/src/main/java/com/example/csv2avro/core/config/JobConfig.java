package com.example.csv2avro.core.config;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import java.io.IOException;
import java.io.Serializable;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * The whole job configuration, loaded from one profile YAML (config/dev.yaml, prod.yaml,
 * missing-files.yaml). Strict on purpose: unknown YAML keys fail, and
 * {@link #validateAgainst(Set)} fails fast on any mismatch between config and discovered
 * stream definitions — in <b>both</b> directions. A missing config key must never silently
 * mean "disabled"; that is how a pipeline quietly stops ingesting a type for three weeks.
 */
public class JobConfig implements Serializable {

    public JobSection job = new JobSection();
    public KafkaSection kafka = new KafkaSection();
    public DlqSection dlq = new DlqSection();
    public SourceSection source = new SourceSection();
    public DefaultsSection defaults = new DefaultsSection();
    public Map<String, StreamConfig> streams = new LinkedHashMap<>();

    public static JobConfig load(Path file) {
        ObjectMapper mapper = JsonMapper.builder(new YAMLFactory())
                .enable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS)
                .build();
        try {
            JobConfig cfg = mapper.readValue(Files.readAllBytes(file), JobConfig.class);
            cfg.basicValidate(file);
            return cfg;
        } catch (IOException e) {
            throw new UncheckedIOException("cannot read config file " + file, e);
        }
    }

    private void basicValidate(Path file) {
        List<String> errors = new ArrayList<>();
        if (streams.isEmpty()) {
            errors.add("no streams configured");
        }
        streams.forEach((id, sc) -> {
            if (sc == null) {
                errors.add("stream '" + id + "': empty config block");
                return;
            }
            if (!sc.enabled) {
                return; // disabled streams may stay partially filled
            }
            if (isBlank(sc.prefix) && (sc.paths == null || sc.paths.isEmpty())) {
                errors.add("stream '" + id + "': needs 'prefix' or 'paths'");
            }
            if (isBlank(sc.topic)) {
                errors.add("stream '" + id + "': 'topic' missing");
            }
            if (isBlank(sc.expectedHeader)) {
                errors.add("stream '" + id + "': 'expectedHeader' missing (the verbatim "
                        + "header line — required for name-based column binding)");
            }
            errors.addAll(sc.dialect.validate(id));
        });
        if (!errors.isEmpty()) {
            throw new IllegalStateException(
                    "invalid config " + file + ":\n  - " + String.join("\n  - ", errors));
        }
    }

    /** Fail fast, both directions: unknown config keys and unconfigured definitions. */
    public void validateAgainst(Set<String> discoveredStreamIds) {
        Set<String> unconfigured = new TreeSet<>(discoveredStreamIds);
        unconfigured.removeAll(streams.keySet());
        Set<String> unknown = new TreeSet<>(streams.keySet());
        unknown.removeAll(discoveredStreamIds);
        List<String> errors = new ArrayList<>();
        if (!unconfigured.isEmpty()) {
            errors.add("discovered stream definitions without a config block "
                    + "(add them, or set enabled: false explicitly): " + unconfigured);
        }
        if (!unknown.isEmpty()) {
            errors.add("config blocks without a discovered stream definition "
                    + "(typo in id, or missing META-INF/services entry?): " + unknown);
        }
        if (!errors.isEmpty()) {
            throw new IllegalStateException(String.join("; ", errors));
        }
    }

    public StreamConfig requireStream(String id) {
        StreamConfig sc = streams.get(id);
        if (sc == null) {
            throw new IllegalStateException("no config block for stream '" + id + "'");
        }
        return sc;
    }

    public int sourceParallelism(StreamConfig sc) {
        return sc.sourceParallelism != null ? sc.sourceParallelism : defaults.sourceParallelism;
    }

    public int sinkParallelism(StreamConfig sc) {
        return sc.sinkParallelism != null ? sc.sinkParallelism : defaults.sinkParallelism;
    }

    private static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }

    // --- sections -------------------------------------------------------------------------

    public static class JobSection implements Serializable {
        public String name = "csv-to-avro";
        /** Replaces all Kafka sinks (records and DLQ) with print sinks. */
        public boolean dryRun = false;
    }

    public static class KafkaSection implements Serializable {
        public String bootstrapServers;
        public String schemaRegistryUrl;
        /** Passed through to the Kafka producer (e.g. compression.type, security settings). */
        public Map<String, String> properties = new LinkedHashMap<>();
    }

    public static class DlqSection implements Serializable {
        /** One shared JSON DLQ topic for all streams. */
        public String topic = "csv-ingest.dlq";
    }

    public static class SourceSection implements Serializable {
        public enum Kind { STOCK, OWN }
        public enum Mode { CONTINUOUS, BOUNDED }

        /** STOCK = Flink's FileSource (dev, missing-files); OWN = the user's OwnFileSource
         * (prod continuous — wiring stub until the dependency is added). */
        public Kind kind = Kind.STOCK;
        public Mode mode = Mode.CONTINUOUS;
        public long monitorIntervalSeconds = 30;
    }

    public static class DefaultsSection implements Serializable {
        public int sourceParallelism = 1;
        public int sinkParallelism = 1;
        /** Halt a type loudly on detected header drift (schema cutover). */
        public boolean haltOnHeaderDrift = true;
        /**
         * Inject in-band file-boundary markers so the parse operator can count files, bytes and
         * data freshness (see {@code FileMarker}). Config-only rollback for the one change that
         * touches the record path; markers never leave the parse operator. Corrupt-file
         * markers are emitted regardless — those are a data-loss signal, not telemetry.
         */
        public boolean emitFileMarkers = true;
    }
}
