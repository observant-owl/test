package com.example.csv2avro.core.config;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import java.io.IOException;
import java.io.Serializable;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * The whole job configuration, deep-merged from an ordered list of YAML layers. See CLAUDE.md
 * for the layer order and merge rules.
 *
 * <p>Strict on purpose: unknown keys fail in any layer, an empty {@code streams} map fails, and
 * a stream block naming no registered definition fails. Between them, "the deployment came up
 * but ingests nothing" is not reachable.
 */
public class JobConfig implements Serializable {

    public JobSection job = new JobSection();
    public KafkaSection kafka = new KafkaSection();
    public DlqSection dlq = new DlqSection();
    public SourceSection source = new SourceSection();
    public DefaultsSection defaults = new DefaultsSection();
    public Map<String, StreamConfig> streams = new LinkedHashMap<>();

    /**
     * Merging the trees <em>before</em> deserializing is what lets an overlay set a single leaf
     * without restating its siblings, and keeps a typo'd key in any layer a startup failure
     * rather than a silently ignored line.
     */
    public static JobConfig load(List<Path> files) {
        if (files == null || files.isEmpty()) {
            throw new IllegalArgumentException("at least one config file is required");
        }
        ObjectMapper mapper = JsonMapper.builder(new YAMLFactory())
                .enable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS)
                .build();

        ObjectNode merged = mapper.createObjectNode();
        for (Path file : files) {
            JsonNode layer;
            try {
                layer = mapper.readTree(Files.readAllBytes(file));
            } catch (IOException e) {
                throw new UncheckedIOException("cannot read config file " + file, e);
            }
            if (layer == null || layer.isNull() || layer.isMissingNode()) {
                continue; // an all-comments layer is legal; it simply overrides nothing
            }
            if (!layer.isObject()) {
                throw new IllegalStateException("config file " + file
                        + " must contain a YAML mapping at the top level");
            }
            deepMerge(merged, (ObjectNode) layer);
        }

        JobConfig cfg;
        try {
            cfg = mapper.treeToValue(merged, JobConfig.class);
        } catch (JsonProcessingException e) {
            // UncheckedIOException, not IllegalStateException: same failure class as an
            // unreadable file, and callers already treat both as "the config is unusable".
            throw new UncheckedIOException("cannot bind merged config " + describe(files), e);
        }
        cfg.basicValidate(files);
        return cfg;
    }

    /**
     * Object nodes recurse; <b>scalars, arrays and explicit nulls are replaced wholesale</b>.
     * Arrays deliberately do not concatenate — appending would make it impossible to shorten a
     * list from an overlay, which is the far more common need.
     */
    static void deepMerge(ObjectNode into, ObjectNode from) {
        Iterator<String> names = from.fieldNames();
        while (names.hasNext()) {
            String name = names.next();
            JsonNode incoming = from.get(name);
            JsonNode existing = into.get(name);
            if (existing != null && existing.isObject() && incoming.isObject()) {
                deepMerge((ObjectNode) existing, (ObjectNode) incoming);
            } else {
                into.set(name, incoming.deepCopy());
            }
        }
    }

    private static String describe(List<Path> files) {
        return files.size() == 1 ? files.get(0).toString() : files.toString();
    }

    private void basicValidate(List<Path> files) {
        List<String> errors = new ArrayList<>();
        if (streams.isEmpty()) {
            errors.add("no streams configured");
        }
        for (Map.Entry<String, StreamConfig> entry : streams.entrySet()) {
            String id = entry.getKey();
            StreamConfig sc = entry.getValue();
            if (sc == null) {
                errors.add("stream '" + id + "': empty config block");
                continue;
            }
            if (isBlank(sc.prefix)) {
                errors.add("stream '" + id + "': 'prefix' missing");
            }
            if (isBlank(sc.topic)) {
                errors.add("stream '" + id + "': 'topic' missing");
            }
            if (isBlank(sc.expectedHeader)) {
                errors.add("stream '" + id + "': 'expectedHeader' missing (the verbatim "
                        + "header line — required for name-based column binding)");
            }
            if (monitorIntervalSeconds(sc) <= 0) {
                errors.add("stream '" + id + "': monitorIntervalSeconds must be > 0 (a "
                        + "zero/negative poll interval is a busy loop against S3, not 'as fast "
                        + "as possible')");
            }
            if (sc.dialect == null) {
                // Not merely "absent": deepMerge replaces explicit nulls wholesale, so a bare
                // `dialect:` in an overlay binds null over the field initializer. Without this
                // guard that is an NPE inside validation instead of a config error.
                errors.add("stream '" + id + "': 'dialect' block is null/missing");
            } else {
                errors.addAll(sc.dialect.validate(id));
            }
        }
        // Every stream writes to Kafka, so the endpoints are unconditionally required.
        // "Forgot to pass --config config/env/<env>.yaml" is the failure this catches, and it
        // must name every missing key at once rather than one per restart.
        List<String> missing = new ArrayList<>();
        if (kafka == null || isBlank(kafka.bootstrapServers)) {
            missing.add("kafka.bootstrapServers");
        }
        if (kafka == null || isBlank(kafka.schemaRegistryUrl)) {
            missing.add("kafka.schemaRegistryUrl");
        }
        if (dlq == null || isBlank(dlq.topic)) {
            missing.add("dlq.topic");
        }
        if (!missing.isEmpty()) {
            errors.add(String.join(", ", missing) + " must be set — usually supplied by "
                    + "config/env/<env>.yaml, is it in the --config list?");
        }
        if (!errors.isEmpty()) {
            // Name every layer: with a merged config, "which file is wrong" is not obvious.
            throw new IllegalStateException("invalid config " + describe(files)
                    + ":\n  - " + String.join("\n  - ", errors));
        }
    }

    /**
     * A config block naming an unregistered stream is a typo in the id — always a mistake.
     *
     * <p>The reverse is deliberately <b>not</b> checked: a registered type with no config block
     * simply does not run, because one deployment runs one type. Requiring a stub would make
     * registering a new type break every other type's deployment.
     */
    public void validateAgainst(Set<String> discoveredStreamIds) {
        Set<String> unknown = new TreeSet<>(streams.keySet());
        unknown.removeAll(discoveredStreamIds);
        if (!unknown.isEmpty()) {
            throw new IllegalStateException("config blocks without a discovered stream "
                    + "definition (typo in id, or missing META-INF/services entry?): " + unknown);
        }
    }

    public StreamConfig requireStream(String id) {
        StreamConfig sc = streams.get(id);
        if (sc == null) {
            throw new IllegalStateException("no config block for stream '" + id + "'");
        }
        return sc;
    }

    /** One value for the whole chain. Source, parse/map and sink must share a parallelism or
     * Flink cannot chain them into a single operator — see {@code config/base.yaml}. */
    public int parallelism(StreamConfig sc) {
        return sc.parallelism != null ? sc.parallelism : defaults.parallelism;
    }

    /** Poll interval, per-stream because arrival rates are not uniform. */
    public long monitorIntervalSeconds(StreamConfig sc) {
        return sc.monitorIntervalSeconds != null
                ? sc.monitorIntervalSeconds : source.monitorIntervalSeconds;
    }

    private static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }

    // --- sections -------------------------------------------------------------------------

    public static class JobSection implements Serializable {
        /** Base name; {@code Job} appends {@code -<streamId>}. Must match the
         * FlinkDeployment's metadata.name — pinned by ConfigStackTest. */
        public String name = "csv-to-avro";
    }

    public static class KafkaSection implements Serializable {
        public String bootstrapServers;
        public String schemaRegistryUrl;
        /** Passed through to the Kafka producer (e.g. compression.type, security settings). */
        public Map<String, String> properties = new LinkedHashMap<>();
    }

    public static class DlqSection implements Serializable {
        /** One shared JSON DLQ topic for all streams. */
        public String topic = "csv-ingest.dlq";
    }

    public static class SourceSection implements Serializable {
        /** Default poll interval; override per stream via
         * {@code streams.<id>.monitorIntervalSeconds}. */
        public long monitorIntervalSeconds = 30;
    }

    public static class DefaultsSection implements Serializable {
        /** One parallelism for the whole source → parse/map → sink chain. Override per stream
         * via {@code streams.<id>.parallelism}. */
        public int parallelism = 1;
    }
}
