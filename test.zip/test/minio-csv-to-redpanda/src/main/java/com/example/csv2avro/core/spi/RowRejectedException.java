package com.example.csv2avro.core.spi;

/**
 * Thrown by a {@link RowMapper} (or {@code CsvRow.require}) to route a row to the DLQ.
 *
 * <p>Carries two things that serve different audiences: the message is free prose for the DLQ
 * payload (name the column, quote the value), and {@link #code()} is the bounded
 * {@link RejectReason} that becomes a Prometheus label. Use
 * {@link RejectReason#MAPPER_OTHER} when no more specific code fits.
 */
public class RowRejectedException extends Exception {

    private static final long serialVersionUID = 1L;

    private final RejectReason code;

    public RowRejectedException(RejectReason code, String reason) {
        super(reason);
        this.code = code;
    }

    public RowRejectedException(RejectReason code, String reason, Throwable cause) {
        super(reason, cause);
        this.code = code;
    }

    /** Never null. */
    public RejectReason code() {
        return code;
    }
}
