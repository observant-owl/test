# minio-csv-to-redpanda

Flink 2.1 job: gzipped CSV objects from MinIO/S3 → per-type normalization → Avro
(Confluent wire format, Redpanda Schema Registry) → one Redpanda topic per CSV type.
Design documents: `PLAN.md` (architecture) and `OPEN-QUESTIONS.md` (decisions log + what's
still open).

## Status

Core business logic is built and tested (61 unit/conformance tests, plus a local end-to-end
dry run). What remains is **filling in the placeholders**:

- [ ] Per-type specifics for the five real CSV types (see "Finishing a type" below —
      `type-a` is the worked template)
- [ ] Wire `OwnFileSource` for prod: add its artifact to `pom.xml`, complete
      `Sources.own()` (has a TODO with the expected shape)
- [ ] Infra values: Redpanda/SR endpoints in `config/*.yaml`, everything marked
      `TODO(user)`/`PLACEHOLDER` in `k8s/*.yaml`
- [ ] Schema registration CI step (explicit registration, `BACKWARD`; the job itself should
      not be the thing that registers schemas in prod)
- [ ] Rename the placeholder Java package `com.example.csv2avro` (one IDE refactor)

## Build & test

```sh
export JAVA_HOME=$(/usr/libexec/java_home -v 17 2>/dev/null || echo /Library/Java/JavaVirtualMachines/temurin-17.jdk/Contents/Home)
mvn test          # unit + conformance tests
mvn package       # shaded job jar in target/
```

Local smoke run without any infrastructure (bounded file source, print sinks):
see `target/smoke/smoke.yaml` pattern — a config with `dryRun: true`, `kind: stock`,
`mode: bounded`, and a `file://` prefix.

## The three profiles

| Profile | Source | Mode | Purpose |
|---|---|---|---|
| `config/dev.yaml` | stock `FileSource` | continuous | development; runs without `OwnFileSource` |
| `config/prod.yaml` | `OwnFileSource` | continuous | production (mod-time monitoring, no growing path state) |
| `config/missing-files.yaml` | stock `FileSource` | bounded | one-shot repair/backfill of a static file set |

Deployed via the Flink Kubernetes Operator: `k8s/flinkdeployment-{dev,prod,missing-files}.yaml`.

## Finishing a type (or adding a sixth)

`type-a` is the template. A type consists of exactly:

1. **Schema** — `src/main/avro/<id>.avsc` (new fields need defaults; breaking change ⇒ new
   `.v2` topic, never a registry override).
2. **Code** — `streams/<id>/`: a `CsvStreamDefinition` + a `RowMapper` (plain Java column
   surgery over `row.get`/`row.require` and the `Cols` helpers; deliberately no config DSL).
3. **Registration** — one line in
   `src/main/resources/META-INF/services/com.example.csv2avro.core.spi.CsvStreamDefinition`.
4. **Config** — one `streams.<id>` block in each profile: `prefix`, `topic`,
   **`expectedHeader` (the verbatim header line — get it exactly right)**, `dialect`
   (delimiter, quote, charset, nullTokens).
5. **Fixture** — `src/test/resources/fixtures/<id>/input.csv` + `expected.json`. The
   conformance test discovers every registered type and fails if the fixture is missing or
   the mapper output diverges.

Config and discovered definitions are validated against each other in both directions at
startup — a typo'd id or missing block refuses to start rather than silently not ingesting.

## Behavior decisions (2026-09-01, see OPEN-QUESTIONS.md §4)

- **Header cutover ⇒ halt that type loudly.** A header-shaped line differing from
  `expectedHeader` throws; only that type's region restarts (exponential-delay restart
  strategy — configured in the k8s manifests — keeps the halt from exhausting a job-wide
  budget). Fix = update `.avsc` + mapper + `expectedHeader`, redeploy. A removed-column
  cutover may instead surface as a DLQ-rate surge (rows reject on column count).
- **Corrupt/truncated object ⇒ skip + count + log**, via `CorruptTolerantBulkFormat`: the
  per-file read error becomes a sentinel record → `csv2avro.corruptFilesSkipped` counter,
  a WARN log, and a DLQ entry naming the object. Trade-off: a transient read error is
  indistinguishable from corruption and also skips the file (repair via missing-files).
- **Missed/backdated objects** (OwnFileSource's strict `mtime >` cursor): copy them into the
  repair prefix and run the missing-files profile once. Duplicates are safe — ClickHouse
  ReplacingMergeTree collapses on the content-derived business key (which must never include
  ingest-time values).
- **Duplicates:** at-least-once; the replay window is one whole file (gzip can't seek).
  No dedup in Flink; ClickHouse absorbs it. Prefer many small objects over few huge ones.
- **DLQ:** one shared JSON topic (`csv-ingest.dlq`): raw line, stream id, reason, object key
  when known (only corrupt-file entries can name their object — row-level entries carry no file
  identity). The prose reason goes to the DLQ; a bounded `RejectReason` code goes to Prometheus.

## Standing assumptions (verify per type when filling in configs)

- **No CSV field ever contains an embedded newline.** Line-oriented reading breaks otherwise;
  a type that violates this needs a file-scoped reader.
- No preamble lines before the header (per-file `skipLines` is impossible without file
  boundaries; preamble junk would land in the DLQ).
- Files are single-part atomic PUTs (no partially-visible multipart uploads).

## Metrics & alerting

All declared in one place — `core/metrics/StreamMetrics.java` — under scope
`csv2avro` + a **keyed** `stream` group, so the CSV type is a real Prometheus label rather than
something you infer from `operator_name`. Exported names look like
`flink_taskmanager_job_task_operator_csv2avro_stream_recordsOut{stream="type-a"}`.

| Metric | Type | Labels | Use |
|---|---|---|---|
| `recordsOut` | counter | `stream` | throughput SLI (≠ `numRecordsOut`, which also counts DLQ side output) |
| `rowsRejected` | counter | `stream`, `reason` | error SLI; `reason` ∈ `malformed-csv`, `column-count`, `header-drift-suspect`, `missing-required`, `value-format`, `mapper-other` |
| `corruptFilesSkipped` | counter | `stream` | silent data loss at file granularity |
| `headerDriftHalts` | counter | `stream` | schema cutover |
| `mapperFailures` | counter | `stream` | mapper threw something that is *not* a rejection — the task dies, so this is your only trace |
| `filesOpened` / `filesCompleted` | counter | `stream` | separates "upstream idle" from "we are stuck"; the difference (minus corrupt) is files in flight |
| `objectBytesRead` | counter | `stream` | volume independent of row count; compressed on-the-wire size, counted on completion |
| `headerLinesDropped` / `blankLinesDropped` | counter | `stream` | cross-check: header drops should track `filesCompleted` ~1:1 |
| `newestFileModifiedMillis` | gauge | `stream` | freshness, as an absolute epoch timestamp |

Freshness is deliberately a **timestamp, not a pre-computed age** — no clock skew baked in, and
aggregation across subtasks is a clean `max` (a `min` over ages would be dominated by subtasks
that got no splits). Data age in seconds:

```promql
time() - (max by (stream) (flink_taskmanager_job_task_operator_csv2avro_stream_newestFileModifiedMillis > 0) / 1000)
```

Total rejections across reasons is `sum without(reason) (...)` — a metric cannot exist both with
and without the `reason` dimension. All six `reason` series are pre-created at zero, because an
absent series is indistinguishable from a zero one and an alert on it would silently never fire.

Alert on the **rate** of `rowsRejected`, and on any increase of `corruptFilesSkipped`,
`headerDriftHalts` or `mapperFailures`. Thresholds are yours to tune.

Two invariants worth not breaking: never call `dec()` on these counters (Flink exports them as
`TYPE gauge`, and PromQL's reset detection relies on them being monotonic), and never let a
synthetic record claim to advance a file position — see the file-marker note below.

### File markers

Per-file metrics need file boundaries, which a flat line stream does not have.
`CorruptTolerantBulkFormat` therefore injects NUL-separated `FileMarker` records (`OPEN` /
`DONE` / `CORRUPT`) around each object's lines; `CsvToAvroFunction` counts them and **drops
them**, so nothing synthetic reaches Kafka or the DLQ. Kill switch: `defaults.emitFileMarkers:
false` (corrupt markers are emitted regardless — those are a data-loss signal, not telemetry).

> **Prerequisite, not yet done:** the Prometheus reporter ships in the image's `/opt/flink/opt/`
> and must be activated as a plugin via `ENABLE_BUILT_IN_PLUGINS`, which currently lists only the
> S3 jar — so nothing above is scraped yet. Check with
> `curl -s localhost:9249/metrics | grep -c '^flink_'` against a port-forwarded TaskManager.

## Runbook sketches

- **Enable/disable a type:** flip `enabled` in the profile. Disabling then restoring from a
  savepoint needs `--allowNonRestoredState` (its source state has no claimant).
- **Schema cutover:** type halts → update `.avsc` (with defaults) + mapper +
  `expectedHeader` → register schema (CI) → redeploy → optionally missing-files-replay any
  files that were DLQ'd during the window.
- **Missing files:** copy objects to the repair prefix → deploy
  `flinkdeployment-missing-files.yaml` → wait for FINISHED → delete resource → empty the
  repair prefix.
- **Corrupt file:** already skipped and DLQ'd; fix/re-export upstream, then missing-files it.
